NAME        beasleyC3
ROWS
 N  MinOBJ..
 E  CNS..002
 E  CNS..003
 E  CNS..005
 E  CNS..006
 E  CNS..007
 E  CNS..009
 E  CNS..010
 E  CNS..011
 E  CNS..012
 E  CNS..013
 E  CNS..015
 E  CNS..016
 E  CNS..020
 E  CNS..023
 E  CNS..024
 E  CNS..026
 E  CNS..027
 E  CNS..030
 E  CNS..031
 E  CNS..033
 E  CNS..036
 E  CNS..038
 E  CNS..039
 E  CNS..040
 E  CNS..042
 E  CNS..043
 E  CNS..045
 E  CNS..047
 E  CNS..048
 E  CNS..052
 E  CNS..053
 E  CNS..056
 E  CNS..058
 E  CNS..059
 E  CNS..065
 E  CNS..066
 E  CNS..069
 E  CNS..071
 E  CNS..072
 E  CNS..073
 E  CNS..074
 E  CNS..077
 E  CNS..080
 E  CNS..081
 E  CNS..082
 E  CNS..083
 E  CNS..084
 E  CNS..085
 E  CNS..086
 E  CNS..087
 E  CNS..088
 E  CNS..090
 E  CNS..091
 E  CNS..092
 E  CNS..098
 E  CNS..102
 E  CNS..103
 E  CNS..106
 E  CNS..108
 E  CNS..109
 E  CNS..110
 E  CNS..116
 E  CNS..117
 E  CNS..118
 E  CNS..120
 E  CNS..121
 E  CNS..123
 E  CNS..126
 E  CNS..127
 E  CNS..128
 E  CNS..129
 E  CNS..130
 E  CNS..131
 E  CNS..132
 E  CNS..133
 E  CNS..134
 E  CNS..135
 E  CNS..136
 E  CNS..138
 E  CNS..140
 E  CNS..141
 E  CNS..142
 E  CNS..143
 E  CNS..144
 E  CNS..146
 E  CNS..147
 E  CNS..148
 E  CNS..150
 E  CNS..153
 E  CNS..154
 E  CNS..155
 E  CNS..156
 E  CNS..158
 E  CNS..159
 E  CNS..160
 E  CNS..163
 E  CNS..164
 E  CNS..166
 E  CNS..167
 E  CNS..169
 E  CNS..170
 E  CNS..171
 E  CNS..172
 E  CNS..173
 E  CNS..174
 E  CNS..175
 E  CNS..176
 E  CNS..177
 E  CNS..179
 E  CNS..181
 E  CNS..184
 E  CNS..186
 E  CNS..188
 E  CNS..189
 E  CNS..190
 E  CNS..193
 E  CNS..195
 E  CNS..196
 E  CNS..197
 E  CNS..198
 E  CNS..200
 E  CNS..201
 E  CNS..203
 E  CNS..204
 E  CNS..205
 E  CNS..206
 E  CNS..208
 E  CNS..210
 E  CNS..212
 E  CNS..213
 E  CNS..214
 E  CNS..215
 E  CNS..216
 E  CNS..217
 E  CNS..219
 E  CNS..220
 E  CNS..222
 E  CNS..223
 E  CNS..224
 E  CNS..225
 E  CNS..228
 E  CNS..229
 E  CNS..231
 E  CNS..232
 E  CNS..233
 E  CNS..234
 E  CNS..235
 E  CNS..238
 E  CNS..239
 E  CNS..240
 E  CNS..241
 E  CNS..242
 E  CNS..243
 E  CNS..246
 E  CNS..247
 E  CNS..249
 E  CNS..250
 E  CNS..251
 E  CNS..254
 E  CNS..255
 E  CNS..256
 E  CNS..257
 E  CNS..258
 E  CNS..262
 E  CNS..264
 E  CNS..265
 E  CNS..266
 E  CNS..268
 E  CNS..271
 E  CNS..272
 E  CNS..273
 E  CNS..274
 E  CNS..277
 E  CNS..278
 E  CNS..279
 E  CNS..281
 E  CNS..283
 E  CNS..284
 E  CNS..285
 E  CNS..289
 E  CNS..290
 E  CNS..292
 E  CNS..296
 E  CNS..298
 E  CNS..300
 E  CNS..301
 E  CNS..302
 E  CNS..303
 E  CNS..305
 E  CNS..306
 E  CNS..308
 E  CNS..309
 E  CNS..311
 E  CNS..314
 E  CNS..315
 E  CNS..316
 E  CNS..320
 E  CNS..321
 E  CNS..326
 E  CNS..328
 E  CNS..330
 E  CNS..332
 E  CNS..335
 E  CNS..338
 E  CNS..339
 E  CNS..340
 E  CNS..341
 E  CNS..342
 E  CNS..345
 E  CNS..348
 E  CNS..350
 E  CNS..351
 E  CNS..353
 E  CNS..354
 E  CNS..355
 E  CNS..356
 E  CNS..357
 E  CNS..360
 E  CNS..361
 E  CNS..362
 E  CNS..363
 E  CNS..364
 E  CNS..366
 E  CNS..367
 E  CNS..369
 E  CNS..371
 E  CNS..372
 E  CNS..373
 E  CNS..375
 E  CNS..376
 E  CNS..377
 E  CNS..379
 E  CNS..381
 E  CNS..382
 E  CNS..383
 E  CNS..384
 E  CNS..385
 E  CNS..387
 E  CNS..388
 E  CNS..390
 E  CNS..392
 E  CNS..394
 E  CNS..396
 E  CNS..400
 E  CNS..401
 E  CNS..403
 E  CNS..405
 E  CNS..406
 E  CNS..409
 E  CNS..410
 E  CNS..412
 E  CNS..414
 E  CNS..416
 E  CNS..417
 E  CNS..418
 E  CNS..420
 E  CNS..425
 E  CNS..426
 E  CNS..427
 E  CNS..429
 E  CNS..430
 E  CNS..431
 E  CNS..434
 E  CNS..437
 E  CNS..438
 E  CNS..439
 E  CNS..443
 E  CNS..447
 E  CNS..448
 E  CNS..452
 E  CNS..454
 E  CNS..455
 E  CNS..458
 E  CNS..460
 E  CNS..464
 E  CNS..465
 E  CNS..466
 E  CNS..470
 E  CNS..471
 E  CNS..472
 E  CNS..473
 E  CNS..474
 E  CNS..475
 E  CNS..477
 E  CNS..478
 E  CNS..479
 E  CNS..480
 E  CNS..482
 E  CNS..483
 E  CNS..484
 E  CNS..485
 E  CNS..487
 E  CNS..488
 E  CNS..489
 E  CNS..491
 E  CNS..492
 E  CNS..494
 E  CNS..495
 E  CNS..496
 E  CNS..498
 E  CNS..499
 L  UC..0001
 L  UC..0002
 L  UC..0003
 L  UC..0004
 L  UC..0005
 L  UC..0006
 L  UC..0007
 L  UC..0008
 L  UC..0009
 L  UC..0010
 L  UC..0011
 L  UC..0012
 L  UC..0013
 L  UC..0014
 L  UC..0015
 L  UC..0016
 L  UC..0017
 L  UC..0018
 L  UC..0019
 L  UC..0020
 L  UC..0021
 L  UC..0022
 L  UC..0025
 L  UC..0026
 L  UC..0027
 L  UC..0028
 L  UC..0029
 L  UC..0030
 L  UC..0031
 L  UC..0032
 L  UC..0035
 L  UC..0036
 L  UC..0037
 L  UC..0038
 L  UC..0039
 L  UC..0040
 L  UC..0041
 L  UC..0042
 L  UC..0045
 L  UC..0046
 L  UC..0047
 L  UC..0048
 L  UC..0049
 L  UC..0050
 L  UC..0051
 L  UC..0052
 L  UC..0053
 L  UC..0054
 L  UC..0055
 L  UC..0056
 L  UC..0057
 L  UC..0058
 L  UC..0059
 L  UC..0060
 L  UC..0061
 L  UC..0062
 L  UC..0063
 L  UC..0064
 L  UC..0065
 L  UC..0066
 L  UC..0067
 L  UC..0068
 L  UC..0069
 L  UC..0070
 L  UC..0071
 L  UC..0072
 L  UC..0073
 L  UC..0074
 L  UC..0075
 L  UC..0076
 L  UC..0077
 L  UC..0078
 L  UC..0079
 L  UC..0080
 L  UC..0081
 L  UC..0082
 L  UC..0083
 L  UC..0084
 L  UC..0085
 L  UC..0086
 L  UC..0087
 L  UC..0088
 L  UC..0089
 L  UC..0090
 L  UC..0091
 L  UC..0092
 L  UC..0093
 L  UC..0094
 L  UC..0095
 L  UC..0096
 L  UC..0097
 L  UC..0098
 L  UC..0099
 L  UC..0100
 L  UC..0103
 L  UC..0104
 L  UC..0105
 L  UC..0106
 L  UC..0109
 L  UC..0110
 L  UC..0111
 L  UC..0112
 L  UC..0113
 L  UC..0114
 L  UC..0115
 L  UC..0116
 L  UC..0117
 L  UC..0118
 L  UC..0119
 L  UC..0120
 L  UC..0121
 L  UC..0122
 L  UC..0123
 L  UC..0124
 L  UC..0125
 L  UC..0126
 L  UC..0127
 L  UC..0128
 L  UC..0129
 L  UC..0130
 L  UC..0131
 L  UC..0132
 L  UC..0133
 L  UC..0134
 L  UC..0135
 L  UC..0136
 L  UC..0137
 L  UC..0138
 L  UC..0139
 L  UC..0140
 L  UC..0143
 L  UC..0144
 L  UC..0145
 L  UC..0146
 L  UC..0147
 L  UC..0148
 L  UC..0149
 L  UC..0150
 L  UC..0151
 L  UC..0152
 L  UC..0155
 L  UC..0156
 L  UC..0163
 L  UC..0164
 L  UC..0169
 L  UC..0170
 L  UC..0171
 L  UC..0172
 L  UC..0173
 L  UC..0174
 L  UC..0175
 L  UC..0176
 L  UC..0179
 L  UC..0180
 L  UC..0181
 L  UC..0182
 L  UC..0185
 L  UC..0186
 L  UC..0187
 L  UC..0188
 L  UC..0191
 L  UC..0192
 L  UC..0193
 L  UC..0194
 L  UC..0195
 L  UC..0196
 L  UC..0197
 L  UC..0198
 L  UC..0199
 L  UC..0200
 L  UC..0201
 L  UC..0202
 L  UC..0203
 L  UC..0204
 L  UC..0205
 L  UC..0206
 L  UC..0207
 L  UC..0208
 L  UC..0211
 L  UC..0212
 L  UC..0215
 L  UC..0216
 L  UC..0217
 L  UC..0218
 L  UC..0221
 L  UC..0222
 L  UC..0223
 L  UC..0224
 L  UC..0225
 L  UC..0226
 L  UC..0227
 L  UC..0228
 L  UC..0231
 L  UC..0232
 L  UC..0233
 L  UC..0234
 L  UC..0237
 L  UC..0238
 L  UC..0243
 L  UC..0244
 L  UC..0245
 L  UC..0246
 L  UC..0247
 L  UC..0248
 L  UC..0249
 L  UC..0250
 L  UC..0251
 L  UC..0252
 L  UC..0253
 L  UC..0254
 L  UC..0255
 L  UC..0256
 L  UC..0257
 L  UC..0258
 L  UC..0259
 L  UC..0260
 L  UC..0261
 L  UC..0262
 L  UC..0263
 L  UC..0264
 L  UC..0267
 L  UC..0268
 L  UC..0269
 L  UC..0270
 L  UC..0271
 L  UC..0272
 L  UC..0273
 L  UC..0274
 L  UC..0275
 L  UC..0276
 L  UC..0277
 L  UC..0278
 L  UC..0281
 L  UC..0282
 L  UC..0283
 L  UC..0284
 L  UC..0285
 L  UC..0286
 L  UC..0287
 L  UC..0288
 L  UC..0289
 L  UC..0290
 L  UC..0295
 L  UC..0296
 L  UC..0297
 L  UC..0298
 L  UC..0299
 L  UC..0300
 L  UC..0301
 L  UC..0302
 L  UC..0303
 L  UC..0304
 L  UC..0305
 L  UC..0306
 L  UC..0307
 L  UC..0308
 L  UC..0309
 L  UC..0310
 L  UC..0311
 L  UC..0312
 L  UC..0313
 L  UC..0314
 L  UC..0315
 L  UC..0316
 L  UC..0319
 L  UC..0320
 L  UC..0321
 L  UC..0322
 L  UC..0327
 L  UC..0328
 L  UC..0335
 L  UC..0336
 L  UC..0337
 L  UC..0338
 L  UC..0339
 L  UC..0340
 L  UC..0347
 L  UC..0348
 L  UC..0349
 L  UC..0350
 L  UC..0357
 L  UC..0358
 L  UC..0359
 L  UC..0360
 L  UC..0361
 L  UC..0362
 L  UC..0363
 L  UC..0364
 L  UC..0365
 L  UC..0366
 L  UC..0367
 L  UC..0368
 L  UC..0369
 L  UC..0370
 L  UC..0371
 L  UC..0372
 L  UC..0373
 L  UC..0374
 L  UC..0377
 L  UC..0378
 L  UC..0379
 L  UC..0380
 L  UC..0383
 L  UC..0384
 L  UC..0385
 L  UC..0386
 L  UC..0387
 L  UC..0388
 L  UC..0393
 L  UC..0394
 L  UC..0395
 L  UC..0396
 L  UC..0397
 L  UC..0398
 L  UC..0399
 L  UC..0400
 L  UC..0405
 L  UC..0406
 L  UC..0407
 L  UC..0408
 L  UC..0409
 L  UC..0410
 L  UC..0413
 L  UC..0414
 L  UC..0417
 L  UC..0418
 L  UC..0419
 L  UC..0420
 L  UC..0421
 L  UC..0422
 L  UC..0423
 L  UC..0424
 L  UC..0429
 L  UC..0430
 L  UC..0433
 L  UC..0434
 L  UC..0437
 L  UC..0438
 L  UC..0441
 L  UC..0442
 L  UC..0445
 L  UC..0446
 L  UC..0447
 L  UC..0448
 L  UC..0451
 L  UC..0452
 L  UC..0455
 L  UC..0456
 L  UC..0457
 L  UC..0458
 L  UC..0461
 L  UC..0462
 L  UC..0463
 L  UC..0464
 L  UC..0467
 L  UC..0468
 L  UC..0469
 L  UC..0470
 L  UC..0475
 L  UC..0476
 L  UC..0477
 L  UC..0478
 L  UC..0479
 L  UC..0480
 L  UC..0483
 L  UC..0484
 L  UC..0485
 L  UC..0486
 L  UC..0495
 L  UC..0496
 L  UC..0497
 L  UC..0498
 L  UC..0499
 L  UC..0500
 L  UC..0501
 L  UC..0502
 L  UC..0503
 L  UC..0504
 L  UC..0507
 L  UC..0508
 L  UC..0511
 L  UC..0512
 L  UC..0513
 L  UC..0514
 L  UC..0519
 L  UC..0520
 L  UC..0521
 L  UC..0522
 L  UC..0525
 L  UC..0526
 L  UC..0527
 L  UC..0528
 L  UC..0529
 L  UC..0530
 L  UC..0533
 L  UC..0534
 L  UC..0543
 L  UC..0544
 L  UC..0547
 L  UC..0548
 L  UC..0551
 L  UC..0552
 L  UC..0553
 L  UC..0554
 L  UC..0563
 L  UC..0564
 L  UC..0565
 L  UC..0566
 L  UC..0569
 L  UC..0570
 L  UC..0571
 L  UC..0572
 L  UC..0577
 L  UC..0578
 L  UC..0579
 L  UC..0580
 L  UC..0583
 L  UC..0584
 L  UC..0585
 L  UC..0586
 L  UC..0589
 L  UC..0590
 L  UC..0591
 L  UC..0592
 L  UC..0593
 L  UC..0594
 L  UC..0595
 L  UC..0596
 L  UC..0597
 L  UC..0598
 L  UC..0599
 L  UC..0600
 L  UC..0601
 L  UC..0602
 L  UC..0603
 L  UC..0604
 L  UC..0609
 L  UC..0610
 L  UC..0611
 L  UC..0612
 L  UC..0631
 L  UC..0632
 L  UC..0633
 L  UC..0634
 L  UC..0643
 L  UC..0644
 L  UC..0647
 L  UC..0648
 L  UC..0649
 L  UC..0650
 L  UC..0651
 L  UC..0652
 L  UC..0655
 L  UC..0656
 L  UC..0657
 L  UC..0658
 L  UC..0661
 L  UC..0662
 L  UC..0665
 L  UC..0666
 L  UC..0667
 L  UC..0668
 L  UC..0669
 L  UC..0670
 L  UC..0671
 L  UC..0672
 L  UC..0673
 L  UC..0674
 L  UC..0675
 L  UC..0676
 L  UC..0679
 L  UC..0680
 L  UC..0681
 L  UC..0682
 L  UC..0689
 L  UC..0690
 L  UC..0693
 L  UC..0694
 L  UC..0695
 L  UC..0696
 L  UC..0699
 L  UC..0700
 L  UC..0707
 L  UC..0708
 L  UC..0715
 L  UC..0716
 L  UC..0717
 L  UC..0718
 L  UC..0719
 L  UC..0720
 L  UC..0721
 L  UC..0722
 L  UC..0725
 L  UC..0726
 L  UC..0749
 L  UC..0750
 L  UC..0753
 L  UC..0754
 L  UC..0763
 L  UC..0764
 L  UC..0773
 L  UC..0774
 L  UC..0781
 L  UC..0782
 L  UC..0783
 L  UC..0784
 L  UC..0785
 L  UC..0786
 L  UC..0787
 L  UC..0788
 L  UC..0791
 L  UC..0792
 L  UC..0793
 L  UC..0794
 L  UC..0799
 L  UC..0800
 L  UC..0801
 L  UC..0802
 L  UC..0803
 L  UC..0804
 L  UC..0805
 L  UC..0806
 L  UC..0815
 L  UC..0816
 L  UC..0823
 L  UC..0824
 L  UC..0829
 L  UC..0830
 L  UC..0837
 L  UC..0838
 L  UC..0839
 L  UC..0840
 L  UC..0841
 L  UC..0842
 L  UC..0849
 L  UC..0850
 L  UC..0853
 L  UC..0854
 L  UC..0855
 L  UC..0856
 L  UC..0857
 L  UC..0858
 L  UC..0869
 L  UC..0870
 L  UC..0875
 L  UC..0876
 L  UC..0879
 L  UC..0880
 L  UC..0883
 L  UC..0884
 L  UC..0885
 L  UC..0886
 L  UC..0887
 L  UC..0888
 L  UC..0899
 L  UC..0900
 L  UC..0901
 L  UC..0902
 L  UC..0905
 L  UC..0906
 L  UC..0911
 L  UC..0912
 L  UC..0913
 L  UC..0914
 L  UC..0915
 L  UC..0916
 L  UC..0917
 L  UC..0918
 L  UC..0919
 L  UC..0920
 L  UC..0921
 L  UC..0922
 L  UC..0923
 L  UC..0924
 L  UC..0925
 L  UC..0926
 L  UC..0937
 L  UC..0938
 L  UC..0945
 L  UC..0946
 L  UC..0947
 L  UC..0948
 L  UC..0953
 L  UC..0954
 L  UC..0961
 L  UC..0962
 L  UC..0975
 L  UC..0976
 L  UC..0979
 L  UC..0980
 L  UC..0981
 L  UC..0982
 L  UC..0985
 L  UC..0986
 L  UC..0987
 L  UC..0988
 L  UC..0991
 L  UC..0992
 L  UC..0995
 L  UC..0996
 L  UC..0999
 L  UC..1000
 L  UC..1001
 L  UC..1002
 L  UC..1003
 L  UC..1004
 L  UC..1005
 L  UC..1006
 L  UC..1007
 L  UC..1008
 L  UC..1009
 L  UC..1010
 L  UC..1011
 L  UC..1012
 L  UC..1013
 L  UC..1014
 L  UC..1015
 L  UC..1016
 L  UC..1017
 L  UC..1018
 L  UC..1019
 L  UC..1020
 L  UC..1021
 L  UC..1022
 L  UC..1023
 L  UC..1024
 L  UC..1025
 L  UC..1026
 L  UC..1027
 L  UC..1028
 L  UC..1029
 L  UC..1030
 L  UC..1031
 L  UC..1032
 L  UC..1033
 L  UC..1034
 L  UC..1035
 L  UC..1036
 L  UC..1037
 L  UC..1038
 L  UC..1039
 L  UC..1040
 L  UC..1041
 L  UC..1042
 L  UC..1043
 L  UC..1044
 L  UC..1045
 L  UC..1046
 L  UC..1047
 L  UC..1048
 L  UC..1049
 L  UC..1050
 L  UC..1051
 L  UC..1052
 L  UC..1053
 L  UC..1054
 L  UC..1055
 L  UC..1056
 L  UC..1057
 L  UC..1058
 L  UC..1059
 L  UC..1060
 L  UC..1061
 L  UC..1062
 L  UC..1063
 L  UC..1064
 L  UC..1065
 L  UC..1066
 L  UC..1067
 L  UC..1068
 L  UC..1069
 L  UC..1070
 L  UC..1071
 L  UC..1072
 L  UC..1073
 L  UC..1074
 L  UC..1075
 L  UC..1076
 L  UC..1077
 L  UC..1078
 L  UC..1079
 L  UC..1080
 L  UC..1081
 L  UC..1082
 L  UC..1083
 L  UC..1084
 L  UC..1085
 L  UC..1086
 L  UC..1087
 L  UC..1088
 L  UC..1089
 L  UC..1090
 L  UC..1091
 L  UC..1092
 L  UC..1093
 L  UC..1094
 L  UC..1095
 L  UC..1096
 L  UC..1097
 L  UC..1098
 L  UC..1099
 L  UC..1100
 L  UC..1101
 L  UC..1102
 L  UC..1103
 L  UC..1104
 L  UC..1105
 L  UC..1106
 L  UC..1107
 L  UC..1108
 L  UC..1109
 L  UC..1110
 L  UC..1111
 L  UC..1112
 L  UC..1113
 L  UC..1114
 L  UC..1115
 L  UC..1116
 L  UC..1117
 L  UC..1118
 L  UC..1119
 L  UC..1120
 L  UC..1121
 L  UC..1122
 L  UC..1123
 L  UC..1124
 L  UC..1125
 L  UC..1126
 L  UC..1127
 L  UC..1128
 L  UC..1129
 L  UC..1130
 L  UC..1131
 L  UC..1132
 L  UC..1133
 L  UC..1134
 L  UC..1135
 L  UC..1136
 L  UC..1137
 L  UC..1138
 L  UC..1139
 L  UC..1140
 L  UC..1141
 L  UC..1142
 L  UC..1143
 L  UC..1144
 L  UC..1145
 L  UC..1146
 L  UC..1147
 L  UC..1148
 L  UC..1149
 L  UC..1150
 L  UC..1151
 L  UC..1152
 L  UC..1153
 L  UC..1154
 L  UC..1155
 L  UC..1156
 L  UC..1157
 L  UC..1158
 L  UC..1159
 L  UC..1160
 L  UC..1161
 L  UC..1162
 L  UC..1163
 L  UC..1164
 L  UC..1165
 L  UC..1166
 L  UC..1167
 L  UC..1168
 L  UC..1169
 L  UC..1170
 L  UC..1171
 L  UC..1172
 L  UC..1173
 L  UC..1174
 L  UC..1175
 L  UC..1176
 L  UC..1177
 L  UC..1178
 L  UC..1179
 L  UC..1180
 L  UC..1181
 L  UC..1182
 L  UC..1183
 L  UC..1184
 L  UC..1185
 L  UC..1186
 L  UC..1187
 L  UC..1188
 L  UC..1189
 L  UC..1190
 L  UC..1191
 L  UC..1192
 L  UC..1193
 L  UC..1194
 L  UC..1195
 L  UC..1196
 L  UC..1197
 L  UC..1198
 L  UC..1199
 L  UC..1200
 L  UC..1201
 L  UC..1202
 L  UC..1203
 L  UC..1204
 L  UC..1205
 L  UC..1206
 L  UC..1207
 L  UC..1208
 L  UC..1209
 L  UC..1210
 L  UC..1211
 L  UC..1212
 L  UC..1213
 L  UC..1214
 L  UC..1215
 L  UC..1216
 L  UC..1217
 L  UC..1218
 L  UC..1219
 L  UC..1220
 L  UC..1221
 L  UC..1222
 L  UC..1223
 L  UC..1224
 L  UC..1225
 L  UC..1226
 L  UC..1227
 L  UC..1228
 L  UC..1229
 L  UC..1230
 L  UC..1231
 L  UC..1232
 L  UC..1233
 L  UC..1234
 L  UC..1235
 L  UC..1236
 L  UC..1237
 L  UC..1238
 L  UC..1239
 L  UC..1240
 L  UC..1241
 L  UC..1242
 L  UC..1243
 L  UC..1244
 L  UC..1245
 L  UC..1246
 L  UC..1247
 L  UC..1248
 L  UC..1249
 L  UC..1250
 L  r_ekk0  
 L  r_ekk1  
 L  r_ekk2  
 L  r_ekk3  
 L  r_ekk4  
 L  r_ekk5  
 L  r_ekk6  
 L  r_ekk7  
 L  r_ekk8  
 L  r_ekk9  
 L  r_ekk10 
 L  r_ekk11 
 L  r_ekk12 
 L  r_ekk13 
 L  r_ekk14 
 L  r_ekk15 
 L  r_ekk16 
 L  r_ekk17 
 L  r_ekk18 
 L  r_ekk19 
 L  r_ekk20 
 L  r_ekk21 
 L  r_ekk22 
 L  r_ekk23 
 L  r_ekk24 
 L  r_ekk25 
 L  r_ekk26 
 L  r_ekk27 
 L  r_ekk28 
 L  r_ekk29 
 L  r_ekk30 
 L  r_ekk31 
 L  r_ekk32 
 L  r_ekk33 
 L  r_ekk34 
 L  r_ekk35 
 L  r_ekk36 
 L  r_ekk37 
 L  r_ekk38 
 L  r_ekk39 
 L  r_ekk40 
 L  r_ekk41 
 L  r_ekk42 
 L  r_ekk43 
 L  r_ekk44 
 L  r_ekk45 
 L  r_ekk46 
 L  r_ekk47 
 L  r_ekk48 
 L  r_ekk49 
 L  r_ekk50 
 L  r_ekk51 
 L  r_ekk52 
 L  r_ekk53 
 L  r_ekk54 
 L  r_ekk55 
 L  r_ekk56 
 L  r_ekk57 
 L  r_ekk58 
 L  r_ekk59 
 L  r_ekk60 
 L  r_ekk61 
 L  r_ekk62 
 L  r_ekk63 
 L  r_ekk64 
 L  r_ekk65 
 L  r_ekk66 
 L  r_ekk67 
 L  r_ekk68 
 L  r_ekk69 
 L  r_ekk70 
 L  r_ekk71 
 L  r_ekk72 
 L  r_ekk73 
 L  r_ekk74 
 L  r_ekk75 
 L  r_ekk76 
 L  r_ekk77 
 L  r_ekk78 
 L  r_ekk79 
 L  r_ekk80 
 L  r_ekk81 
 L  r_ekk82 
 L  r_ekk83 
 L  r_ekk84 
 L  r_ekk85 
 L  r_ekk86 
 L  r_ekk87 
 L  r_ekk88 
 L  r_ekk89 
 L  r_ekk90 
 L  r_ekk91 
 L  r_ekk92 
 L  r_ekk93 
 L  r_ekk94 
 L  r_ekk95 
 L  r_ekk96 
 L  r_ekk97 
 L  r_ekk98 
 L  r_ekk99 
 L  r_ekk100
 L  r_ekk101
 L  r_ekk102
 L  r_ekk103
 L  r_ekk104
 L  r_ekk105
 L  r_ekk106
 L  r_ekk107
 L  r_ekk108
 L  r_ekk109
 L  r_ekk110
 L  r_ekk111
 L  r_ekk112
 L  r_ekk113
 L  r_ekk114
 L  r_ekk115
 L  r_ekk116
 L  r_ekk117
 L  r_ekk118
 L  r_ekk119
 L  r_ekk120
 L  r_ekk121
 L  r_ekk122
 L  r_ekk123
 L  r_ekk124
 L  r_ekk125
 L  r_ekk126
 L  r_ekk127
 L  r_ekk128
 L  r_ekk129
 L  r_ekk130
 L  r_ekk131
 L  r_ekk132
 L  r_ekk133
 L  r_ekk134
 L  r_ekk135
 L  r_ekk136
 L  r_ekk137
 L  r_ekk138
 L  r_ekk139
 L  r_ekk140
 L  r_ekk141
 L  r_ekk142
 L  r_ekk143
 L  r_ekk144
 L  r_ekk145
 L  r_ekk146
 L  r_ekk147
 L  r_ekk148
 L  r_ekk149
 L  r_ekk150
 L  r_ekk151
 L  r_ekk152
 L  r_ekk153
 L  r_ekk154
 L  r_ekk155
 L  r_ekk156
 L  r_ekk157
 L  r_ekk158
 L  r_ekk159
 L  r_ekk160
 L  r_ekk161
 L  r_ekk162
 L  r_ekk163
 L  r_ekk164
 L  r_ekk165
 L  r_ekk166
 L  r_ekk167
 L  r_ekk168
 L  r_ekk169
 L  r_ekk170
 L  r_ekk171
 L  r_ekk172
 L  r_ekk173
 L  r_ekk174
 L  r_ekk175
 L  r_ekk176
 L  r_ekk177
 L  r_ekk178
 L  r_ekk179
 L  r_ekk180
 L  r_ekk181
 L  r_ekk182
 L  r_ekk183
 L  r_ekk184
 L  r_ekk185
 L  r_ekk186
 L  r_ekk187
 L  r_ekk188
 L  r_ekk189
 L  r_ekk190
 L  r_ekk191
 L  r_ekk192
 L  r_ekk193
 L  r_ekk194
 L  r_ekk195
 L  r_ekk196
 L  r_ekk197
 L  r_ekk198
 L  r_ekk199
 L  r_ekk200
 L  r_ekk201
 L  r_ekk202
 L  r_ekk203
 L  r_ekk204
 L  r_ekk205
 L  r_ekk206
 L  r_ekk207
 L  r_ekk208
 L  r_ekk209
 L  r_ekk210
 L  r_ekk211
 L  r_ekk212
 L  r_ekk213
 L  r_ekk214
 L  r_ekk215
 L  r_ekk216
 L  r_ekk217
 L  r_ekk218
 L  r_ekk219
 L  r_ekk220
 L  r_ekk221
 L  r_ekk222
 L  r_ekk223
 L  r_ekk224
 L  r_ekk225
 L  r_ekk226
 L  r_ekk227
 L  r_ekk228
 L  r_ekk229
 L  r_ekk230
 L  r_ekk231
 L  r_ekk232
 L  r_ekk233
 L  r_ekk234
 L  r_ekk235
 L  r_ekk236
 L  r_ekk237
 L  r_ekk238
 L  r_ekk239
 L  r_ekk240
 L  r_ekk241
 L  r_ekk242
 L  r_ekk243
 L  r_ekk244
 L  r_ekk245
 L  r_ekk246
 L  r_ekk247
 L  r_ekk248
 L  r_ekk249
 L  r_ekk250
 L  r_ekk251
 L  r_ekk252
 L  r_ekk253
 L  r_ekk254
 L  r_ekk255
 L  r_ekk256
 L  r_ekk257
 L  r_ekk258
 L  r_ekk259
 L  r_ekk260
 L  r_ekk261
 L  r_ekk262
 L  r_ekk263
 L  r_ekk264
 L  r_ekk265
 L  r_ekk266
 L  r_ekk267
 L  r_ekk268
 L  r_ekk269
 L  r_ekk270
 L  r_ekk271
 L  r_ekk272
 L  r_ekk273
 L  r_ekk274
 L  r_ekk275
 L  r_ekk276
 L  r_ekk277
 L  r_ekk278
 L  r_ekk279
 L  r_ekk280
 L  r_ekk281
 L  r_ekk282
 L  r_ekk283
 L  r_ekk284
 L  r_ekk285
 L  r_ekk286
 L  r_ekk287
 L  r_ekk288
 L  r_ekk289
 L  r_ekk290
 L  r_ekk291
 L  r_ekk292
 L  r_ekk293
 L  r_ekk294
 L  r_ekk295
 L  r_ekk296
 L  r_ekk297
 L  r_ekk298
 L  r_ekk299
 L  r_ekk300
 L  r_ekk301
 L  r_ekk302
 L  r_ekk303
 L  r_ekk304
 L  r_ekk305
 L  r_ekk306
 L  r_ekk307
 L  r_ekk308
 L  r_ekk309
 L  r_ekk310
 L  r_ekk311
 L  r_ekk312
 L  r_ekk313
 L  r_ekk314
 L  r_ekk315
 L  r_ekk316
 L  r_ekk317
 L  r_ekk318
 L  r_ekk319
 L  r_ekk320
 L  r_ekk321
 L  r_ekk322
 L  r_ekk323
 L  r_ekk324
 L  r_ekk325
 L  r_ekk326
 L  r_ekk327
 L  r_ekk328
 L  r_ekk329
 L  r_ekk330
 L  r_ekk331
 L  r_ekk332
 L  r_ekk333
 L  r_ekk334
 L  r_ekk335
 L  r_ekk336
 L  r_ekk337
 L  r_ekk338
 L  r_ekk339
 L  r_ekk340
 L  r_ekk341
 L  r_ekk342
 L  r_ekk343
 L  r_ekk344
 L  r_ekk345
 L  r_ekk346
 L  r_ekk347
 L  r_ekk348
 L  r_ekk349
 L  r_ekk350
 L  r_ekk351
 L  r_ekk352
 L  r_ekk353
 L  r_ekk354
 L  r_ekk355
 L  r_ekk356
 L  r_ekk357
 L  r_ekk358
 L  r_ekk359
 L  r_ekk360
 L  r_ekk361
 L  r_ekk362
 L  r_ekk363
 L  r_ekk364
 L  r_ekk365
 L  r_ekk366
 L  r_ekk367
 L  r_ekk368
 L  r_ekk369
 L  r_ekk370
 L  r_ekk371
 L  r_ekk372
 L  r_ekk373
 L  r_ekk374
 L  r_ekk375
 L  r_ekk376
 L  r_ekk377
 L  r_ekk378
 L  r_ekk379
 L  r_ekk380
 L  r_ekk381
 L  r_ekk382
 L  r_ekk383
 L  r_ekk384
 L  r_ekk385
 L  r_ekk386
 L  r_ekk387
 L  r_ekk388
 L  r_ekk389
 L  r_ekk390
 L  r_ekk391
 L  r_ekk392
 L  r_ekk393
 L  r_ekk394
 L  r_ekk395
 L  r_ekk396
 L  r_ekk397
 L  r_ekk398
 L  r_ekk399
 L  r_ekk400
 L  r_ekk401
 L  r_ekk402
 L  r_ekk403
 L  r_ekk404
 L  r_ekk405
 L  r_ekk406
 L  r_ekk407
 L  r_ekk408
 L  r_ekk409
 L  r_ekk410
 L  r_ekk411
 L  r_ekk412
 L  r_ekk413
 L  r_ekk414
 L  r_ekk415
 L  r_ekk416
 L  r_ekk417
 L  r_ekk418
 L  r_ekk419
 L  r_ekk420
 L  r_ekk421
 L  r_ekk422
 L  r_ekk423
 L  r_ekk424
 L  r_ekk425
 L  r_ekk426
 L  r_ekk427
 L  r_ekk428
 L  r_ekk429
 L  r_ekk430
 L  r_ekk431
 L  r_ekk432
 L  r_ekk433
COLUMNS
    x...0001  CNS..255  1
    x...0001  CNS..498  -1
    x...0001  UC..0001  1
    x...0002  CNS..255  -1
    x...0002  CNS..498  1
    x...0002  UC..0002  1
    x...0002  r_ekk321  -0.00810546875
    x...0003  CNS..264  -1
    x...0003  CNS..498  1
    x...0003  UC..0003  1
    x...0004  CNS..264  1
    x...0004  CNS..498  -1
    x...0004  UC..0004  1
    x...0005  CNS..381  -1
    x...0005  CNS..498  1
    x...0005  UC..0005  1
    x...0005  r_ekk364  -0.0101318359375
    x...0005  r_ekk365  -0.0101318359375
    x...0006  CNS..381  1
    x...0006  CNS..498  -1
    x...0006  UC..0006  1
    x...0006  r_ekk261  0.00810546875
    x...0006  r_ekk364  0.0101318359375
    x...0006  r_ekk433  0.0078125
    x...0007  CNS..193  1
    x...0007  CNS..264  -1
    x...0007  UC..0007  1
    x...0007  r_ekk312  0.00675455729166667
    x...0008  CNS..193  -1
    x...0008  CNS..264  1
    x...0008  UC..0008  1
    x...0009  CNS..255  1
    x...0009  CNS..278  -1
    x...0009  UC..0009  1
    x...0009  r_ekk433  -0.0078125
    x...0010  CNS..255  -1
    x...0010  CNS..278  1
    x...0010  UC..0010  1
    x...0010  r_ekk365  0.0101318359375
    x...0011  CNS..264  -1
    x...0011  CNS..271  1
    x...0011  UC..0011  1
    x...0011  r_ekk363  -0.25
    x...0012  CNS..264  1
    x...0012  CNS..271  -1
    x...0012  UC..0012  1
    x...0013  CNS..271  1
    x...0013  CNS..465  -1
    x...0013  UC..0013  1
    x...0013  r_ekk302  -0.125
    x...0014  CNS..271  -1
    x...0014  CNS..465  1
    x...0014  UC..0014  1
    x...0015  CNS..278  -1
    x...0015  CNS..281  1
    x...0015  UC..0015  1
    x...0016  CNS..278  1
    x...0016  CNS..281  -1
    x...0016  UC..0016  1
    x...0017  CNS..305  1
    x...0017  CNS..465  -1
    x...0017  UC..0017  1
    x...0018  CNS..305  -1
    x...0018  CNS..465  1
    x...0018  UC..0018  1
    x...0019  CNS..281  -1
    x...0019  CNS..354  1
    x...0019  UC..0019  1
    x...0020  CNS..281  1
    x...0020  CNS..354  -1
    x...0020  UC..0020  1
    x...0021  CNS..465  -1
    x...0021  CNS..496  1
    x...0021  UC..0021  1
    x...0022  CNS..465  1
    x...0022  CNS..496  -1
    x...0022  UC..0022  1
    x...0025  CNS..465  -1
    x...0025  CNS..466  1
    x...0025  UC..0025  1
    x...0026  CNS..465  1
    x...0026  CNS..466  -1
    x...0026  UC..0026  1
    x...0027  CNS..131  1
    x...0027  CNS..465  -1
    x...0027  UC..0027  1
    x...0028  CNS..131  -1
    x...0028  CNS..465  1
    x...0028  UC..0028  1
    x...0029  CNS..272  -1
    x...0029  CNS..381  1
    x...0029  UC..0029  1
    x...0030  CNS..272  1
    x...0030  CNS..381  -1
    x...0030  UC..0030  1
    x...0031  CNS..272  -1
    x...0031  CNS..418  1
    x...0031  UC..0031  1
    x...0032  CNS..272  1
    x...0032  CNS..418  -1
    x...0032  UC..0032  1
    x...0035  CNS..305  -1
    x...0035  CNS..492  1
    x...0035  UC..0035  1
    x...0036  CNS..305  1
    x...0036  CNS..492  -1
    x...0036  UC..0036  1
    x...0037  CNS..278  -1
    x...0037  CNS..340  1
    x...0037  UC..0037  1
    x...0038  CNS..278  1
    x...0038  CNS..340  -1
    x...0038  UC..0038  1
    x...0038  r_ekk226  0.00675455729166667
    x...0038  r_ekk237  -1
    x...0039  CNS..212  1
    x...0039  CNS..466  -1
    x...0039  UC..0039  1
    x...0040  CNS..212  -1
    x...0040  CNS..466  1
    x...0040  UC..0040  1
    x...0040  r_ekk400  -1
    x...0041  CNS..238  1
    x...0041  CNS..496  -1
    x...0041  UC..0041  1
    x...0041  r_ekk337  -0.780487804878049
    x...0042  CNS..238  -1
    x...0042  CNS..496  1
    x...0042  UC..0042  1
    x...0045  CNS..146  -1
    x...0045  CNS..340  1
    x...0045  UC..0045  1
    x...0046  CNS..146  1
    x...0046  CNS..340  -1
    x...0046  UC..0046  1
    x...0046  r_ekk339  -0.0975609756097561
    x...0047  CNS..141  1
    x...0047  CNS..418  -1
    x...0047  UC..0047  1
    x...0048  CNS..141  -1
    x...0048  CNS..418  1
    x...0048  UC..0048  1
    x...0049  CNS..348  -1
    x...0049  CNS..466  1
    x...0049  UC..0049  1
    x...0050  CNS..348  1
    x...0050  CNS..466  -1
    x...0050  UC..0050  1
    x...0051  CNS..306  1
    x...0051  CNS..348  -1
    x...0051  UC..0051  1
    x...0052  CNS..306  -1
    x...0052  CNS..348  1
    x...0052  UC..0052  1
    x...0053  CNS..271  1
    x...0053  CNS..425  -1
    x...0053  UC..0053  1
    x...0054  CNS..271  -1
    x...0054  CNS..425  1
    x...0054  UC..0054  1
    x...0055  CNS..156  -1
    x...0055  CNS..425  1
    x...0055  UC..0055  1
    x...0055  r_ekk166  0.00675455729166667
    x...0056  CNS..156  1
    x...0056  CNS..425  -1
    x...0056  UC..0056  1
    x...0057  CNS..272  -1
    x...0057  CNS..273  1
    x...0057  UC..0057  1
    x...0058  CNS..272  1
    x...0058  CNS..273  -1
    x...0058  UC..0058  1
    x...0059  CNS..366  -1
    x...0059  CNS..492  1
    x...0059  UC..0059  1
    x...0059  r_ekk270  -1
    x...0060  CNS..366  1
    x...0060  CNS..492  -1
    x...0060  UC..0060  1
    x...0061  CNS..212  -1
    x...0061  CNS..222  1
    x...0061  UC..0061  1
    x...0062  CNS..212  1
    x...0062  CNS..222  -1
    x...0062  UC..0062  1
    x...0063  CNS..090  -1
    x...0063  CNS..496  1
    x...0063  UC..0063  1
    x...0063  r_ekk419  -0.25
    x...0064  CNS..090  1
    x...0064  CNS..496  -1
    x...0064  UC..0064  1
    x...0065  CNS..232  -1
    x...0065  CNS..465  1
    x...0065  UC..0065  1
    x...0066  CNS..232  1
    x...0066  CNS..465  -1
    x...0066  UC..0066  1
    x...0066  r_ekk128  0.0121951219512195
    x...0067  CNS..091  -1
    x...0067  CNS..232  1
    x...0067  UC..0067  1
    x...0068  CNS..091  1
    x...0068  CNS..232  -1
    x...0068  UC..0068  1
    x...0069  CNS..091  -1
    x...0069  CNS..163  1
    x...0069  UC..0069  1
    x...0070  CNS..091  1
    x...0070  CNS..163  -1
    x...0070  UC..0070  1
    x...0071  CNS..224  -1
    x...0071  CNS..255  1
    x...0071  UC..0071  1
    x...0072  CNS..224  1
    x...0072  CNS..255  -1
    x...0072  UC..0072  1
    x...0073  CNS..491  1
    x...0073  CNS..498  -1
    x...0073  UC..0073  1
    x...0074  CNS..491  -1
    x...0074  CNS..498  1
    x...0074  UC..0074  1
    x...0074  r_ekk261  -0.00810546875
    x...0074  r_ekk318  -0.1296875
    x...0075  CNS..110  -1
    x...0075  CNS..305  1
    x...0075  UC..0075  1
    x...0076  CNS..110  1
    x...0076  CNS..305  -1
    x...0076  UC..0076  1
    x...0077  CNS..416  -1
    x...0077  CNS..418  1
    x...0077  UC..0077  1
    x...0078  CNS..416  1
    x...0078  CNS..418  -1
    x...0078  UC..0078  1
    x...0079  CNS..403  -1
    x...0079  CNS..418  1
    x...0079  UC..0079  1
    x...0080  CNS..403  1
    x...0080  CNS..418  -1
    x...0080  UC..0080  1
    x...0081  CNS..023  -1
    x...0081  CNS..498  1
    x...0081  UC..0081  1
    x...0082  CNS..023  1
    x...0082  CNS..498  -1
    x...0082  UC..0082  1
    x...0083  CNS..222  1
    x...0083  CNS..387  -1
    x...0083  UC..0083  1
    x...0084  CNS..222  -1
    x...0084  CNS..387  1
    x...0084  UC..0084  1
    x...0084  r_ekk312  -0.00675455729166667
    x...0084  r_ekk329  -0.108072916666667
    x...0084  r_ekk375  -0.25
    x...0085  CNS..108  1
    x...0085  CNS..306  -1
    x...0085  UC..0085  1
    x...0086  CNS..108  -1
    x...0086  CNS..306  1
    x...0086  UC..0086  1
    x...0087  CNS..201  -1
    x...0087  CNS..496  1
    x...0087  UC..0087  1
    x...0088  CNS..201  1
    x...0088  CNS..496  -1
    x...0088  UC..0088  1
    x...0088  r_ekk239  -1
    x...0089  CNS..306  -1
    x...0089  CNS..376  1
    x...0089  UC..0089  1
    x...0089  r_ekk322  -1
    x...0090  CNS..306  1
    x...0090  CNS..376  -1
    x...0090  UC..0090  1
    x...0091  CNS..489  -1
    x...0091  CNS..491  1
    x...0091  UC..0091  1
    x...0092  CNS..489  1
    x...0092  CNS..491  -1
    x...0092  UC..0092  1
    x...0092  r_ekk76   0.0078125
    x...0093  CNS..249  -1
    x...0093  CNS..496  1
    x...0093  UC..0093  1
    x...0094  CNS..249  1
    x...0094  CNS..496  -1
    x...0094  UC..0094  1
    x...0095  CNS..134  1
    x...0095  CNS..272  -1
    x...0095  UC..0095  1
    x...0096  CNS..134  -1
    x...0096  CNS..272  1
    x...0096  UC..0096  1
    x...0096  r_ekk238  -1
    x...0096  r_ekk432  -0.25
    x...0097  CNS..117  1
    x...0097  CNS..212  -1
    x...0097  UC..0097  1
    x...0097  r_ekk418  -1
    x...0098  CNS..117  -1
    x...0098  CNS..212  1
    x...0098  UC..0098  1
    x...0099  CNS..181  1
    x...0099  CNS..381  -1
    x...0099  UC..0099  1
    x...0100  CNS..181  -1
    x...0100  CNS..381  1
    x...0100  UC..0100  1
    x...0103  CNS..255  -1
    x...0103  CNS..482  1
    x...0103  UC..0103  1
    x...0103  r_ekk433  0.0078125
    x...0104  CNS..255  1
    x...0104  CNS..482  -1
    x...0104  UC..0104  1
    x...0105  CNS..117  1
    x...0105  CNS..203  -1
    x...0105  UC..0105  1
    x...0106  CNS..117  -1
    x...0106  CNS..203  1
    x...0106  UC..0106  1
    x...0106  r_ekk362  -0.25
    x...0109  CNS..366  -1
    x...0109  CNS..447  1
    x...0109  UC..0109  1
    x...0110  CNS..366  1
    x...0110  CNS..447  -1
    x...0110  UC..0110  1
    x...0111  CNS..164  1
    x...0111  CNS..387  -1
    x...0111  UC..0111  1
    x...0112  CNS..164  -1
    x...0112  CNS..387  1
    x...0112  UC..0112  1
    x...0113  CNS..110  -1
    x...0113  CNS..473  1
    x...0113  UC..0113  1
    x...0114  CNS..110  1
    x...0114  CNS..473  -1
    x...0114  UC..0114  1
    x...0115  CNS..238  1
    x...0115  CNS..355  -1
    x...0115  UC..0115  1
    x...0115  r_ekk142  -0.0975609756097561
    x...0116  CNS..238  -1
    x...0116  CNS..355  1
    x...0116  UC..0116  1
    x...0117  CNS..003  -1
    x...0117  CNS..348  1
    x...0117  UC..0117  1
    x...0118  CNS..003  1
    x...0118  CNS..348  -1
    x...0118  UC..0118  1
    x...0118  r_ekk198  0.0078125
    x...0119  CNS..013  -1
    x...0119  CNS..141  1
    x...0119  UC..0119  1
    x...0120  CNS..013  1
    x...0120  CNS..141  -1
    x...0120  UC..0120  1
    x...0121  CNS..048  -1
    x...0121  CNS..473  1
    x...0121  UC..0121  1
    x...0121  r_ekk356  -0.0078125
    x...0122  CNS..048  1
    x...0122  CNS..473  -1
    x...0122  UC..0122  1
    x...0122  r_ekk196  0.0101318359375
    x...0123  CNS..181  1
    x...0123  CNS..239  -1
    x...0123  UC..0123  1
    x...0123  r_ekk320  -0.25
    x...0124  CNS..181  -1
    x...0124  CNS..239  1
    x...0124  UC..0124  1
    x...0125  CNS..239  1
    x...0125  CNS..379  -1
    x...0125  UC..0125  1
    x...0125  r_ekk173  -0.5
    x...0126  CNS..239  -1
    x...0126  CNS..379  1
    x...0126  UC..0126  1
    x...0127  CNS..234  1
    x...0127  CNS..416  -1
    x...0127  UC..0127  1
    x...0128  CNS..234  -1
    x...0128  CNS..416  1
    x...0128  UC..0128  1
    x...0129  CNS..086  1
    x...0129  CNS..466  -1
    x...0129  UC..0129  1
    x...0130  CNS..086  -1
    x...0130  CNS..466  1
    x...0130  UC..0130  1
    x...0131  CNS..053  1
    x...0131  CNS..131  -1
    x...0131  UC..0131  1
    x...0131  r_ekk165  0.000150557061126167
    x...0131  r_ekk270  -1
    x...0132  CNS..053  -1
    x...0132  CNS..131  1
    x...0132  UC..0132  1
    x...0133  CNS..273  1
    x...0133  CNS..426  -1
    x...0133  UC..0133  1
    x...0134  CNS..273  -1
    x...0134  CNS..426  1
    x...0134  UC..0134  1
    x...0135  CNS..262  -1
    x...0135  CNS..447  1
    x...0135  UC..0135  1
    x...0136  CNS..262  1
    x...0136  CNS..447  -1
    x...0136  UC..0136  1
    x...0137  CNS..006  -1
    x...0137  CNS..156  1
    x...0137  UC..0137  1
    x...0137  r_ekk156  0.0078125
    x...0138  CNS..006  1
    x...0138  CNS..156  -1
    x...0138  UC..0138  1
    x...0139  CNS..012  1
    x...0139  CNS..023  -1
    x...0139  UC..0139  1
    x...0140  CNS..012  -1
    x...0140  CNS..023  1
    x...0140  UC..0140  1
    x...0143  CNS..222  -1
    x...0143  CNS..350  1
    x...0143  UC..0143  1
    x...0143  r_ekk415  -0.5
    x...0144  CNS..222  1
    x...0144  CNS..350  -1
    x...0144  UC..0144  1
    x...0145  CNS..376  -1
    x...0145  CNS..478  1
    x...0145  UC..0145  1
    x...0145  r_ekk385  -0.25
    x...0146  CNS..376  1
    x...0146  CNS..478  -1
    x...0146  UC..0146  1
    x...0147  CNS..203  1
    x...0147  CNS..388  -1
    x...0147  UC..0147  1
    x...0147  r_ekk430  -1
    x...0148  CNS..203  -1
    x...0148  CNS..388  1
    x...0148  UC..0148  1
    x...0149  CNS..043  1
    x...0149  CNS..478  -1
    x...0149  UC..0149  1
    x...0150  CNS..043  -1
    x...0150  CNS..478  1
    x...0150  UC..0150  1
    x...0150  r_ekk378  -0.25
    x...0151  CNS..133  1
    x...0151  CNS..156  -1
    x...0151  UC..0151  1
    x...0152  CNS..133  -1
    x...0152  CNS..156  1
    x...0152  UC..0152  1
    x...0155  CNS..087  1
    x...0155  CNS..496  -1
    x...0155  UC..0155  1
    x...0156  CNS..087  -1
    x...0156  CNS..496  1
    x...0156  UC..0156  1
    x...0163  CNS..171  1
    x...0163  CNS..492  -1
    x...0163  UC..0163  1
    x...0164  CNS..171  -1
    x...0164  CNS..492  1
    x...0164  UC..0164  1
    x...0169  CNS..238  -1
    x...0169  CNS..499  1
    x...0169  UC..0169  1
    x...0170  CNS..238  1
    x...0170  CNS..499  -1
    x...0170  UC..0170  1
    x...0170  r_ekk419  -0.25
    x...0170  r_ekk428  -0.125
    x...0171  CNS..132  1
    x...0171  CNS..281  -1
    x...0171  UC..0171  1
    x...0172  CNS..132  -1
    x...0172  CNS..281  1
    x...0172  UC..0172  1
    x...0173  CNS..234  1
    x...0173  CNS..471  -1
    x...0173  UC..0173  1
    x...0173  r_ekk231  -1
    x...0174  CNS..234  -1
    x...0174  CNS..471  1
    x...0174  UC..0174  1
    x...0175  CNS..129  1
    x...0175  CNS..376  -1
    x...0175  UC..0175  1
    x...0176  CNS..129  -1
    x...0176  CNS..376  1
    x...0176  UC..0176  1
    x...0179  CNS..340  1
    x...0179  CNS..373  -1
    x...0179  UC..0179  1
    x...0179  r_ekk202  -1
    x...0180  CNS..340  -1
    x...0180  CNS..373  1
    x...0180  UC..0180  1
    x...0181  CNS..006  1
    x...0181  CNS..320  -1
    x...0181  UC..0181  1
    x...0182  CNS..006  -1
    x...0182  CNS..320  1
    x...0182  UC..0182  1
    x...0185  CNS..478  1
    x...0185  CNS..495  -1
    x...0185  UC..0185  1
    x...0185  r_ekk404  -1
    x...0186  CNS..478  -1
    x...0186  CNS..495  1
    x...0186  UC..0186  1
    x...0187  CNS..172  -1
    x...0187  CNS..212  1
    x...0187  UC..0187  1
    x...0188  CNS..172  1
    x...0188  CNS..212  -1
    x...0188  UC..0188  1
    x...0191  CNS..475  -1
    x...0191  CNS..496  1
    x...0191  UC..0191  1
    x...0192  CNS..475  1
    x...0192  CNS..496  -1
    x...0192  UC..0192  1
    x...0193  CNS..364  1
    x...0193  CNS..425  -1
    x...0193  UC..0193  1
    x...0194  CNS..364  -1
    x...0194  CNS..425  1
    x...0194  UC..0194  1
    x...0195  CNS..184  1
    x...0195  CNS..234  -1
    x...0195  UC..0195  1
    x...0196  CNS..184  -1
    x...0196  CNS..234  1
    x...0196  UC..0196  1
    x...0197  CNS..039  -1
    x...0197  CNS..471  1
    x...0197  UC..0197  1
    x...0198  CNS..039  1
    x...0198  CNS..471  -1
    x...0198  UC..0198  1
    x...0199  CNS..117  1
    x...0199  CNS..390  -1
    x...0199  UC..0199  1
    x...0199  r_ekk347  -0.0078125
    x...0200  CNS..117  -1
    x...0200  CNS..390  1
    x...0200  UC..0200  1
    x...0201  CNS..005  1
    x...0201  CNS..388  -1
    x...0201  UC..0201  1
    x...0201  r_ekk347  0.0078125
    x...0202  CNS..005  -1
    x...0202  CNS..388  1
    x...0202  UC..0202  1
    x...0202  r_ekk347  -0.0078125
    x...0202  r_ekk351  -0.5
    x...0202  r_ekk362  -0.25
    x...0202  r_ekk420  -0.25
    x...0203  CNS..043  -1
    x...0203  CNS..420  1
    x...0203  UC..0203  1
    x...0204  CNS..043  1
    x...0204  CNS..420  -1
    x...0204  UC..0204  1
    x...0205  CNS..038  1
    x...0205  CNS..163  -1
    x...0205  UC..0205  1
    x...0205  r_ekk224  -0.390243902439024
    x...0205  r_ekk262  -0.0101318359375
    x...0206  CNS..038  -1
    x...0206  CNS..163  1
    x...0206  UC..0206  1
    x...0207  CNS..181  -1
    x...0207  CNS..241  1
    x...0207  UC..0207  1
    x...0207  r_ekk143  -0.5
    x...0208  CNS..181  1
    x...0208  CNS..241  -1
    x...0208  UC..0208  1
    x...0208  r_ekk195  0.0101318359375
    x...0211  CNS..195  1
    x...0211  CNS..222  -1
    x...0211  UC..0211  1
    x...0212  CNS..195  -1
    x...0212  CNS..222  1
    x...0212  UC..0212  1
    x...0215  CNS..091  1
    x...0215  CNS..242  -1
    x...0215  UC..0215  1
    x...0215  r_ekk164  -0.25
    x...0215  r_ekk200  -0.0078125
    x...0216  CNS..091  -1
    x...0216  CNS..242  1
    x...0216  UC..0216  1
    x...0216  r_ekk200  0.0078125
    x...0217  CNS..353  1
    x...0217  CNS..447  -1
    x...0217  UC..0217  1
    x...0218  CNS..353  -1
    x...0218  CNS..447  1
    x...0218  UC..0218  1
    x...0221  CNS..167  -1
    x...0221  CNS..353  1
    x...0221  UC..0221  1
    x...0222  CNS..167  1
    x...0222  CNS..353  -1
    x...0222  UC..0222  1
    x...0223  CNS..012  -1
    x...0223  CNS..479  1
    x...0223  UC..0223  1
    x...0224  CNS..012  1
    x...0224  CNS..479  -1
    x...0224  UC..0224  1
    x...0224  r_ekk230  -1
    x...0225  CNS..038  1
    x...0225  CNS..472  -1
    x...0225  UC..0225  1
    x...0225  r_ekk262  -0.0101318359375
    x...0226  CNS..038  -1
    x...0226  CNS..472  1
    x...0226  UC..0226  1
    x...0226  r_ekk262  0.0101318359375
    x...0227  CNS..005  -1
    x...0227  CNS..189  1
    x...0227  UC..0227  1
    x...0228  CNS..005  1
    x...0228  CNS..189  -1
    x...0228  UC..0228  1
    x...0231  CNS..116  1
    x...0231  CNS..133  -1
    x...0231  UC..0231  1
    x...0232  CNS..116  -1
    x...0232  CNS..133  1
    x...0232  UC..0232  1
    x...0233  CNS..031  1
    x...0233  CNS..086  -1
    x...0233  UC..0233  1
    x...0234  CNS..031  -1
    x...0234  CNS..086  1
    x...0234  UC..0234  1
    x...0237  CNS..203  1
    x...0237  CNS..308  -1
    x...0237  UC..0237  1
    x...0238  CNS..203  -1
    x...0238  CNS..308  1
    x...0238  UC..0238  1
    x...0243  CNS..163  -1
    x...0243  CNS..464  1
    x...0243  UC..0243  1
    x...0244  CNS..163  1
    x...0244  CNS..464  -1
    x...0244  UC..0244  1
    x...0245  CNS..335  -1
    x...0245  CNS..350  1
    x...0245  UC..0245  1
    x...0246  CNS..335  1
    x...0246  CNS..350  -1
    x...0246  UC..0246  1
    x...0246  r_ekk241  -1
    x...0247  CNS..082  -1
    x...0247  CNS..425  1
    x...0247  UC..0247  1
    x...0248  CNS..082  1
    x...0248  CNS..425  -1
    x...0248  UC..0248  1
    x...0249  CNS..289  1
    x...0249  CNS..366  -1
    x...0249  UC..0249  1
    x...0250  CNS..289  -1
    x...0250  CNS..366  1
    x...0250  UC..0250  1
    x...0251  CNS..249  1
    x...0251  CNS..369  -1
    x...0251  UC..0251  1
    x...0251  r_ekk419  -0.25
    x...0251  r_ekk428  -0.125
    x...0252  CNS..249  -1
    x...0252  CNS..369  1
    x...0252  UC..0252  1
    x...0253  CNS..175  -1
    x...0253  CNS..489  1
    x...0253  UC..0253  1
    x...0253  r_ekk165  -0.0121951219512195
    x...0253  r_ekk292  0.00675455729166667
    x...0254  CNS..175  1
    x...0254  CNS..489  -1
    x...0254  UC..0254  1
    x...0254  r_ekk321  0.00810546875
    x...0255  CNS..134  -1
    x...0255  CNS..488  1
    x...0255  UC..0255  1
    x...0256  CNS..134  1
    x...0256  CNS..488  -1
    x...0256  UC..0256  1
    x...0257  CNS..003  1
    x...0257  CNS..277  -1
    x...0257  UC..0257  1
    x...0258  CNS..003  -1
    x...0258  CNS..277  1
    x...0258  UC..0258  1
    x...0259  CNS..251  -1
    x...0259  CNS..262  1
    x...0259  UC..0259  1
    x...0260  CNS..251  1
    x...0260  CNS..262  -1
    x...0260  UC..0260  1
    x...0261  CNS..024  1
    x...0261  CNS..366  -1
    x...0261  UC..0261  1
    x...0262  CNS..024  -1
    x...0262  CNS..366  1
    x...0262  UC..0262  1
    x...0263  CNS..129  -1
    x...0263  CNS..144  1
    x...0263  UC..0263  1
    x...0264  CNS..129  1
    x...0264  CNS..144  -1
    x...0264  UC..0264  1
    x...0264  r_ekk300  -1
    x...0264  r_ekk304  -0.0078125
    x...0264  r_ekk396  -0.25
    x...0267  CNS..163  1
    x...0267  CNS..474  -1
    x...0267  UC..0267  1
    x...0267  r_ekk308  -0.25
    x...0268  CNS..163  -1
    x...0268  CNS..474  1
    x...0268  UC..0268  1
    x...0268  r_ekk227  0.00675455729166667
    x...0269  CNS..326  1
    x...0269  CNS..473  -1
    x...0269  UC..0269  1
    x...0269  r_ekk314  -1
    x...0270  CNS..326  -1
    x...0270  CNS..473  1
    x...0270  UC..0270  1
    x...0271  CNS..338  -1
    x...0271  CNS..369  1
    x...0271  UC..0271  1
    x...0272  CNS..338  1
    x...0272  CNS..369  -1
    x...0272  UC..0272  1
    x...0273  CNS..272  1
    x...0273  CNS..477  -1
    x...0273  UC..0273  1
    x...0273  r_ekk299  -1
    x...0274  CNS..272  -1
    x...0274  CNS..477  1
    x...0274  UC..0274  1
    x...0275  CNS..010  1
    x...0275  CNS..132  -1
    x...0275  UC..0275  1
    x...0276  CNS..010  -1
    x...0276  CNS..132  1
    x...0276  UC..0276  1
    x...0277  CNS..056  1
    x...0277  CNS..379  -1
    x...0277  UC..0277  1
    x...0278  CNS..056  -1
    x...0278  CNS..379  1
    x...0278  UC..0278  1
    x...0281  CNS..420  1
    x...0281  CNS..439  -1
    x...0281  UC..0281  1
    x...0282  CNS..420  -1
    x...0282  CNS..439  1
    x...0282  UC..0282  1
    x...0283  CNS..010  -1
    x...0283  CNS..188  1
    x...0283  UC..0283  1
    x...0283  r_ekk326  -1
    x...0283  r_ekk398  -1
    x...0284  CNS..010  1
    x...0284  CNS..188  -1
    x...0284  UC..0284  1
    x...0285  CNS..195  -1
    x...0285  CNS..351  1
    x...0285  UC..0285  1
    x...0286  CNS..195  1
    x...0286  CNS..351  -1
    x...0286  UC..0286  1
    x...0287  CNS..175  -1
    x...0287  CNS..357  1
    x...0287  UC..0287  1
    x...0287  r_ekk368  -0.5
    x...0288  CNS..175  1
    x...0288  CNS..357  -1
    x...0288  UC..0288  1
    x...0289  CNS..048  1
    x...0289  CNS..339  -1
    x...0289  UC..0289  1
    x...0290  CNS..048  -1
    x...0290  CNS..339  1
    x...0290  UC..0290  1
    x...0295  CNS..251  -1
    x...0295  CNS..480  1
    x...0295  UC..0295  1
    x...0295  r_ekk367  -1
    x...0296  CNS..251  1
    x...0296  CNS..480  -1
    x...0296  UC..0296  1
    x...0297  CNS..195  -1
    x...0297  CNS..206  1
    x...0297  UC..0297  1
    x...0298  CNS..195  1
    x...0298  CNS..206  -1
    x...0298  UC..0298  1
    x...0299  CNS..403  1
    x...0299  CNS..438  -1
    x...0299  UC..0299  1
    x...0300  CNS..403  -1
    x...0300  CNS..438  1
    x...0300  UC..0300  1
    x...0301  CNS..024  -1
    x...0301  CNS..098  1
    x...0301  UC..0301  1
    x...0301  r_ekk306  -0.5
    x...0302  CNS..024  1
    x...0302  CNS..098  -1
    x...0302  UC..0302  1
    x...0303  CNS..212  1
    x...0303  CNS..243  -1
    x...0303  UC..0303  1
    x...0304  CNS..212  -1
    x...0304  CNS..243  1
    x...0304  UC..0304  1
    x...0305  CNS..090  -1
    x...0305  CNS..233  1
    x...0305  UC..0305  1
    x...0306  CNS..090  1
    x...0306  CNS..233  -1
    x...0306  UC..0306  1
    x...0306  r_ekk366  -0.0101318359375
    x...0307  CNS..048  1
    x...0307  CNS..383  -1
    x...0307  UC..0307  1
    x...0307  r_ekk356  0.0078125
    x...0308  CNS..048  -1
    x...0308  CNS..383  1
    x...0308  UC..0308  1
    x...0308  r_ekk356  -0.0078125
    x...0308  r_ekk411  -0.390243902439024
    x...0309  CNS..277  1
    x...0309  CNS..434  -1
    x...0309  UC..0309  1
    x...0310  CNS..277  -1
    x...0310  CNS..434  1
    x...0310  UC..0310  1
    x...0310  r_ekk49   0.0078125
    x...0311  CNS..086  1
    x...0311  CNS..216  -1
    x...0311  UC..0311  1
    x...0312  CNS..086  -1
    x...0312  CNS..216  1
    x...0312  UC..0312  1
    x...0313  CNS..167  -1
    x...0313  CNS..246  1
    x...0313  UC..0313  1
    x...0313  r_ekk64   -0.5
    x...0314  CNS..167  1
    x...0314  CNS..246  -1
    x...0314  UC..0314  1
    x...0315  CNS..098  -1
    x...0315  CNS..314  1
    x...0315  UC..0315  1
    x...0316  CNS..098  1
    x...0316  CNS..314  -1
    x...0316  UC..0316  1
    x...0316  r_ekk387  -0.00675455729166667
    x...0319  CNS..250  1
    x...0319  CNS..278  -1
    x...0319  UC..0319  1
    x...0320  CNS..250  -1
    x...0320  CNS..278  1
    x...0320  UC..0320  1
    x...0321  CNS..348  -1
    x...0321  CNS..405  1
    x...0321  UC..0321  1
    x...0322  CNS..348  1
    x...0322  CNS..405  -1
    x...0322  UC..0322  1
    x...0327  CNS..016  -1
    x...0327  CNS..473  1
    x...0327  UC..0327  1
    x...0327  r_ekk369  -1
    x...0328  CNS..016  1
    x...0328  CNS..473  -1
    x...0328  UC..0328  1
    x...0335  CNS..364  -1
    x...0335  CNS..431  1
    x...0335  UC..0335  1
    x...0336  CNS..364  1
    x...0336  CNS..431  -1
    x...0336  UC..0336  1
    x...0337  CNS..069  -1
    x...0337  CNS..272  1
    x...0337  UC..0337  1
    x...0338  CNS..069  1
    x...0338  CNS..272  -1
    x...0338  UC..0338  1
    x...0339  CNS..013  1
    x...0339  CNS..154  -1
    x...0339  UC..0339  1
    x...0340  CNS..013  -1
    x...0340  CNS..154  1
    x...0340  UC..0340  1
    x...0347  CNS..108  1
    x...0347  CNS..142  -1
    x...0347  UC..0347  1
    x...0348  CNS..108  -1
    x...0348  CNS..142  1
    x...0348  UC..0348  1
    x...0349  CNS..083  -1
    x...0349  CNS..350  1
    x...0349  UC..0349  1
    x...0350  CNS..083  1
    x...0350  CNS..350  -1
    x...0350  UC..0350  1
    x...0350  r_ekk407  -0.25
    x...0357  CNS..158  -1
    x...0357  CNS..238  1
    x...0357  UC..0357  1
    x...0358  CNS..158  1
    x...0358  CNS..238  -1
    x...0358  UC..0358  1
    x...0359  CNS..090  -1
    x...0359  CNS..414  1
    x...0359  UC..0359  1
    x...0360  CNS..090  1
    x...0360  CNS..414  -1
    x...0360  UC..0360  1
    x...0361  CNS..170  1
    x...0361  CNS..272  -1
    x...0361  UC..0361  1
    x...0362  CNS..170  -1
    x...0362  CNS..272  1
    x...0362  UC..0362  1
    x...0363  CNS..155  1
    x...0363  CNS..314  -1
    x...0363  UC..0363  1
    x...0364  CNS..155  -1
    x...0364  CNS..314  1
    x...0364  UC..0364  1
    x...0365  CNS..383  1
    x...0365  CNS..437  -1
    x...0365  UC..0365  1
    x...0366  CNS..383  -1
    x...0366  CNS..437  1
    x...0366  UC..0366  1
    x...0366  r_ekk425  -0.25
    x...0367  CNS..367  1
    x...0367  CNS..478  -1
    x...0367  UC..0367  1
    x...0367  r_ekk304  0.0078125
    x...0367  r_ekk357  0.0121951219512195
    x...0368  CNS..367  -1
    x...0368  CNS..478  1
    x...0368  UC..0368  1
    x...0369  CNS..176  1
    x...0369  CNS..272  -1
    x...0369  UC..0369  1
    x...0370  CNS..176  -1
    x...0370  CNS..272  1
    x...0370  UC..0370  1
    x...0371  CNS..088  -1
    x...0371  CNS..387  1
    x...0371  UC..0371  1
    x...0372  CNS..088  1
    x...0372  CNS..387  -1
    x...0372  UC..0372  1
    x...0373  CNS..103  1
    x...0373  CNS..479  -1
    x...0373  UC..0373  1
    x...0373  r_ekk186  -0.5
    x...0374  CNS..103  -1
    x...0374  CNS..479  1
    x...0374  UC..0374  1
    x...0377  CNS..169  -1
    x...0377  CNS..335  1
    x...0377  UC..0377  1
    x...0377  r_ekk395  -1
    x...0377  r_ekk421  -0.5
    x...0378  CNS..169  1
    x...0378  CNS..335  -1
    x...0378  UC..0378  1
    x...0379  CNS..382  1
    x...0379  CNS..425  -1
    x...0379  UC..0379  1
    x...0379  r_ekk145  0.0101318359375
    x...0380  CNS..382  -1
    x...0380  CNS..425  1
    x...0380  UC..0380  1
    x...0383  CNS..047  1
    x...0383  CNS..163  -1
    x...0383  UC..0383  1
    x...0384  CNS..047  -1
    x...0384  CNS..163  1
    x...0384  UC..0384  1
    x...0385  CNS..158  -1
    x...0385  CNS..290  1
    x...0385  UC..0385  1
    x...0386  CNS..158  1
    x...0386  CNS..290  -1
    x...0386  UC..0386  1
    x...0387  CNS..372  1
    x...0387  CNS..414  -1
    x...0387  UC..0387  1
    x...0388  CNS..372  -1
    x...0388  CNS..414  1
    x...0388  UC..0388  1
    x...0393  CNS..363  -1
    x...0393  CNS..439  1
    x...0393  UC..0393  1
    x...0394  CNS..363  1
    x...0394  CNS..439  -1
    x...0394  UC..0394  1
    x...0395  CNS..023  -1
    x...0395  CNS..284  1
    x...0395  UC..0395  1
    x...0396  CNS..023  1
    x...0396  CNS..284  -1
    x...0396  UC..0396  1
    x...0397  CNS..031  1
    x...0397  CNS..092  -1
    x...0397  UC..0397  1
    x...0397  r_ekk339  -0.0975609756097561
    x...0398  CNS..031  -1
    x...0398  CNS..092  1
    x...0398  UC..0398  1
    x...0399  CNS..116  -1
    x...0399  CNS..140  1
    x...0399  UC..0399  1
    x...0399  r_ekk109  0.0101318359375
    x...0399  r_ekk166  0.00675455729166667
    x...0400  CNS..116  1
    x...0400  CNS..140  -1
    x...0400  UC..0400  1
    x...0405  CNS..290  -1
    x...0405  CNS..328  1
    x...0405  UC..0405  1
    x...0406  CNS..290  1
    x...0406  CNS..328  -1
    x...0406  UC..0406  1
    x...0407  CNS..254  1
    x...0407  CNS..388  -1
    x...0407  UC..0407  1
    x...0407  r_ekk341  -0.5
    x...0408  CNS..254  -1
    x...0408  CNS..388  1
    x...0408  UC..0408  1
    x...0409  CNS..301  -1
    x...0409  CNS..357  1
    x...0409  UC..0409  1
    x...0410  CNS..301  1
    x...0410  CNS..357  -1
    x...0410  UC..0410  1
    x...0410  r_ekk323  -1
    x...0413  CNS..121  -1
    x...0413  CNS..188  1
    x...0413  UC..0413  1
    x...0413  r_ekk335  -1
    x...0413  r_ekk398  -1
    x...0414  CNS..121  1
    x...0414  CNS..188  -1
    x...0414  UC..0414  1
    x...0417  CNS..390  1
    x...0417  CNS..458  -1
    x...0417  UC..0417  1
    x...0418  CNS..390  -1
    x...0418  CNS..458  1
    x...0418  UC..0418  1
    x...0419  CNS..141  -1
    x...0419  CNS..341  1
    x...0419  UC..0419  1
    x...0420  CNS..141  1
    x...0420  CNS..341  -1
    x...0420  UC..0420  1
    x...0421  CNS..009  1
    x...0421  CNS..016  -1
    x...0421  UC..0421  1
    x...0422  CNS..009  -1
    x...0422  CNS..016  1
    x...0422  UC..0422  1
    x...0422  r_ekk383  -0.5
    x...0423  CNS..116  1
    x...0423  CNS..377  -1
    x...0423  UC..0423  1
    x...0424  CNS..116  -1
    x...0424  CNS..377  1
    x...0424  UC..0424  1
    x...0429  CNS..228  -1
    x...0429  CNS..447  1
    x...0429  UC..0429  1
    x...0430  CNS..228  1
    x...0430  CNS..447  -1
    x...0430  UC..0430  1
    x...0433  CNS..292  -1
    x...0433  CNS..464  1
    x...0433  UC..0433  1
    x...0434  CNS..292  1
    x...0434  CNS..464  -1
    x...0434  UC..0434  1
    x...0437  CNS..081  -1
    x...0437  CNS..103  1
    x...0437  UC..0437  1
    x...0438  CNS..081  1
    x...0438  CNS..103  -1
    x...0438  UC..0438  1
    x...0438  r_ekk339  0.00243902439024389
    x...0441  CNS..167  1
    x...0441  CNS..303  -1
    x...0441  UC..0441  1
    x...0441  r_ekk235  -0.5
    x...0442  CNS..167  -1
    x...0442  CNS..303  1
    x...0442  UC..0442  1
    x...0445  CNS..392  1
    x...0445  CNS..416  -1
    x...0445  UC..0445  1
    x...0445  r_ekk390  -1
    x...0445  r_ekk397  -1
    x...0446  CNS..392  -1
    x...0446  CNS..416  1
    x...0446  UC..0446  1
    x...0447  CNS..255  -1
    x...0447  CNS..342  1
    x...0447  UC..0447  1
    x...0448  CNS..255  1
    x...0448  CNS..342  -1
    x...0448  UC..0448  1
    x...0448  r_ekk433  -0.0078125
    x...0451  CNS..036  -1
    x...0451  CNS..418  1
    x...0451  UC..0451  1
    x...0452  CNS..036  1
    x...0452  CNS..418  -1
    x...0452  UC..0452  1
    x...0455  CNS..074  -1
    x...0455  CNS..438  1
    x...0455  UC..0455  1
    x...0455  r_ekk354  -0.0078125
    x...0455  r_ekk399  -0.5
    x...0456  CNS..074  1
    x...0456  CNS..438  -1
    x...0456  UC..0456  1
    x...0457  CNS..357  1
    x...0457  CNS..443  -1
    x...0457  UC..0457  1
    x...0458  CNS..357  -1
    x...0458  CNS..443  1
    x...0458  UC..0458  1
    x...0458  r_ekk358  -0.5
    x...0461  CNS..200  -1
    x...0461  CNS..348  1
    x...0461  UC..0461  1
    x...0462  CNS..200  1
    x...0462  CNS..348  -1
    x...0462  UC..0462  1
    x...0463  CNS..073  -1
    x...0463  CNS..479  1
    x...0463  UC..0463  1
    x...0463  r_ekk293  -0.1296875
    x...0464  CNS..073  1
    x...0464  CNS..479  -1
    x...0464  UC..0464  1
    x...0467  CNS..250  1
    x...0467  CNS..455  -1
    x...0467  UC..0467  1
    x...0468  CNS..250  -1
    x...0468  CNS..455  1
    x...0468  UC..0468  1
    x...0469  CNS..170  1
    x...0469  CNS..315  -1
    x...0469  UC..0469  1
    x...0470  CNS..170  -1
    x...0470  CNS..315  1
    x...0470  UC..0470  1
    x...0475  CNS..181  1
    x...0475  CNS..311  -1
    x...0475  UC..0475  1
    x...0476  CNS..181  -1
    x...0476  CNS..311  1
    x...0476  UC..0476  1
    x...0477  CNS..118  -1
    x...0477  CNS..326  1
    x...0477  UC..0477  1
    x...0477  r_ekk48   0.0078125
    x...0477  r_ekk77   -0.0078125
    x...0478  CNS..118  1
    x...0478  CNS..326  -1
    x...0478  UC..0478  1
    x...0479  CNS..058  -1
    x...0479  CNS..193  1
    x...0479  UC..0479  1
    x...0480  CNS..058  1
    x...0480  CNS..193  -1
    x...0480  UC..0480  1
    x...0483  CNS..024  1
    x...0483  CNS..085  -1
    x...0483  UC..0483  1
    x...0484  CNS..024  -1
    x...0484  CNS..085  1
    x...0484  UC..0484  1
    x...0485  CNS..026  -1
    x...0485  CNS..170  1
    x...0485  UC..0485  1
    x...0486  CNS..026  1
    x...0486  CNS..170  -1
    x...0486  UC..0486  1
    x...0495  CNS..188  1
    x...0495  CNS..223  -1
    x...0495  UC..0495  1
    x...0496  CNS..188  -1
    x...0496  CNS..223  1
    x...0496  UC..0496  1
    x...0496  r_ekk378  -0.25
    x...0497  CNS..090  1
    x...0497  CNS..215  -1
    x...0497  UC..0497  1
    x...0497  r_ekk428  -0.125
    x...0498  CNS..090  -1
    x...0498  CNS..215  1
    x...0498  UC..0498  1
    x...0499  CNS..052  1
    x...0499  CNS..499  -1
    x...0499  UC..0499  1
    x...0500  CNS..052  -1
    x...0500  CNS..499  1
    x...0500  UC..0500  1
    x...0501  CNS..234  -1
    x...0501  CNS..487  1
    x...0501  UC..0501  1
    x...0502  CNS..234  1
    x...0502  CNS..487  -1
    x...0502  UC..0502  1
    x...0503  CNS..489  1
    x...0503  CNS..494  -1
    x...0503  UC..0503  1
    x...0504  CNS..489  -1
    x...0504  CNS..494  1
    x...0504  UC..0504  1
    x...0507  CNS..024  1
    x...0507  CNS..138  -1
    x...0507  UC..0507  1
    x...0507  r_ekk330  -0.0078125
    x...0508  CNS..024  -1
    x...0508  CNS..138  1
    x...0508  UC..0508  1
    x...0511  CNS..153  1
    x...0511  CNS..200  -1
    x...0511  UC..0511  1
    x...0512  CNS..153  -1
    x...0512  CNS..200  1
    x...0512  UC..0512  1
    x...0513  CNS..123  1
    x...0513  CNS..392  -1
    x...0513  UC..0513  1
    x...0513  r_ekk389  -1
    x...0513  r_ekk408  -1
    x...0514  CNS..123  -1
    x...0514  CNS..392  1
    x...0514  UC..0514  1
    x...0519  CNS..153  1
    x...0519  CNS..179  -1
    x...0519  UC..0519  1
    x...0520  CNS..153  -1
    x...0520  CNS..179  1
    x...0520  UC..0520  1
    x...0521  CNS..342  -1
    x...0521  CNS..409  1
    x...0521  UC..0521  1
    x...0522  CNS..342  1
    x...0522  CNS..409  -1
    x...0522  UC..0522  1
    x...0525  CNS..077  1
    x...0525  CNS..239  -1
    x...0525  UC..0525  1
    x...0526  CNS..077  -1
    x...0526  CNS..239  1
    x...0526  UC..0526  1
    x...0527  CNS..177  1
    x...0527  CNS..284  -1
    x...0527  UC..0527  1
    x...0528  CNS..177  -1
    x...0528  CNS..284  1
    x...0528  UC..0528  1
    x...0528  r_ekk121  -1
    x...0529  CNS..073  1
    x...0529  CNS..330  -1
    x...0529  UC..0529  1
    x...0530  CNS..073  -1
    x...0530  CNS..330  1
    x...0530  UC..0530  1
    x...0533  CNS..412  1
    x...0533  CNS..482  -1
    x...0533  UC..0533  1
    x...0534  CNS..412  -1
    x...0534  CNS..482  1
    x...0534  UC..0534  1
    x...0534  r_ekk283  -1
    x...0543  CNS..396  1
    x...0543  CNS..443  -1
    x...0543  UC..0543  1
    x...0544  CNS..396  -1
    x...0544  CNS..443  1
    x...0544  UC..0544  1
    x...0544  r_ekk355  -0.5
    x...0547  CNS..148  1
    x...0547  CNS..339  -1
    x...0547  UC..0547  1
    x...0548  CNS..148  -1
    x...0548  CNS..339  1
    x...0548  UC..0548  1
    x...0551  CNS..106  -1
    x...0551  CNS..167  1
    x...0551  UC..0551  1
    x...0552  CNS..106  1
    x...0552  CNS..167  -1
    x...0552  UC..0552  1
    x...0552  r_ekk319  -0.0101318359375
    x...0553  CNS..247  -1
    x...0553  CNS..434  1
    x...0553  UC..0553  1
    x...0554  CNS..247  1
    x...0554  CNS..434  -1
    x...0554  UC..0554  1
    x...0563  CNS..235  1
    x...0563  CNS..355  -1
    x...0563  UC..0563  1
    x...0564  CNS..235  -1
    x...0564  CNS..355  1
    x...0564  UC..0564  1
    x...0565  CNS..197  -1
    x...0565  CNS..420  1
    x...0565  UC..0565  1
    x...0566  CNS..197  1
    x...0566  CNS..420  -1
    x...0566  UC..0566  1
    x...0569  CNS..242  1
    x...0569  CNS..417  -1
    x...0569  UC..0569  1
    x...0570  CNS..242  -1
    x...0570  CNS..417  1
    x...0570  UC..0570  1
    x...0571  CNS..083  -1
    x...0571  CNS..279  1
    x...0571  UC..0571  1
    x...0572  CNS..083  1
    x...0572  CNS..279  -1
    x...0572  UC..0572  1
    x...0577  CNS..052  1
    x...0577  CNS..102  -1
    x...0577  UC..0577  1
    x...0578  CNS..052  -1
    x...0578  CNS..102  1
    x...0578  UC..0578  1
    x...0579  CNS..448  -1
    x...0579  CNS..480  1
    x...0579  UC..0579  1
    x...0580  CNS..448  1
    x...0580  CNS..480  -1
    x...0580  UC..0580  1
    x...0580  r_ekk377  -0.5
    x...0583  CNS..042  -1
    x...0583  CNS..340  1
    x...0583  UC..0583  1
    x...0584  CNS..042  1
    x...0584  CNS..340  -1
    x...0584  UC..0584  1
    x...0585  CNS..328  -1
    x...0585  CNS..485  1
    x...0585  UC..0585  1
    x...0586  CNS..328  1
    x...0586  CNS..485  -1
    x...0586  UC..0586  1
    x...0589  CNS..240  -1
    x...0589  CNS..412  1
    x...0589  UC..0589  1
    x...0589  r_ekk144  -0.0078125
    x...0590  CNS..240  1
    x...0590  CNS..412  -1
    x...0590  UC..0590  1
    x...0591  CNS..369  1
    x...0591  CNS..430  -1
    x...0591  UC..0591  1
    x...0591  r_ekk317  -1
    x...0592  CNS..369  -1
    x...0592  CNS..430  1
    x...0592  UC..0592  1
    x...0593  CNS..217  -1
    x...0593  CNS..301  1
    x...0593  UC..0593  1
    x...0594  CNS..217  1
    x...0594  CNS..301  -1
    x...0594  UC..0594  1
    x...0594  r_ekk346  -1
    x...0595  CNS..150  1
    x...0595  CNS..272  -1
    x...0595  UC..0595  1
    x...0596  CNS..150  -1
    x...0596  CNS..272  1
    x...0596  UC..0596  1
    x...0596  r_ekk350  -1
    x...0597  CNS..036  1
    x...0597  CNS..406  -1
    x...0597  UC..0597  1
    x...0598  CNS..036  -1
    x...0598  CNS..406  1
    x...0598  UC..0598  1
    x...0599  CNS..027  -1
    x...0599  CNS..132  1
    x...0599  UC..0599  1
    x...0599  r_ekk158  -0.5
    x...0600  CNS..027  1
    x...0600  CNS..132  -1
    x...0600  UC..0600  1
    x...0601  CNS..266  1
    x...0601  CNS..439  -1
    x...0601  UC..0601  1
    x...0601  r_ekk165  0.000150557061126167
    x...0602  CNS..266  -1
    x...0602  CNS..439  1
    x...0602  UC..0602  1
    x...0603  CNS..239  -1
    x...0603  CNS..371  1
    x...0603  UC..0603  1
    x...0603  r_ekk331  0.00865427652994792
    x...0604  CNS..239  1
    x...0604  CNS..371  -1
    x...0604  UC..0604  1
    x...0604  r_ekk303  -0.0101318359375
    x...0604  r_ekk330  -0.0078125
    x...0604  r_ekk331  -0.00865427652994792
    x...0609  CNS..216  -1
    x...0609  CNS..229  1
    x...0609  UC..0609  1
    x...0610  CNS..216  1
    x...0610  CNS..229  -1
    x...0610  UC..0610  1
    x...0610  r_ekk315  -1
    x...0610  r_ekk362  -0.25
    x...0611  CNS..002  1
    x...0611  CNS..074  -1
    x...0611  UC..0611  1
    x...0612  CNS..002  -1
    x...0612  CNS..074  1
    x...0612  UC..0612  1
    x...0612  r_ekk354  0.0078125
    x...0631  CNS..009  -1
    x...0631  CNS..231  1
    x...0631  UC..0631  1
    x...0631  r_ekk108  0.0101318359375
    x...0631  r_ekk263  0.0101318359375
    x...0632  CNS..009  1
    x...0632  CNS..231  -1
    x...0632  UC..0632  1
    x...0632  r_ekk263  -0.0101318359375
    x...0632  r_ekk332  -0.5
    x...0632  r_ekk356  -0.0078125
    x...0632  r_ekk391  -0.25
    x...0632  r_ekk426  -0.5
    x...0633  CNS..220  -1
    x...0633  CNS..235  1
    x...0633  UC..0633  1
    x...0634  CNS..220  1
    x...0634  CNS..235  -1
    x...0634  UC..0634  1
    x...0643  CNS..130  1
    x...0643  CNS..480  -1
    x...0643  UC..0643  1
    x...0643  r_ekk292  -0.00675455729166667
    x...0644  CNS..130  -1
    x...0644  CNS..480  1
    x...0644  UC..0644  1
    x...0647  CNS..186  -1
    x...0647  CNS..364  1
    x...0647  UC..0647  1
    x...0648  CNS..186  1
    x...0648  CNS..364  -1
    x...0648  UC..0648  1
    x...0649  CNS..087  -1
    x...0649  CNS..190  1
    x...0649  UC..0649  1
    x...0650  CNS..087  1
    x...0650  CNS..190  -1
    x...0650  UC..0650  1
    x...0651  CNS..084  -1
    x...0651  CNS..193  1
    x...0651  UC..0651  1
    x...0652  CNS..084  1
    x...0652  CNS..193  -1
    x...0652  UC..0652  1
    x...0652  r_ekk207  -1
    x...0655  CNS..059  -1
    x...0655  CNS..353  1
    x...0655  UC..0655  1
    x...0656  CNS..059  1
    x...0656  CNS..353  -1
    x...0656  UC..0656  1
    x...0657  CNS..184  -1
    x...0657  CNS..410  1
    x...0657  UC..0657  1
    x...0658  CNS..184  1
    x...0658  CNS..410  -1
    x...0658  UC..0658  1
    x...0661  CNS..083  1
    x...0661  CNS..166  -1
    x...0661  UC..0661  1
    x...0662  CNS..083  -1
    x...0662  CNS..166  1
    x...0662  UC..0662  1
    x...0662  r_ekk426  -0.5
    x...0665  CNS..106  1
    x...0665  CNS..296  -1
    x...0665  UC..0665  1
    x...0666  CNS..106  -1
    x...0666  CNS..296  1
    x...0666  UC..0666  1
    x...0666  r_ekk93   -1
    x...0667  CNS..020  -1
    x...0667  CNS..084  1
    x...0667  UC..0667  1
    x...0667  r_ekk207  -1
    x...0667  r_ekk234  -0.5
    x...0668  CNS..020  1
    x...0668  CNS..084  -1
    x...0668  UC..0668  1
    x...0669  CNS..240  -1
    x...0669  CNS..302  1
    x...0669  UC..0669  1
    x...0670  CNS..240  1
    x...0670  CNS..302  -1
    x...0670  UC..0670  1
    x...0670  r_ekk144  0.0078125
    x...0671  CNS..401  1
    x...0671  CNS..430  -1
    x...0671  UC..0671  1
    x...0672  CNS..401  -1
    x...0672  CNS..430  1
    x...0672  UC..0672  1
    x...0673  CNS..188  -1
    x...0673  CNS..285  1
    x...0673  UC..0673  1
    x...0674  CNS..188  1
    x...0674  CNS..285  -1
    x...0674  UC..0674  1
    x...0674  r_ekk385  -0.25
    x...0674  r_ekk422  -0.25
    x...0675  CNS..429  1
    x...0675  CNS..437  -1
    x...0675  UC..0675  1
    x...0676  CNS..429  -1
    x...0676  CNS..437  1
    x...0676  UC..0676  1
    x...0679  CNS..015  1
    x...0679  CNS..038  -1
    x...0679  UC..0679  1
    x...0679  r_ekk294  -1
    x...0680  CNS..015  -1
    x...0680  CNS..038  1
    x...0680  UC..0680  1
    x...0681  CNS..196  1
    x...0681  CNS..281  -1
    x...0681  UC..0681  1
    x...0682  CNS..196  -1
    x...0682  CNS..281  1
    x...0682  UC..0682  1
    x...0682  r_ekk137  -1
    x...0689  CNS..143  -1
    x...0689  CNS..148  1
    x...0689  UC..0689  1
    x...0690  CNS..143  1
    x...0690  CNS..148  -1
    x...0690  UC..0690  1
    x...0693  CNS..042  -1
    x...0693  CNS..427  1
    x...0693  UC..0693  1
    x...0694  CNS..042  1
    x...0694  CNS..427  -1
    x...0694  UC..0694  1
    x...0695  CNS..283  1
    x...0695  CNS..472  -1
    x...0695  UC..0695  1
    x...0696  CNS..283  -1
    x...0696  CNS..472  1
    x...0696  UC..0696  1
    x...0699  CNS..030  1
    x...0699  CNS..477  -1
    x...0699  UC..0699  1
    x...0700  CNS..030  -1
    x...0700  CNS..477  1
    x...0700  UC..0700  1
    x...0707  CNS..190  1
    x...0707  CNS..356  -1
    x...0707  UC..0707  1
    x...0708  CNS..190  -1
    x...0708  CNS..356  1
    x...0708  UC..0708  1
    x...0715  CNS..219  -1
    x...0715  CNS..231  1
    x...0715  UC..0715  1
    x...0716  CNS..219  1
    x...0716  CNS..231  -1
    x...0716  UC..0716  1
    x...0716  r_ekk263  -0.0101318359375
    x...0717  CNS..174  -1
    x...0717  CNS..496  1
    x...0717  UC..0717  1
    x...0718  CNS..174  1
    x...0718  CNS..496  -1
    x...0718  UC..0718  1
    x...0718  r_ekk161  -0.790123456790124
    x...0719  CNS..394  1
    x...0719  CNS..458  -1
    x...0719  UC..0719  1
    x...0720  CNS..394  -1
    x...0720  CNS..458  1
    x...0720  UC..0720  1
    x...0721  CNS..309  -1
    x...0721  CNS..437  1
    x...0721  UC..0721  1
    x...0721  r_ekk199  -0.0123456790123457
    x...0722  CNS..309  1
    x...0722  CNS..437  -1
    x...0722  UC..0722  1
    x...0722  r_ekk199  0.0123456790123457
    x...0722  r_ekk412  -0.5
    x...0725  CNS..213  -1
    x...0725  CNS..290  1
    x...0725  UC..0725  1
    x...0726  CNS..213  1
    x...0726  CNS..290  -1
    x...0726  UC..0726  1
    x...0749  CNS..214  1
    x...0749  CNS..217  -1
    x...0749  UC..0749  1
    x...0750  CNS..214  -1
    x...0750  CNS..217  1
    x...0750  UC..0750  1
    x...0753  CNS..033  -1
    x...0753  CNS..412  1
    x...0753  UC..0753  1
    x...0753  r_ekk147  -1
    x...0753  r_ekk165  -0.0121951219512195
    x...0754  CNS..033  1
    x...0754  CNS..412  -1
    x...0754  UC..0754  1
    x...0754  r_ekk165  0.0121951219512195
    x...0763  CNS..184  -1
    x...0763  CNS..375  1
    x...0763  UC..0763  1
    x...0764  CNS..184  1
    x...0764  CNS..375  -1
    x...0764  UC..0764  1
    x...0764  r_ekk57   -1
    x...0773  CNS..308  1
    x...0773  CNS..361  -1
    x...0773  UC..0773  1
    x...0774  CNS..308  -1
    x...0774  CNS..361  1
    x...0774  UC..0774  1
    x...0781  CNS..208  1
    x...0781  CNS..487  -1
    x...0781  UC..0781  1
    x...0782  CNS..208  -1
    x...0782  CNS..487  1
    x...0782  UC..0782  1
    x...0783  CNS..229  1
    x...0783  CNS..384  -1
    x...0783  UC..0783  1
    x...0784  CNS..229  -1
    x...0784  CNS..384  1
    x...0784  UC..0784  1
    x...0785  CNS..080  -1
    x...0785  CNS..492  1
    x...0785  UC..0785  1
    x...0786  CNS..080  1
    x...0786  CNS..492  -1
    x...0786  UC..0786  1
    x...0787  CNS..058  -1
    x...0787  CNS..256  1
    x...0787  UC..0787  1
    x...0788  CNS..058  1
    x...0788  CNS..256  -1
    x...0788  UC..0788  1
    x...0791  CNS..298  1
    x...0791  CNS..367  -1
    x...0791  UC..0791  1
    x...0791  r_ekk181  -1
    x...0792  CNS..298  -1
    x...0792  CNS..367  1
    x...0792  UC..0792  1
    x...0793  CNS..084  -1
    x...0793  CNS..484  1
    x...0793  UC..0793  1
    x...0794  CNS..084  1
    x...0794  CNS..484  -1
    x...0794  UC..0794  1
    x...0799  CNS..195  -1
    x...0799  CNS..258  1
    x...0799  UC..0799  1
    x...0799  r_ekk197  0.0121951219512195
    x...0800  CNS..195  1
    x...0800  CNS..258  -1
    x...0800  UC..0800  1
    x...0801  CNS..011  1
    x...0801  CNS..326  -1
    x...0801  UC..0801  1
    x...0802  CNS..011  -1
    x...0802  CNS..326  1
    x...0802  UC..0802  1
    x...0803  CNS..006  -1
    x...0803  CNS..136  1
    x...0803  UC..0803  1
    x...0804  CNS..006  1
    x...0804  CNS..136  -1
    x...0804  UC..0804  1
    x...0805  CNS..106  1
    x...0805  CNS..257  -1
    x...0805  UC..0805  1
    x...0805  r_ekk319  -0.0101318359375
    x...0805  r_ekk373  -1
    x...0806  CNS..106  -1
    x...0806  CNS..257  1
    x...0806  UC..0806  1
    x...0815  CNS..026  -1
    x...0815  CNS..045  1
    x...0815  UC..0815  1
    x...0816  CNS..026  1
    x...0816  CNS..045  -1
    x...0816  UC..0816  1
    x...0823  CNS..400  1
    x...0823  CNS..465  -1
    x...0823  UC..0823  1
    x...0824  CNS..400  -1
    x...0824  CNS..465  1
    x...0824  UC..0824  1
    x...0829  CNS..123  -1
    x...0829  CNS..126  1
    x...0829  UC..0829  1
    x...0830  CNS..123  1
    x...0830  CNS..126  -1
    x...0830  UC..0830  1
    x...0830  r_ekk382  -1
    x...0830  r_ekk389  -1
    x...0837  CNS..066  -1
    x...0837  CNS..328  1
    x...0837  UC..0837  1
    x...0838  CNS..066  1
    x...0838  CNS..328  -1
    x...0838  UC..0838  1
    x...0839  CNS..173  1
    x...0839  CNS..429  -1
    x...0839  UC..0839  1
    x...0840  CNS..173  -1
    x...0840  CNS..429  1
    x...0840  UC..0840  1
    x...0841  CNS..257  1
    x...0841  CNS..470  -1
    x...0841  UC..0841  1
    x...0842  CNS..257  -1
    x...0842  CNS..470  1
    x...0842  UC..0842  1
    x...0849  CNS..071  -1
    x...0849  CNS..405  1
    x...0849  UC..0849  1
    x...0850  CNS..071  1
    x...0850  CNS..405  -1
    x...0850  UC..0850  1
    x...0853  CNS..030  1
    x...0853  CNS..454  -1
    x...0853  UC..0853  1
    x...0854  CNS..030  -1
    x...0854  CNS..454  1
    x...0854  UC..0854  1
    x...0855  CNS..118  -1
    x...0855  CNS..300  1
    x...0855  UC..0855  1
    x...0856  CNS..118  1
    x...0856  CNS..300  -1
    x...0856  UC..0856  1
    x...0856  r_ekk77   0.0078125
    x...0857  CNS..120  1
    x...0857  CNS..320  -1
    x...0857  UC..0857  1
    x...0858  CNS..120  -1
    x...0858  CNS..320  1
    x...0858  UC..0858  1
    x...0869  CNS..072  -1
    x...0869  CNS..492  1
    x...0869  UC..0869  1
    x...0870  CNS..072  1
    x...0870  CNS..492  -1
    x...0870  UC..0870  1
    x...0875  CNS..186  1
    x...0875  CNS..360  -1
    x...0875  UC..0875  1
    x...0875  r_ekk387  0.00675455729166667
    x...0876  CNS..186  -1
    x...0876  CNS..360  1
    x...0876  UC..0876  1
    x...0876  r_ekk352  -0.25
    x...0879  CNS..198  -1
    x...0879  CNS..273  1
    x...0879  UC..0879  1
    x...0880  CNS..198  1
    x...0880  CNS..273  -1
    x...0880  UC..0880  1
    x...0883  CNS..002  1
    x...0883  CNS..321  -1
    x...0883  UC..0883  1
    x...0884  CNS..002  -1
    x...0884  CNS..321  1
    x...0884  UC..0884  1
    x...0884  r_ekk92   -1
    x...0885  CNS..143  -1
    x...0885  CNS..385  1
    x...0885  UC..0885  1
    x...0886  CNS..143  1
    x...0886  CNS..385  -1
    x...0886  UC..0886  1
    x...0887  CNS..160  1
    x...0887  CNS..279  -1
    x...0887  UC..0887  1
    x...0888  CNS..160  -1
    x...0888  CNS..279  1
    x...0888  UC..0888  1
    x...0899  CNS..080  -1
    x...0899  CNS..345  1
    x...0899  UC..0899  1
    x...0900  CNS..080  1
    x...0900  CNS..345  -1
    x...0900  UC..0900  1
    x...0901  CNS..143  1
    x...0901  CNS..452  -1
    x...0901  UC..0901  1
    x...0902  CNS..143  -1
    x...0902  CNS..452  1
    x...0902  UC..0902  1
    x...0905  CNS..147  -1
    x...0905  CNS..382  1
    x...0905  UC..0905  1
    x...0906  CNS..147  1
    x...0906  CNS..382  -1
    x...0906  UC..0906  1
    x...0911  CNS..212  1
    x...0911  CNS..316  -1
    x...0911  UC..0911  1
    x...0912  CNS..212  -1
    x...0912  CNS..316  1
    x...0912  UC..0912  1
    x...0913  CNS..160  -1
    x...0913  CNS..265  1
    x...0913  UC..0913  1
    x...0913  r_ekk78   -0.780487804878049
    x...0914  CNS..160  1
    x...0914  CNS..265  -1
    x...0914  UC..0914  1
    x...0915  CNS..210  -1
    x...0915  CNS..243  1
    x...0915  UC..0915  1
    x...0916  CNS..210  1
    x...0916  CNS..243  -1
    x...0916  UC..0916  1
    x...0917  CNS..268  1
    x...0917  CNS..425  -1
    x...0917  UC..0917  1
    x...0918  CNS..268  -1
    x...0918  CNS..425  1
    x...0918  UC..0918  1
    x...0918  r_ekk145  -0.0101318359375
    x...0919  CNS..085  1
    x...0919  CNS..332  -1
    x...0919  UC..0919  1
    x...0920  CNS..085  -1
    x...0920  CNS..332  1
    x...0920  UC..0920  1
    x...0921  CNS..135  -1
    x...0921  CNS..498  1
    x...0921  UC..0921  1
    x...0922  CNS..135  1
    x...0922  CNS..498  -1
    x...0922  UC..0922  1
    x...0923  CNS..007  1
    x...0923  CNS..015  -1
    x...0923  UC..0923  1
    x...0924  CNS..007  -1
    x...0924  CNS..015  1
    x...0924  UC..0924  1
    x...0925  CNS..170  1
    x...0925  CNS..225  -1
    x...0925  UC..0925  1
    x...0926  CNS..170  -1
    x...0926  CNS..225  1
    x...0926  UC..0926  1
    x...0937  CNS..172  1
    x...0937  CNS..460  -1
    x...0937  UC..0937  1
    x...0938  CNS..172  -1
    x...0938  CNS..460  1
    x...0938  UC..0938  1
    x...0945  CNS..040  1
    x...0945  CNS..123  -1
    x...0945  UC..0945  1
    x...0946  CNS..040  -1
    x...0946  CNS..123  1
    x...0946  UC..0946  1
    x...0946  r_ekk382  -1
    x...0946  r_ekk397  -1
    x...0947  CNS..204  1
    x...0947  CNS..438  -1
    x...0947  UC..0947  1
    x...0948  CNS..204  -1
    x...0948  CNS..438  1
    x...0948  UC..0948  1
    x...0953  CNS..065  1
    x...0953  CNS..155  -1
    x...0953  UC..0953  1
    x...0954  CNS..065  -1
    x...0954  CNS..155  1
    x...0954  UC..0954  1
    x...0961  CNS..159  -1
    x...0961  CNS..484  1
    x...0961  UC..0961  1
    x...0962  CNS..159  1
    x...0962  CNS..484  -1
    x...0962  UC..0962  1
    x...0975  CNS..274  -1
    x...0975  CNS..494  1
    x...0975  UC..0975  1
    x...0976  CNS..274  1
    x...0976  CNS..494  -1
    x...0976  UC..0976  1
    x...0979  CNS..206  1
    x...0979  CNS..483  -1
    x...0979  UC..0979  1
    x...0980  CNS..206  -1
    x...0980  CNS..483  1
    x...0980  UC..0980  1
    x...0981  CNS..109  1
    x...0981  CNS..414  -1
    x...0981  UC..0981  1
    x...0982  CNS..109  -1
    x...0982  CNS..414  1
    x...0982  UC..0982  1
    x...0982  r_ekk343  -1
    x...0982  r_ekk394  -0.5
    x...0985  CNS..020  -1
    x...0985  CNS..362  1
    x...0985  UC..0985  1
    x...0986  CNS..020  1
    x...0986  CNS..362  -1
    x...0986  UC..0986  1
    x...0987  CNS..174  1
    x...0987  CNS..205  -1
    x...0987  UC..0987  1
    x...0987  r_ekk50   -0.0078125
    x...0987  r_ekk264  -1
    x...0988  CNS..174  -1
    x...0988  CNS..205  1
    x...0988  UC..0988  1
    x...0988  r_ekk50   0.0078125
    x...0991  CNS..128  -1
    x...0991  CNS..335  1
    x...0991  UC..0991  1
    x...0991  r_ekk421  -0.5
    x...0992  CNS..128  1
    x...0992  CNS..335  -1
    x...0992  UC..0992  1
    x...0995  CNS..127  -1
    x...0995  CNS..303  1
    x...0995  UC..0995  1
    x...0996  CNS..127  1
    x...0996  CNS..303  -1
    x...0996  UC..0996  1
    x...0996  r_ekk134  -1
    x...0999  CNS..338  1
    x...0999  CNS..385  -1
    x...0999  UC..0999  1
    x...1000  CNS..338  -1
    x...1000  CNS..385  1
    x...1000  UC..1000  1
    x...1001  CNS..077  1
    x...1001  CNS..138  -1
    x...1001  UC..1001  1
    x...1002  CNS..077  -1
    x...1002  CNS..138  1
    x...1002  UC..1002  1
    x...1002  r_ekk303  0.0101318359375
    x...1002  r_ekk319  0.0101318359375
    x...1002  r_ekk330  0.0078125
    x...1002  r_ekk379  -0.25
    x...1002  r_ekk432  -0.25
    x...1003  CNS..216  1
    x...1003  CNS..427  -1
    x...1003  UC..1003  1
    x...1003  r_ekk307  -1
    x...1003  r_ekk420  -0.25
    x...1004  CNS..216  -1
    x...1004  CNS..427  1
    x...1004  UC..1004  1
    x...1005  CNS..081  1
    x...1005  CNS..203  -1
    x...1005  UC..1005  1
    x...1006  CNS..081  -1
    x...1006  CNS..203  1
    x...1006  UC..1006  1
    x...1006  r_ekk339  -0.1
    x...1006  r_ekk347  -0.0078125
    x...1006  r_ekk351  -0.5
    x...1007  CNS..179  1
    x...1007  CNS..488  -1
    x...1007  UC..1007  1
    x...1008  CNS..179  -1
    x...1008  CNS..488  1
    x...1008  UC..1008  1
    x...1009  CNS..400  -1
    x...1009  CNS..431  1
    x...1009  UC..1009  1
    x...1010  CNS..400  1
    x...1010  CNS..431  -1
    x...1010  UC..1010  1
    x...1010  r_ekk201  -1
    x...1011  CNS..121  -1
    x...1011  CNS..366  1
    x...1011  UC..1011  1
    x...1012  CNS..121  1
    x...1012  CNS..366  -1
    x...1012  UC..1012  1
    x...1013  CNS..027  1
    x...1013  CNS..219  -1
    x...1013  UC..1013  1
    x...1013  r_ekk204  -0.5
    x...1013  r_ekk213  -0.0121951219512195
    x...1014  CNS..027  -1
    x...1014  CNS..219  1
    x...1014  UC..1014  1
    x...1014  r_ekk213  0.0121951219512195
    x...1015  CNS..173  1
    x...1015  CNS..188  -1
    x...1015  UC..1015  1
    x...1016  CNS..173  -1
    x...1016  CNS..188  1
    x...1016  UC..1016  1
    x...1017  CNS..098  -1
    x...1017  CNS..360  1
    x...1017  UC..1017  1
    x...1017  r_ekk179  -0.780487804878049
    x...1018  CNS..098  1
    x...1018  CNS..360  -1
    x...1018  UC..1018  1
    x...1019  CNS..401  -1
    x...1019  CNS..406  1
    x...1019  UC..1019  1
    x...1020  CNS..401  1
    x...1020  CNS..406  -1
    x...1020  UC..1020  1
    x...1021  CNS..103  1
    x...1021  CNS..177  -1
    x...1021  UC..1021  1
    x...1022  CNS..103  -1
    x...1022  CNS..177  1
    x...1022  UC..1022  1
    x...1022  r_ekk236  -1
    x...1023  CNS..102  -1
    x...1023  CNS..292  1
    x...1023  UC..1023  1
    x...1024  CNS..102  1
    x...1024  CNS..292  -1
    x...1024  UC..1024  1
    x...1025  CNS..144  -1
    x...1025  CNS..465  1
    x...1025  UC..1025  1
    x...1026  CNS..144  1
    x...1026  CNS..465  -1
    x...1026  UC..1026  1
    x...1027  CNS..043  1
    x...1027  CNS..321  -1
    x...1027  UC..1027  1
    x...1027  r_ekk304  -0.0078125
    x...1027  r_ekk396  -0.25
    x...1028  CNS..043  -1
    x...1028  CNS..321  1
    x...1028  UC..1028  1
    x...1029  CNS..205  -1
    x...1029  CNS..281  1
    x...1029  UC..1029  1
    x...1029  r_ekk150  -1
    x...1030  CNS..205  1
    x...1030  CNS..281  -1
    x...1030  UC..1030  1
    x...1030  r_ekk142  0.00120445648900933
    x...1031  CNS..198  -1
    x...1031  CNS..208  1
    x...1031  UC..1031  1
    x...1032  CNS..198  1
    x...1032  CNS..208  -1
    x...1032  UC..1032  1
    x...1033  CNS..241  -1
    x...1033  CNS..246  1
    x...1033  UC..1033  1
    x...1033  r_ekk310  -1
    x...1034  CNS..241  1
    x...1034  CNS..246  -1
    x...1034  UC..1034  1
    x...1035  CNS..098  -1
    x...1035  CNS..210  1
    x...1035  UC..1035  1
    x...1036  CNS..098  1
    x...1036  CNS..210  -1
    x...1036  UC..1036  1
    x...1036  r_ekk387  -0.00675455729166667
    x...1036  r_ekk432  -0.25
    x...1037  CNS..345  1
    x...1037  CNS..470  -1
    x...1037  UC..1037  1
    x...1038  CNS..345  -1
    x...1038  CNS..470  1
    x...1038  UC..1038  1
    x...1038  r_ekk155  -0.780487804878049
    x...1039  CNS..039  1
    x...1039  CNS..353  -1
    x...1039  UC..1039  1
    x...1040  CNS..039  -1
    x...1040  CNS..353  1
    x...1040  UC..1040  1
    x...1041  CNS..256  -1
    x...1041  CNS..464  1
    x...1041  UC..1041  1
    x...1042  CNS..256  1
    x...1042  CNS..464  -1
    x...1042  UC..1042  1
    x...1043  CNS..361  -1
    x...1043  CNS..364  1
    x...1043  UC..1043  1
    x...1044  CNS..361  1
    x...1044  CNS..364  -1
    x...1044  UC..1044  1
    x...1045  CNS..065  1
    x...1045  CNS..390  -1
    x...1045  UC..1045  1
    x...1046  CNS..065  -1
    x...1046  CNS..390  1
    x...1046  UC..1046  1
    x...1046  r_ekk372  -0.5
    x...1047  CNS..126  -1
    x...1047  CNS..220  1
    x...1047  UC..1047  1
    x...1048  CNS..126  1
    x...1048  CNS..220  -1
    x...1048  UC..1048  1
    x...1048  r_ekk182  -1
    x...1049  CNS..088  -1
    x...1049  CNS..120  1
    x...1049  UC..1049  1
    x...1050  CNS..088  1
    x...1050  CNS..120  -1
    x...1050  UC..1050  1
    x...1051  CNS..146  -1
    x...1051  CNS..390  1
    x...1051  UC..1051  1
    x...1052  CNS..146  1
    x...1052  CNS..390  -1
    x...1052  UC..1052  1
    x...1053  CNS..056  -1
    x...1053  CNS..268  1
    x...1053  UC..1053  1
    x...1054  CNS..056  1
    x...1054  CNS..268  -1
    x...1054  UC..1054  1
    x...1055  CNS..069  -1
    x...1055  CNS..273  1
    x...1055  UC..1055  1
    x...1056  CNS..069  1
    x...1056  CNS..273  -1
    x...1056  UC..1056  1
    x...1057  CNS..071  -1
    x...1057  CNS..308  1
    x...1057  UC..1057  1
    x...1058  CNS..071  1
    x...1058  CNS..308  -1
    x...1058  UC..1058  1
    x...1059  CNS..231  -1
    x...1059  CNS..377  1
    x...1059  UC..1059  1
    x...1060  CNS..231  1
    x...1060  CNS..377  -1
    x...1060  UC..1060  1
    x...1060  r_ekk263  0.0101318359375
    x...1061  CNS..204  -1
    x...1061  CNS..448  1
    x...1061  UC..1061  1
    x...1062  CNS..204  1
    x...1062  CNS..448  -1
    x...1062  UC..1062  1
    x...1062  r_ekk265  -1
    x...1063  CNS..376  1
    x...1063  CNS..484  -1
    x...1063  UC..1063  1
    x...1064  CNS..376  -1
    x...1064  CNS..484  1
    x...1064  UC..1064  1
    x...1065  CNS..033  1
    x...1065  CNS..478  -1
    x...1065  UC..1065  1
    x...1066  CNS..033  -1
    x...1066  CNS..478  1
    x...1066  UC..1066  1
    x...1067  CNS..013  -1
    x...1067  CNS..320  1
    x...1067  UC..1067  1
    x...1068  CNS..013  1
    x...1068  CNS..320  -1
    x...1068  UC..1068  1
    x...1069  CNS..005  -1
    x...1069  CNS..081  1
    x...1069  UC..1069  1
    x...1069  r_ekk339  0.0024390243902439
    x...1070  CNS..005  1
    x...1070  CNS..081  -1
    x...1070  UC..1070  1
    x...1071  CNS..176  -1
    x...1071  CNS..315  1
    x...1071  UC..1071  1
    x...1072  CNS..176  1
    x...1072  CNS..315  -1
    x...1072  UC..1072  1
    x...1073  CNS..005  -1
    x...1073  CNS..040  1
    x...1073  UC..1073  1
    x...1074  CNS..005  1
    x...1074  CNS..040  -1
    x...1074  UC..1074  1
    x...1074  r_ekk431  -0.25
    x...1075  CNS..127  -1
    x...1075  CNS..298  1
    x...1075  UC..1075  1
    x...1075  r_ekk113  -1
    x...1076  CNS..127  1
    x...1076  CNS..298  -1
    x...1076  UC..1076  1
    x...1077  CNS..130  1
    x...1077  CNS..396  -1
    x...1077  UC..1077  1
    x...1077  r_ekk371  -0.25
    x...1078  CNS..130  -1
    x...1078  CNS..396  1
    x...1078  UC..1078  1
    x...1079  CNS..309  1
    x...1079  CNS..373  -1
    x...1079  UC..1079  1
    x...1080  CNS..309  -1
    x...1080  CNS..373  1
    x...1080  UC..1080  1
    x...1080  r_ekk232  -1
    x...1081  CNS..116  -1
    x...1081  CNS..355  1
    x...1081  UC..1081  1
    x...1082  CNS..116  1
    x...1082  CNS..355  -1
    x...1082  UC..1082  1
    x...1083  CNS..454  1
    x...1083  CNS..455  -1
    x...1083  UC..1083  1
    x...1084  CNS..454  -1
    x...1084  CNS..455  1
    x...1084  UC..1084  1
    x...1085  CNS..073  1
    x...1085  CNS..296  -1
    x...1085  UC..1085  1
    x...1085  r_ekk54   -0.780487804878049
    x...1085  r_ekk225  -0.00810546875
    x...1085  r_ekk271  -0.00810546875
    x...1086  CNS..073  -1
    x...1086  CNS..296  1
    x...1086  UC..1086  1
    x...1086  r_ekk225  0.00810546875
    x...1086  r_ekk271  0.00810546875
    x...1087  CNS..284  -1
    x...1087  CNS..472  1
    x...1087  UC..1087  1
    x...1088  CNS..284  1
    x...1088  CNS..472  -1
    x...1088  UC..1088  1
    x...1089  CNS..290  1
    x...1089  CNS..491  -1
    x...1089  UC..1089  1
    x...1090  CNS..290  -1
    x...1090  CNS..491  1
    x...1090  UC..1090  1
    x...1091  CNS..193  1
    x...1091  CNS..215  -1
    x...1091  UC..1091  1
    x...1091  r_ekk234  -0.5
    x...1092  CNS..193  -1
    x...1092  CNS..215  1
    x...1092  UC..1092  1
    x...1093  CNS..271  -1
    x...1093  CNS..387  1
    x...1093  UC..1093  1
    x...1094  CNS..271  1
    x...1094  CNS..387  -1
    x...1094  UC..1094  1
    x...1095  CNS..080  -1
    x...1095  CNS..229  1
    x...1095  UC..1095  1
    x...1096  CNS..080  1
    x...1096  CNS..229  -1
    x...1096  UC..1096  1
    x...1097  CNS..247  1
    x...1097  CNS..371  -1
    x...1097  UC..1097  1
    x...1098  CNS..247  -1
    x...1098  CNS..371  1
    x...1098  UC..1098  1
    x...1099  CNS..086  -1
    x...1099  CNS..254  1
    x...1099  UC..1099  1
    x...1100  CNS..086  1
    x...1100  CNS..254  -1
    x...1100  UC..1100  1
    x...1100  r_ekk400  -1
    x...1101  CNS..154  -1
    x...1101  CNS..460  1
    x...1101  UC..1101  1
    x...1102  CNS..154  1
    x...1102  CNS..460  -1
    x...1102  UC..1102  1
    x...1103  CNS..308  1
    x...1103  CNS..354  -1
    x...1103  UC..1103  1
    x...1104  CNS..308  -1
    x...1104  CNS..354  1
    x...1104  UC..1104  1
    x...1105  CNS..166  -1
    x...1105  CNS..473  1
    x...1105  UC..1105  1
    x...1105  r_ekk332  -0.5
    x...1106  CNS..166  1
    x...1106  CNS..473  -1
    x...1106  UC..1106  1
    x...1107  CNS..084  -1
    x...1107  CNS..472  1
    x...1107  UC..1107  1
    x...1108  CNS..084  1
    x...1108  CNS..472  -1
    x...1108  UC..1108  1
    x...1108  r_ekk234  -0.5
    x...1109  CNS..264  1
    x...1109  CNS..363  -1
    x...1109  UC..1109  1
    x...1110  CNS..264  -1
    x...1110  CNS..363  1
    x...1110  UC..1110  1
    x...1111  CNS..117  -1
    x...1111  CNS..285  1
    x...1111  UC..1111  1
    x...1111  r_ekk398  -1
    x...1112  CNS..117  1
    x...1112  CNS..285  -1
    x...1112  UC..1112  1
    x...1113  CNS..053  -1
    x...1113  CNS..265  1
    x...1113  UC..1113  1
    x...1114  CNS..053  1
    x...1114  CNS..265  -1
    x...1114  UC..1114  1
    x...1115  CNS..210  -1
    x...1115  CNS..417  1
    x...1115  UC..1115  1
    x...1116  CNS..210  1
    x...1116  CNS..417  -1
    x...1116  UC..1116  1
    x...1117  CNS..011  1
    x...1117  CNS..235  -1
    x...1117  UC..1117  1
    x...1118  CNS..011  -1
    x...1118  CNS..235  1
    x...1118  UC..1118  1
    x...1119  CNS..136  -1
    x...1119  CNS..197  1
    x...1119  UC..1119  1
    x...1120  CNS..136  1
    x...1120  CNS..197  -1
    x...1120  UC..1120  1
    x...1121  CNS..007  -1
    x...1121  CNS..147  1
    x...1121  UC..1121  1
    x...1122  CNS..007  1
    x...1122  CNS..147  -1
    x...1122  UC..1122  1
    x...1123  CNS..148  1
    x...1123  CNS..256  -1
    x...1123  UC..1123  1
    x...1124  CNS..148  -1
    x...1124  CNS..256  1
    x...1124  UC..1124  1
    x...1125  CNS..410  1
    x...1125  CNS..438  -1
    x...1125  UC..1125  1
    x...1126  CNS..410  -1
    x...1126  CNS..438  1
    x...1126  UC..1126  1
    x...1127  CNS..228  1
    x...1127  CNS..342  -1
    x...1127  UC..1127  1
    x...1128  CNS..228  -1
    x...1128  CNS..342  1
    x...1128  UC..1128  1
    x...1128  r_ekk214  -0.00810546875
    x...1129  CNS..214  1
    x...1129  CNS..417  -1
    x...1129  UC..1129  1
    x...1129  r_ekk313  -0.5
    x...1130  CNS..214  -1
    x...1130  CNS..417  1
    x...1130  UC..1130  1
    x...1131  CNS..033  -1
    x...1131  CNS..223  1
    x...1131  UC..1131  1
    x...1132  CNS..033  1
    x...1132  CNS..223  -1
    x...1132  UC..1132  1
    x...1132  r_ekk304  -0.0078125
    x...1133  CNS..225  1
    x...1133  CNS..345  -1
    x...1133  UC..1133  1
    x...1134  CNS..225  -1
    x...1134  CNS..345  1
    x...1134  UC..1134  1
    x...1134  r_ekk259  -0.780487804878049
    x...1135  CNS..091  -1
    x...1135  CNS..246  1
    x...1135  UC..1135  1
    x...1136  CNS..091  1
    x...1136  CNS..246  -1
    x...1136  UC..1136  1
    x...1137  CNS..289  1
    x...1137  CNS..474  -1
    x...1137  UC..1137  1
    x...1138  CNS..289  -1
    x...1138  CNS..474  1
    x...1138  UC..1138  1
    x...1139  CNS..082  1
    x...1139  CNS..354  -1
    x...1139  UC..1139  1
    x...1140  CNS..082  -1
    x...1140  CNS..354  1
    x...1140  UC..1140  1
    x...1141  CNS..224  -1
    x...1141  CNS..274  1
    x...1141  UC..1141  1
    x...1142  CNS..224  1
    x...1142  CNS..274  -1
    x...1142  UC..1142  1
    x...1142  r_ekk152  -1
    x...1142  r_ekk433  -0.0078125
    x...1143  CNS..189  1
    x...1143  CNS..316  -1
    x...1143  UC..1143  1
    x...1144  CNS..189  -1
    x...1144  CNS..316  1
    x...1144  UC..1144  1
    x...1145  CNS..302  1
    x...1145  CNS..341  -1
    x...1145  UC..1145  1
    x...1146  CNS..302  -1
    x...1146  CNS..341  1
    x...1146  UC..1146  1
    x...1147  CNS..006  1
    x...1147  CNS..348  -1
    x...1147  UC..1147  1
    x...1148  CNS..006  -1
    x...1148  CNS..348  1
    x...1148  UC..1148  1
    x...1149  CNS..003  -1
    x...1149  CNS..475  1
    x...1149  UC..1149  1
    x...1149  r_ekk178  0.0101318359375
    x...1149  r_ekk198  -0.0078125
    x...1150  CNS..003  1
    x...1150  CNS..475  -1
    x...1150  UC..1150  1
    x...1151  CNS..038  1
    x...1151  CNS..066  -1
    x...1151  UC..1151  1
    x...1151  r_ekk110  -0.0121951219512195
    x...1152  CNS..038  -1
    x...1152  CNS..066  1
    x...1152  UC..1152  1
    x...1152  r_ekk110  0.0121951219512195
    x...1153  CNS..197  1
    x...1153  CNS..384  -1
    x...1153  UC..1153  1
    x...1154  CNS..197  -1
    x...1154  CNS..384  1
    x...1154  UC..1154  1
    x...1155  CNS..092  1
    x...1155  CNS..300  -1
    x...1155  UC..1155  1
    x...1156  CNS..092  -1
    x...1156  CNS..300  1
    x...1156  UC..1156  1
    x...1156  r_ekk380  -0.125
    x...1157  CNS..072  -1
    x...1157  CNS..224  1
    x...1157  UC..1157  1
    x...1157  r_ekk281  -0.25
    x...1158  CNS..072  1
    x...1158  CNS..224  -1
    x...1158  UC..1158  1
    x...1158  r_ekk214  0.00810546875
    x...1159  CNS..196  -1
    x...1159  CNS..383  1
    x...1159  UC..1159  1
    x...1160  CNS..196  1
    x...1160  CNS..383  -1
    x...1160  UC..1160  1
    x...1161  CNS..059  1
    x...1161  CNS..246  -1
    x...1161  UC..1161  1
    x...1162  CNS..059  -1
    x...1162  CNS..246  1
    x...1162  UC..1162  1
    x...1162  r_ekk195  -0.0101318359375
    x...1163  CNS..311  1
    x...1163  CNS..362  -1
    x...1163  UC..1163  1
    x...1163  r_ekk303  -0.0101318359375
    x...1163  r_ekk319  -0.0101318359375
    x...1163  r_ekk320  -0.25
    x...1163  r_ekk330  -0.0078125
    x...1163  r_ekk331  -0.00865427652994792
    x...1163  r_ekk424  -1
    x...1164  CNS..311  -1
    x...1164  CNS..362  1
    x...1164  UC..1164  1
    x...1165  CNS..135  1
    x...1165  CNS..142  -1
    x...1165  UC..1165  1
    x...1166  CNS..135  -1
    x...1166  CNS..142  1
    x...1166  UC..1166  1
    x...1167  CNS..164  -1
    x...1167  CNS..332  1
    x...1167  UC..1167  1
    x...1168  CNS..164  1
    x...1168  CNS..332  -1
    x...1168  UC..1168  1
    x...1169  CNS..164  1
    x...1169  CNS..201  -1
    x...1169  UC..1169  1
    x...1170  CNS..164  -1
    x...1170  CNS..201  1
    x...1170  UC..1170  1
    x...1170  r_ekk309  -0.125
    x...1170  r_ekk366  -0.0101318359375
    x...1170  r_ekk370  -0.25
    x...1170  r_ekk376  -0.0078125
    x...1170  r_ekk428  -0.125
    x...1171  CNS..265  -1
    x...1171  CNS..266  1
    x...1171  UC..1171  1
    x...1172  CNS..265  1
    x...1172  CNS..266  -1
    x...1172  UC..1172  1
    x...1172  r_ekk131  -1
    x...1173  CNS..128  1
    x...1173  CNS..369  -1
    x...1173  UC..1173  1
    x...1173  r_ekk311  -1
    x...1174  CNS..128  -1
    x...1174  CNS..369  1
    x...1174  UC..1174  1
    x...1175  CNS..117  -1
    x...1175  CNS..384  1
    x...1175  UC..1175  1
    x...1176  CNS..117  1
    x...1176  CNS..384  -1
    x...1176  UC..1176  1
    x...1177  CNS..040  1
    x...1177  CNS..169  -1
    x...1177  UC..1177  1
    x...1178  CNS..040  -1
    x...1178  CNS..169  1
    x...1178  UC..1178  1
    x...1179  CNS..159  1
    x...1179  CNS..464  -1
    x...1179  UC..1179  1
    x...1180  CNS..159  -1
    x...1180  CNS..464  1
    x...1180  UC..1180  1
    x...1181  CNS..002  -1
    x...1181  CNS..474  1
    x...1181  UC..1181  1
    x...1182  CNS..002  1
    x...1182  CNS..474  -1
    x...1182  UC..1182  1
    x...1183  CNS..351  1
    x...1183  CNS..434  -1
    x...1183  UC..1183  1
    x...1184  CNS..351  -1
    x...1184  CNS..434  1
    x...1184  UC..1184  1
    x...1185  CNS..163  1
    x...1185  CNS..258  -1
    x...1185  UC..1185  1
    x...1186  CNS..163  -1
    x...1186  CNS..258  1
    x...1186  UC..1186  1
    x...1187  CNS..012  -1
    x...1187  CNS..036  1
    x...1187  UC..1187  1
    x...1188  CNS..012  1
    x...1188  CNS..036  -1
    x...1188  UC..1188  1
    x...1188  r_ekk271  -0.00810546875
    x...1189  CNS..416  1
    x...1189  CNS..454  -1
    x...1189  UC..1189  1
    x...1190  CNS..416  -1
    x...1190  CNS..454  1
    x...1190  UC..1190  1
    x...1191  CNS..271  -1
    x...1191  CNS..300  1
    x...1191  UC..1191  1
    x...1192  CNS..271  1
    x...1192  CNS..300  -1
    x...1192  UC..1192  1
    x...1192  r_ekk405  -0.125
    x...1193  CNS..135  -1
    x...1193  CNS..379  1
    x...1193  UC..1193  1
    x...1194  CNS..135  1
    x...1194  CNS..379  -1
    x...1194  UC..1194  1
    x...1195  CNS..406  -1
    x...1195  CNS..495  1
    x...1195  UC..1195  1
    x...1196  CNS..406  1
    x...1196  CNS..495  -1
    x...1196  UC..1196  1
    x...1197  CNS..362  1
    x...1197  CNS..366  -1
    x...1197  UC..1197  1
    x...1198  CNS..362  -1
    x...1198  CNS..366  1
    x...1198  UC..1198  1
    x...1199  CNS..090  1
    x...1199  CNS..283  -1
    x...1199  UC..1199  1
    x...1199  r_ekk309  -0.125
    x...1199  r_ekk376  -0.0078125
    x...1200  CNS..090  -1
    x...1200  CNS..283  1
    x...1200  UC..1200  1
    x...1200  r_ekk366  0.0101318359375
    x...1200  r_ekk376  0.0078125
    x...1201  CNS..372  1
    x...1201  CNS..474  -1
    x...1201  UC..1201  1
    x...1202  CNS..372  -1
    x...1202  CNS..474  1
    x...1202  UC..1202  1
    x...1203  CNS..189  1
    x...1203  CNS..214  -1
    x...1203  UC..1203  1
    x...1204  CNS..189  -1
    x...1204  CNS..214  1
    x...1204  UC..1204  1
    x...1205  CNS..030  -1
    x...1205  CNS..213  1
    x...1205  UC..1205  1
    x...1206  CNS..030  1
    x...1206  CNS..213  -1
    x...1206  UC..1206  1
    x...1207  CNS..098  1
    x...1207  CNS..150  -1
    x...1207  UC..1207  1
    x...1208  CNS..098  -1
    x...1208  CNS..150  1
    x...1208  UC..1208  1
    x...1209  CNS..426  1
    x...1209  CNS..452  -1
    x...1209  UC..1209  1
    x...1210  CNS..426  -1
    x...1210  CNS..452  1
    x...1210  UC..1210  1
    x...1211  CNS..146  -1
    x...1211  CNS..375  1
    x...1211  UC..1211  1
    x...1212  CNS..146  1
    x...1212  CNS..375  -1
    x...1212  UC..1212  1
    x...1212  r_ekk339  0.00120445648900933
    x...1213  CNS..341  1
    x...1213  CNS..483  -1
    x...1213  UC..1213  1
    x...1214  CNS..341  -1
    x...1214  CNS..483  1
    x...1214  UC..1214  1
    x...1215  CNS..108  1
    x...1215  CNS..164  -1
    x...1215  UC..1215  1
    x...1216  CNS..108  -1
    x...1216  CNS..164  1
    x...1216  UC..1216  1
    x...1217  CNS..405  1
    x...1217  CNS..488  -1
    x...1217  UC..1217  1
    x...1218  CNS..405  -1
    x...1218  CNS..488  1
    x...1218  UC..1218  1
    x...1219  CNS..009  -1
    x...1219  CNS..140  1
    x...1219  UC..1219  1
    x...1220  CNS..009  1
    x...1220  CNS..140  -1
    x...1220  UC..1220  1
    x...1220  r_ekk251  0.0101318359375
    x...1221  CNS..045  -1
    x...1221  CNS..348  1
    x...1221  UC..1221  1
    x...1222  CNS..045  1
    x...1222  CNS..348  -1
    x...1222  UC..1222  1
    x...1223  CNS..373  -1
    x...1223  CNS..403  1
    x...1223  UC..1223  1
    x...1224  CNS..373  1
    x...1224  CNS..403  -1
    x...1224  UC..1224  1
    x...1225  CNS..254  -1
    x...1225  CNS..394  1
    x...1225  UC..1225  1
    x...1226  CNS..254  1
    x...1226  CNS..394  -1
    x...1226  UC..1226  1
    x...1227  CNS..106  -1
    x...1227  CNS..371  1
    x...1227  UC..1227  1
    x...1228  CNS..106  1
    x...1228  CNS..371  -1
    x...1228  UC..1228  1
    x...1229  CNS..330  -1
    x...1229  CNS..392  1
    x...1229  UC..1229  1
    x...1229  r_ekk382  -1
    x...1229  r_ekk390  -1
    x...1230  CNS..330  1
    x...1230  CNS..392  -1
    x...1230  UC..1230  1
    x...1231  CNS..047  -1
    x...1231  CNS..257  1
    x...1231  UC..1231  1
    x...1232  CNS..047  1
    x...1232  CNS..257  -1
    x...1232  UC..1232  1
    x...1233  CNS..233  -1
    x...1233  CNS..278  1
    x...1233  UC..1233  1
    x...1234  CNS..233  1
    x...1234  CNS..278  -1
    x...1234  UC..1234  1
    x...1234  r_ekk394  -0.5
    x...1234  r_ekk428  -0.125
    x...1235  CNS..109  1
    x...1235  CNS..292  -1
    x...1235  UC..1235  1
    x...1236  CNS..109  -1
    x...1236  CNS..292  1
    x...1236  UC..1236  1
    x...1237  CNS..160  1
    x...1237  CNS..171  -1
    x...1237  UC..1237  1
    x...1238  CNS..160  -1
    x...1238  CNS..171  1
    x...1238  UC..1238  1
    x...1239  CNS..150  -1
    x...1239  CNS..410  1
    x...1239  UC..1239  1
    x...1240  CNS..150  1
    x...1240  CNS..410  -1
    x...1240  UC..1240  1
    x...1240  r_ekk432  -0.25
    x...1241  CNS..132  -1
    x...1241  CNS..289  1
    x...1241  UC..1241  1
    x...1242  CNS..132  1
    x...1242  CNS..289  -1
    x...1242  UC..1242  1
    x...1242  r_ekk158  -0.5
    x...1242  r_ekk169  -0.5
    x...1243  CNS..485  -1
    x...1243  CNS..494  1
    x...1243  UC..1243  1
    x...1243  r_ekk321  -0.00810546875
    x...1244  CNS..485  1
    x...1244  CNS..494  -1
    x...1244  UC..1244  1
    x...1245  CNS..106  -1
    x...1245  CNS..470  1
    x...1245  UC..1245  1
    x...1246  CNS..106  1
    x...1246  CNS..470  -1
    x...1246  UC..1246  1
    x...1246  r_ekk427  -1
    x...1247  CNS..409  1
    x...1247  CNS..447  -1
    x...1247  UC..1247  1
    x...1247  r_ekk261  -0.00810546875
    x...1247  r_ekk318  -0.1296875
    x...1247  r_ekk344  -0.1296875
    x...1248  CNS..409  -1
    x...1248  CNS..447  1
    x...1248  UC..1248  1
    x...1249  CNS..220  1
    x...1249  CNS..356  -1
    x...1249  UC..1249  1
    x...1250  CNS..220  -1
    x...1250  CNS..356  1
    x...1250  UC..1250  1
    MARK0000  'MARKER'                 'INTORG'
    y...0001  MinOBJ..  7
    y...0001  UC..0001  -82
    y...0001  r_ekk152  -1
    y...0001  r_ekk162  -1
    y...0001  r_ekk249  -1
    y...0001  r_ekk359  -1
    y...0002  MinOBJ..  7
    y...0002  UC..0002  -82
    y...0002  r_ekk75   -1
    y...0002  r_ekk127  -1
    y...0002  r_ekk260  -1
    y...0002  r_ekk381  -1
    y...0003  MinOBJ..  8
    y...0003  UC..0003  -82
    y...0003  r_ekk75   -1
    y...0003  r_ekk127  -1
    y...0003  r_ekk165  -0.134146341463416
    y...0003  r_ekk214  -0.04052734375
    y...0003  r_ekk260  -1
    y...0003  r_ekk261  -0.04052734375
    y...0003  r_ekk281  -0.75
    y...0003  r_ekk318  -0.6484375
    y...0003  r_ekk321  -0.04052734375
    y...0003  r_ekk344  -0.6484375
    y...0003  r_ekk364  -0.04052734375
    y...0003  r_ekk365  -0.04052734375
    y...0003  r_ekk381  -1
    y...0003  r_ekk433  -0.046875
    y...0004  MinOBJ..  8
    y...0004  UC..0004  -82
    y...0004  r_ekk99   -1
    y...0004  r_ekk197  -0.0975609756097569
    y...0004  r_ekk302  -0.75
    y...0004  r_ekk312  -0.04052734375
    y...0004  r_ekk329  -0.6484375
    y...0004  r_ekk380  -0.625
    y...0005  MinOBJ..  4
    y...0005  UC..0005  -82
    y...0005  r_ekk214  -0.04052734375
    y...0005  r_ekk260  -1
    y...0005  r_ekk261  -0.04052734375
    y...0005  r_ekk281  -0.75
    y...0005  r_ekk318  -0.6484375
    y...0005  r_ekk321  -0.04052734375
    y...0005  r_ekk344  -0.6484375
    y...0005  r_ekk433  -0.046875
    y...0006  MinOBJ..  4
    y...0006  UC..0006  -82
    y...0006  r_ekk127  -1
    y...0006  r_ekk261  -0.6646484375
    y...0006  r_ekk318  -0.6484375
    y...0006  r_ekk344  -0.6484375
    y...0006  r_ekk364  -0.830810546875
    y...0006  r_ekk433  -0.59375
    y...0007  MinOBJ..  8
    y...0007  UC..0007  -82
    y...0007  r_ekk71   -1
    y...0007  r_ekk174  -1
    y...0007  r_ekk234  -0.5
    y...0007  r_ekk312  -0.553873697916667
    y...0007  r_ekk329  -0.6484375
    y...0007  r_ekk394  -1
    y...0007  r_ekk413  -1
    y...0008  MinOBJ..  8
    y...0008  UC..0008  -82
    y...0008  r_ekk99   -1
    y...0008  r_ekk197  -0.0975609756097569
    y...0008  r_ekk302  -0.75
    y...0008  r_ekk312  -0.04052734375
    y...0008  r_ekk329  -0.6484375
    y...0008  r_ekk380  -0.625
    y...0009  MinOBJ..  8
    y...0009  UC..0009  -82
    y...0009  r_ekk152  -1
    y...0009  r_ekk162  -1
    y...0009  r_ekk165  -0.134146341463416
    y...0009  r_ekk214  -0.04052734375
    y...0009  r_ekk249  -1
    y...0009  r_ekk261  -0.04052734375
    y...0009  r_ekk281  -0.75
    y...0009  r_ekk318  -0.6484375
    y...0009  r_ekk344  -0.6484375
    y...0009  r_ekk359  -1
    y...0009  r_ekk364  -0.04052734375
    y...0009  r_ekk365  -0.04052734375
    y...0010  MinOBJ..  8
    y...0010  UC..0010  -82
    y...0010  r_ekk89   -1
    y...0010  r_ekk190  -1
    y...0010  r_ekk237  -1
    y...0010  r_ekk246  -1
    y...0010  r_ekk343  -1
    y...0010  r_ekk353  -1
    y...0010  r_ekk365  -0.830810546875
    y...0010  r_ekk402  -1
    y...0010  r_ekk413  -1
    y...0011  MinOBJ..  4
    y...0011  UC..0011  -82
    y...0011  r_ekk172  -1
    y...0011  r_ekk222  -1
    y...0011  r_ekk279  -1
    y...0011  r_ekk342  -1
    y...0011  r_ekk375  -0.75
    y...0011  r_ekk405  -0.75
    y...0012  MinOBJ..  4
    y...0012  UC..0012  -82
    y...0012  r_ekk99   -1
    y...0013  MinOBJ..  4
    y...0013  UC..0013  -82
    y...0013  r_ekk172  -1
    y...0013  r_ekk197  -0.0975609756097569
    y...0013  r_ekk222  -1
    y...0013  r_ekk312  -0.04052734375
    y...0013  r_ekk329  -0.6484375
    y...0013  r_ekk342  -1
    y...0013  r_ekk363  -0.75
    y...0013  r_ekk375  -0.75
    y...0013  r_ekk380  -0.625
    y...0014  MinOBJ..  4
    y...0014  UC..0014  -82
    y...0014  r_ekk245  -1
    y...0015  MinOBJ..  5
    y...0015  UC..0015  -82
    y...0015  r_ekk46   -1
    y...0015  r_ekk73   -1
    y...0015  r_ekk137  -1
    y...0015  r_ekk150  -1
    y...0015  r_ekk161  -0.780487804878049
    y...0015  r_ekk218  -1
    y...0015  r_ekk258  -1
    y...0015  r_ekk409  -1
    y...0016  MinOBJ..  5
    y...0016  UC..0016  -82
    y...0016  r_ekk190  -1
    y...0016  r_ekk246  -1
    y...0016  r_ekk343  -1
    y...0016  r_ekk353  -1
    y...0016  r_ekk413  -1
    y...0017  MinOBJ..  8
    y...0017  UC..0017  -82
    y...0017  r_ekk191  -1
    y...0017  r_ekk210  -1
    y...0018  MinOBJ..  8
    y...0018  UC..0018  -82
    y...0018  r_ekk245  -1
    y...0018  r_ekk279  -1
    y...0018  r_ekk405  -0.75
    y...0019  MinOBJ..  9
    y...0019  UC..0019  -82
    y...0019  r_ekk338  -1
    y...0020  MinOBJ..  9
    y...0020  UC..0020  -82
    y...0020  r_ekk46   -1
    y...0020  r_ekk73   -1
    y...0020  r_ekk89   -1
    y...0020  r_ekk137  -1
    y...0020  r_ekk150  -1
    y...0020  r_ekk161  -0.780487804878049
    y...0020  r_ekk218  -1
    y...0020  r_ekk237  -1
    y...0020  r_ekk246  -1
    y...0020  r_ekk258  -1
    y...0020  r_ekk402  -1
    y...0020  r_ekk409  -1
    y...0021  MinOBJ..  10
    y...0021  UC..0021  -82
    y...0021  r_ekk142  -0.780487804878035
    y...0021  r_ekk154  -4
    y...0021  r_ekk221  -1
    y...0021  r_ekk309  -0.625
    y...0021  r_ekk327  -1
    y...0021  r_ekk366  -0.04052734375
    y...0021  r_ekk370  -1
    y...0021  r_ekk376  -0.0390625
    y...0021  r_ekk384  -1
    y...0021  r_ekk403  -1
    y...0021  r_ekk419  -0.75
    y...0021  r_ekk428  -0.625
    y...0022  MinOBJ..  10
    y...0022  UC..0022  -82
    y...0022  r_ekk245  -1
    y...0022  r_ekk279  -1
    y...0022  r_ekk405  -0.75
    y...0025  MinOBJ..  6
    y...0025  UC..0025  -82
    y...0025  r_ekk295  -1
    y...0025  r_ekk307  -1
    y...0025  r_ekk315  -1
    y...0025  r_ekk324  -1
    y...0025  r_ekk339  -0.390243902439028
    y...0025  r_ekk400  -1
    y...0025  r_ekk410  -3.1640625
    y...0026  MinOBJ..  6
    y...0026  UC..0026  -82
    y...0026  r_ekk245  -1
    y...0026  r_ekk279  -1
    y...0026  r_ekk405  -0.75
    y...0027  MinOBJ..  1
    y...0027  UC..0027  -82
    y...0027  r_ekk114  -1
    y...0028  MinOBJ..  1
    y...0028  UC..0028  -82
    y...0028  r_ekk279  -1
    y...0028  r_ekk405  -0.75
    y...0029  MinOBJ..  10
    y...0029  UC..0029  -82
    y...0029  r_ekk75   -1
    y...0029  r_ekk127  -1
    y...0029  r_ekk165  -0.134146341463416
    y...0029  r_ekk381  -1
    y...0030  MinOBJ..  10
    y...0030  UC..0030  -82
    y...0030  r_ekk238  -1
    y...0030  r_ekk247  -1
    y...0030  r_ekk278  -1
    y...0030  r_ekk286  -1
    y...0030  r_ekk299  -1
    y...0030  r_ekk325  -1
    y...0030  r_ekk334  -1
    y...0030  r_ekk350  -1
    y...0030  r_ekk360  -1
    y...0030  r_ekk374  -1
    y...0030  r_ekk432  -1
    y...0031  MinOBJ..  8
    y...0031  UC..0031  -82
    y...0032  MinOBJ..  8
    y...0032  UC..0032  -82
    y...0032  r_ekk238  -1
    y...0032  r_ekk247  -1
    y...0032  r_ekk278  -1
    y...0032  r_ekk286  -1
    y...0032  r_ekk299  -1
    y...0032  r_ekk325  -1
    y...0032  r_ekk334  -1
    y...0032  r_ekk350  -1
    y...0032  r_ekk360  -1
    y...0032  r_ekk374  -1
    y...0032  r_ekk432  -1
    y...0035  MinOBJ..  3
    y...0035  UC..0035  -82
    y...0035  r_ekk153  -1
    y...0035  r_ekk165  -0.134146341463416
    y...0035  r_ekk223  -1
    y...0035  r_ekk270  -1
    y...0036  MinOBJ..  3
    y...0036  UC..0036  -82
    y...0037  MinOBJ..  4
    y...0037  UC..0037  -82
    y...0037  r_ekk42   -1
    y...0037  r_ekk202  -1
    y...0037  r_ekk226  -0.020263671875
    y...0037  r_ekk232  -1
    y...0037  r_ekk243  -1
    y...0037  r_ekk253  -1
    y...0037  r_ekk412  -1
    y...0037  r_ekk425  -0.75
    y...0038  MinOBJ..  4
    y...0038  UC..0038  -82
    y...0038  r_ekk89   -1
    y...0038  r_ekk226  -0.553873697916667
    y...0038  r_ekk246  -1
    y...0038  r_ekk343  -1
    y...0038  r_ekk353  -1
    y...0038  r_ekk402  -1
    y...0038  r_ekk413  -1
    y...0039  MinOBJ..  3
    y...0039  UC..0039  -82
    y...0039  r_ekk430  -1
    y...0040  MinOBJ..  3
    y...0040  UC..0040  -82
    y...0040  r_ekk295  -1
    y...0040  r_ekk307  -1
    y...0040  r_ekk315  -1
    y...0040  r_ekk324  -1
    y...0041  MinOBJ..  4
    y...0041  UC..0041  -82
    y...0041  r_ekk43   -1
    y...0041  r_ekk188  -1
    y...0042  MinOBJ..  4
    y...0042  UC..0042  -82
    y...0042  r_ekk154  -4
    y...0042  r_ekk221  -1
    y...0042  r_ekk309  -0.625
    y...0042  r_ekk366  -0.04052734375
    y...0042  r_ekk370  -1
    y...0042  r_ekk376  -0.0390625
    y...0042  r_ekk384  -1
    y...0045  MinOBJ..  7
    y...0045  UC..0045  -82
    y...0045  r_ekk42   -1
    y...0045  r_ekk190  -1
    y...0045  r_ekk202  -1
    y...0045  r_ekk226  -0.020263671875
    y...0045  r_ekk232  -1
    y...0045  r_ekk243  -1
    y...0045  r_ekk253  -1
    y...0045  r_ekk339  -0.0987654320987647
    y...0045  r_ekk410  -0.80078125
    y...0045  r_ekk412  -1
    y...0045  r_ekk425  -0.75
    y...0046  MinOBJ..  7
    y...0046  UC..0046  -82
    y...0046  r_ekk33   -1
    y...0046  r_ekk69   -1
    y...0046  r_ekk138  -1
    y...0046  r_ekk301  -1
    y...0046  r_ekk410  -3.1640625
    y...0047  MinOBJ..  5
    y...0047  UC..0047  -82
    y...0048  MinOBJ..  5
    y...0048  UC..0048  -82
    y...0049  MinOBJ..  9
    y...0049  UC..0049  -82
    y...0049  r_ekk295  -1
    y...0049  r_ekk307  -1
    y...0049  r_ekk315  -1
    y...0049  r_ekk324  -1
    y...0049  r_ekk339  -0.390243902439028
    y...0049  r_ekk400  -1
    y...0049  r_ekk410  -3.1640625
    y...0050  MinOBJ..  9
    y...0050  UC..0050  -82
    y...0051  MinOBJ..  10
    y...0051  UC..0051  -82
    y...0051  r_ekk333  -1
    y...0052  MinOBJ..  10
    y...0052  UC..0052  -82
    y...0053  MinOBJ..  7
    y...0053  UC..0053  -82
    y...0053  r_ekk172  -1
    y...0053  r_ekk197  -0.0975609756097569
    y...0053  r_ekk222  -1
    y...0053  r_ekk279  -1
    y...0053  r_ekk302  -0.75
    y...0053  r_ekk312  -0.04052734375
    y...0053  r_ekk329  -0.6484375
    y...0053  r_ekk342  -1
    y...0053  r_ekk363  -0.75
    y...0053  r_ekk375  -0.75
    y...0053  r_ekk380  -0.625
    y...0053  r_ekk405  -0.75
    y...0054  MinOBJ..  7
    y...0054  UC..0054  -82
    y...0054  r_ekk125  -1
    y...0054  r_ekk145  -0.020263671875
    y...0054  r_ekk176  -1
    y...0054  r_ekk193  -1
    y...0054  r_ekk212  -1
    y...0054  r_ekk224  -0.780487804878046
    y...0054  r_ekk328  -1
    y...0054  r_ekk338  -1
    y...0055  MinOBJ..  8
    y...0055  UC..0055  -82
    y...0055  r_ekk125  -1
    y...0055  r_ekk145  -0.020263671875
    y...0055  r_ekk156  -0.6171875
    y...0055  r_ekk166  -0.540364583333333
    y...0055  r_ekk176  -1
    y...0055  r_ekk212  -1
    y...0055  r_ekk224  -0.780487804878046
    y...0055  r_ekk338  -1
    y...0056  MinOBJ..  8
    y...0056  UC..0056  -82
    y...0056  r_ekk166  -0.020263671875
    y...0056  r_ekk168  -1
    y...0057  MinOBJ..  9
    y...0057  UC..0057  -82
    y...0058  MinOBJ..  9
    y...0058  UC..0058  -82
    y...0058  r_ekk238  -1
    y...0058  r_ekk247  -1
    y...0058  r_ekk299  -1
    y...0058  r_ekk325  -1
    y...0058  r_ekk334  -1
    y...0058  r_ekk350  -1
    y...0058  r_ekk360  -1
    y...0058  r_ekk374  -1
    y...0058  r_ekk432  -1
    y...0059  MinOBJ..  6
    y...0059  UC..0059  -82
    y...0059  r_ekk153  -1
    y...0059  r_ekk165  -0.134146341463416
    y...0059  r_ekk191  -1
    y...0059  r_ekk210  -1
    y...0059  r_ekk223  -1
    y...0060  MinOBJ..  6
    y...0060  UC..0060  -82
    y...0061  MinOBJ..  8
    y...0061  UC..0061  -82
    y...0061  r_ekk197  -0.0975609756097569
    y...0061  r_ekk340  -1
    y...0061  r_ekk416  -1
    y...0062  MinOBJ..  8
    y...0062  UC..0062  -82
    y...0062  r_ekk339  -0.390243902439028
    y...0062  r_ekk410  -3.1640625
    y...0062  r_ekk430  -1
    y...0063  MinOBJ..  3
    y...0063  UC..0063  -82
    y...0063  r_ekk221  -1
    y...0063  r_ekk370  -1
    y...0063  r_ekk384  -1
    y...0063  r_ekk403  -1
    y...0064  MinOBJ..  3
    y...0064  UC..0064  -82
    y...0064  r_ekk140  -1
    y...0064  r_ekk160  -1
    y...0064  r_ekk343  -1
    y...0064  r_ekk353  -1
    y...0064  r_ekk394  -1
    y...0064  r_ekk402  -1
    y...0064  r_ekk413  -1
    y...0065  MinOBJ..  10
    y...0065  UC..0065  -82
    y...0065  r_ekk128  -0.963414634146342
    y...0065  r_ekk245  -1
    y...0065  r_ekk279  -1
    y...0066  MinOBJ..  10
    y...0066  UC..0066  -82
    y...0066  r_ekk68   -1
    y...0066  r_ekk106  -1
    y...0066  r_ekk128  -0.0365853658536581
    y...0066  r_ekk164  -0.75
    y...0066  r_ekk180  -1
    y...0066  r_ekk200  -0.0234375
    y...0066  r_ekk227  -0.020263671875
    y...0066  r_ekk267  -1
    y...0066  r_ekk308  -0.75
    y...0067  MinOBJ..  1
    y...0067  UC..0067  -82
    y...0067  r_ekk180  -1
    y...0067  r_ekk405  -0.75
    y...0068  MinOBJ..  1
    y...0068  UC..0068  -82
    y...0068  r_ekk209  -1
    y...0069  MinOBJ..  6
    y...0069  UC..0069  -82
    y...0069  r_ekk106  -1
    y...0069  r_ekk128  -0.963414634146342
    y...0069  r_ekk164  -0.75
    y...0069  r_ekk175  -1
    y...0069  r_ekk200  -0.0234375
    y...0069  r_ekk308  -0.75
    y...0069  r_ekk328  -1
    y...0069  r_ekk338  -1
    y...0069  r_ekk413  -1
    y...0070  MinOBJ..  6
    y...0070  UC..0070  -82
    y...0070  r_ekk68   -1
    y...0070  r_ekk209  -1
    y...0071  MinOBJ..  8
    y...0071  UC..0071  -82
    y...0071  r_ekk162  -1
    y...0071  r_ekk364  -0.04052734375
    y...0071  r_ekk365  -0.04052734375
    y...0072  MinOBJ..  8
    y...0072  UC..0072  -82
    y...0072  r_ekk31   -1
    y...0072  r_ekk58   -1
    y...0072  r_ekk223  -1
    y...0073  MinOBJ..  5
    y...0073  UC..0073  -82
    y...0073  r_ekk47   -1
    y...0074  MinOBJ..  5
    y...0074  UC..0074  -82
    y...0074  r_ekk127  -1
    y...0074  r_ekk214  -0.04052734375
    y...0074  r_ekk281  -0.75
    y...0074  r_ekk344  -0.6484375
    y...0074  r_ekk364  -0.04052734375
    y...0074  r_ekk365  -0.04052734375
    y...0075  MinOBJ..  1
    y...0075  UC..0075  -82
    y...0075  r_ekk191  -1
    y...0076  MinOBJ..  1
    y...0076  UC..0076  -82
    y...0076  r_ekk233  -1
    y...0076  r_ekk336  -1
    y...0077  MinOBJ..  2
    y...0077  UC..0077  -82
    y...0078  MinOBJ..  2
    y...0078  UC..0078  -82
    y...0078  r_ekk219  -1
    y...0078  r_ekk248  -1
    y...0079  MinOBJ..  6
    y...0079  UC..0079  -82
    y...0080  MinOBJ..  6
    y...0080  UC..0080  -82
    y...0080  r_ekk206  -1
    y...0081  MinOBJ..  5
    y...0081  UC..0081  -82
    y...0081  r_ekk75   -1
    y...0081  r_ekk165  -0.134146341463416
    y...0081  r_ekk214  -0.04052734375
    y...0081  r_ekk261  -0.04052734375
    y...0081  r_ekk281  -0.75
    y...0081  r_ekk318  -0.6484375
    y...0081  r_ekk321  -0.04052734375
    y...0081  r_ekk344  -0.6484375
    y...0081  r_ekk364  -0.04052734375
    y...0081  r_ekk365  -0.04052734375
    y...0081  r_ekk381  -1
    y...0081  r_ekk433  -0.046875
    y...0082  MinOBJ..  5
    y...0082  UC..0082  -82
    y...0082  r_ekk159  -1
    y...0083  MinOBJ..  4
    y...0083  UC..0083  -82
    y...0083  r_ekk340  -1
    y...0084  MinOBJ..  4
    y...0084  UC..0084  -82
    y...0084  r_ekk185  -1
    y...0084  r_ekk222  -1
    y...0084  r_ekk279  -1
    y...0084  r_ekk302  -0.75
    y...0084  r_ekk342  -1
    y...0084  r_ekk363  -0.75
    y...0084  r_ekk380  -0.625
    y...0084  r_ekk405  -0.75
    y...0085  MinOBJ..  8
    y...0085  UC..0085  -82
    y...0085  r_ekk269  -1
    y...0085  r_ekk286  -1
    y...0085  r_ekk381  -1
    y...0086  MinOBJ..  8
    y...0086  UC..0086  -82
    y...0086  r_ekk333  -1
    y...0087  MinOBJ..  6
    y...0087  UC..0087  -82
    y...0087  r_ekk327  -1
    y...0087  r_ekk384  -1
    y...0087  r_ekk419  -0.75
    y...0088  MinOBJ..  6
    y...0088  UC..0088  -82
    y...0088  r_ekk12   -1
    y...0089  MinOBJ..  8
    y...0089  UC..0089  -82
    y...0089  r_ekk85   -1
    y...0089  r_ekk105  -1
    y...0089  r_ekk300  -1
    y...0089  r_ekk304  -0.03125
    y...0089  r_ekk349  -1
    y...0089  r_ekk357  -0.048780487804878
    y...0089  r_ekk378  -0.75
    y...0089  r_ekk396  -1
    y...0090  MinOBJ..  8
    y...0090  UC..0090  -82
    y...0091  MinOBJ..  9
    y...0091  UC..0091  -82
    y...0091  r_ekk76   -0.6171875
    y...0091  r_ekk260  -1
    y...0092  MinOBJ..  9
    y...0092  UC..0092  -82
    y...0092  r_ekk67   -1
    y...0092  r_ekk76   -0.0234375
    y...0092  r_ekk82   -1
    y...0093  MinOBJ..  5
    y...0093  UC..0093  -82
    y...0093  r_ekk221  -1
    y...0093  r_ekk309  -0.625
    y...0093  r_ekk327  -1
    y...0093  r_ekk376  -0.0390625
    y...0093  r_ekk403  -1
    y...0094  MinOBJ..  5
    y...0094  UC..0094  -82
    y...0094  r_ekk10   -1
    y...0095  MinOBJ..  2
    y...0095  UC..0095  -82
    y...0095  r_ekk247  -1
    y...0096  MinOBJ..  2
    y...0096  UC..0096  -82
    y...0096  r_ekk299  -1
    y...0096  r_ekk325  -1
    y...0096  r_ekk334  -1
    y...0096  r_ekk374  -1
    y...0097  MinOBJ..  6
    y...0097  UC..0097  -82
    y...0097  r_ekk211  -1
    y...0097  r_ekk276  -1
    y...0097  r_ekk288  -1
    y...0097  r_ekk301  -1
    y...0097  r_ekk326  -1
    y...0097  r_ekk335  -1
    y...0097  r_ekk339  -0.1
    y...0097  r_ekk347  -0.0234375
    y...0097  r_ekk351  -1
    y...0097  r_ekk372  -1
    y...0097  r_ekk392  -1
    y...0097  r_ekk423  -1
    y...0097  r_ekk429  -1
    y...0098  MinOBJ..  6
    y...0098  UC..0098  -82
    y...0098  r_ekk430  -1
    y...0099  MinOBJ..  9
    y...0099  UC..0099  -82
    y...0099  r_ekk66   -1
    y...0099  r_ekk173  -1
    y...0099  r_ekk220  -1
    y...0099  r_ekk290  -1
    y...0099  r_ekk296  -1
    y...0099  r_ekk303  -0.04052734375
    y...0099  r_ekk319  -0.04052734375
    y...0099  r_ekk320  -0.75
    y...0099  r_ekk330  -0.03125
    y...0099  r_ekk331  -0.0346171061197917
    y...0099  r_ekk424  -1
    y...0100  MinOBJ..  9
    y...0100  UC..0100  -82
    y...0100  r_ekk75   -1
    y...0100  r_ekk127  -1
    y...0100  r_ekk165  -0.134146341463416
    y...0100  r_ekk381  -1
    y...0103  MinOBJ..  9
    y...0103  UC..0103  -82
    y...0103  r_ekk1    -1
    y...0103  r_ekk39   -1
    y...0103  r_ekk283  -1
    y...0103  r_ekk433  -0.59375
    y...0104  MinOBJ..  9
    y...0104  UC..0104  -82
    y...0104  r_ekk152  -1
    y...0104  r_ekk162  -1
    y...0104  r_ekk214  -0.04052734375
    y...0104  r_ekk249  -1
    y...0104  r_ekk261  -0.04052734375
    y...0104  r_ekk281  -0.75
    y...0104  r_ekk318  -0.6484375
    y...0104  r_ekk344  -0.6484375
    y...0104  r_ekk359  -1
    y...0104  r_ekk364  -0.04052734375
    y...0104  r_ekk365  -0.04052734375
    y...0104  r_ekk433  -0.046875
    y...0105  MinOBJ..  4
    y...0105  UC..0105  -82
    y...0105  r_ekk276  -1
    y...0105  r_ekk301  -1
    y...0105  r_ekk326  -1
    y...0105  r_ekk335  -1
    y...0105  r_ekk392  -1
    y...0105  r_ekk418  -1
    y...0105  r_ekk429  -1
    y...0106  MinOBJ..  4
    y...0106  UC..0106  -82
    y...0106  r_ekk87   -1
    y...0106  r_ekk275  -1
    y...0106  r_ekk339  -0.2
    y...0106  r_ekk393  -1
    y...0106  r_ekk420  -0.75
    y...0106  r_ekk431  -0.75
    y...0109  MinOBJ..  2
    y...0109  UC..0109  -82
    y...0109  r_ekk165  -0.134146341463416
    y...0109  r_ekk364  -0.04052734375
    y...0109  r_ekk365  -0.04052734375
    y...0110  MinOBJ..  2
    y...0110  UC..0110  -82
    y...0111  MinOBJ..  10
    y...0111  UC..0111  -82
    y...0111  r_ekk239  -1
    y...0111  r_ekk269  -1
    y...0111  r_ekk286  -1
    y...0111  r_ekk381  -1
    y...0111  r_ekk403  -1
    y...0112  MinOBJ..  10
    y...0112  UC..0112  -82
    y...0112  r_ekk185  -1
    y...0112  r_ekk197  -0.0975609756097569
    y...0112  r_ekk222  -1
    y...0112  r_ekk279  -1
    y...0112  r_ekk302  -0.75
    y...0112  r_ekk312  -0.04052734375
    y...0112  r_ekk329  -0.6484375
    y...0112  r_ekk342  -1
    y...0112  r_ekk363  -0.75
    y...0112  r_ekk375  -0.75
    y...0112  r_ekk380  -0.625
    y...0112  r_ekk405  -0.75
    y...0112  r_ekk416  -1
    y...0113  MinOBJ..  9
    y...0113  UC..0113  -82
    y...0113  r_ekk108  -0.04052734375
    y...0113  r_ekk196  -0.04052734375
    y...0113  r_ekk199  -0.073321288768443
    y...0113  r_ekk251  -0.0303955078125
    y...0113  r_ekk256  -1
    y...0113  r_ekk263  -0.04052734375
    y...0113  r_ekk289  -1
    y...0113  r_ekk305  -1
    y...0113  r_ekk332  -1
    y...0113  r_ekk356  -0.0234375
    y...0113  r_ekk369  -1
    y...0113  r_ekk383  -1
    y...0113  r_ekk391  -0.75
    y...0113  r_ekk401  -1
    y...0113  r_ekk407  -0.75
    y...0113  r_ekk415  -1
    y...0113  r_ekk421  -1
    y...0113  r_ekk426  -1
    y...0114  MinOBJ..  9
    y...0114  UC..0114  -82
    y...0114  r_ekk210  -1
    y...0115  MinOBJ..  5
    y...0115  UC..0115  -82
    y...0115  r_ekk43   -1
    y...0115  r_ekk327  -1
    y...0115  r_ekk403  -1
    y...0115  r_ekk419  -0.75
    y...0115  r_ekk428  -0.625
    y...0116  MinOBJ..  5
    y...0116  UC..0116  -82
    y...0116  r_ekk154  -4
    y...0117  MinOBJ..  6
    y...0117  UC..0117  -82
    y...0117  r_ekk198  -0.625
    y...0118  MinOBJ..  6
    y...0118  UC..0118  -82
    y...0118  r_ekk178  -0.020263671875
    y...0118  r_ekk183  -1
    y...0118  r_ekk198  -0.015625
    y...0119  MinOBJ..  3
    y...0119  UC..0119  -82
    y...0120  MinOBJ..  3
    y...0120  UC..0120  -82
    y...0121  MinOBJ..  5
    y...0121  UC..0121  -82
    y...0121  r_ekk108  -0.04052734375
    y...0121  r_ekk196  -0.04052734375
    y...0121  r_ekk251  -0.0303955078125
    y...0121  r_ekk256  -1
    y...0121  r_ekk263  -0.04052734375
    y...0121  r_ekk305  -1
    y...0121  r_ekk391  -0.75
    y...0121  r_ekk401  -1
    y...0121  r_ekk407  -0.75
    y...0121  r_ekk415  -1
    y...0121  r_ekk421  -1
    y...0122  MinOBJ..  5
    y...0122  UC..0122  -82
    y...0122  r_ekk103  -1
    y...0122  r_ekk141  -1
    y...0122  r_ekk196  -0.830810546875
    y...0122  r_ekk199  -0.0246913580246914
    y...0123  MinOBJ..  3
    y...0123  UC..0123  -82
    y...0123  r_ekk66   -1
    y...0123  r_ekk424  -1
    y...0124  MinOBJ..  3
    y...0124  UC..0124  -82
    y...0124  r_ekk100  -1
    y...0124  r_ekk268  -1
    y...0124  r_ekk361  -1
    y...0124  r_ekk417  -1
    y...0124  r_ekk427  -1
    y...0125  MinOBJ..  4
    y...0125  UC..0125  -82
    y...0125  r_ekk100  -1
    y...0125  r_ekk268  -1
    y...0125  r_ekk296  -1
    y...0125  r_ekk303  -0.04052734375
    y...0125  r_ekk319  -0.04052734375
    y...0125  r_ekk330  -0.03125
    y...0125  r_ekk331  -0.0346171061197917
    y...0125  r_ekk361  -1
    y...0125  r_ekk417  -1
    y...0125  r_ekk427  -1
    y...0126  MinOBJ..  4
    y...0126  UC..0126  -82
    y...0127  MinOBJ..  3
    y...0127  UC..0127  -82
    y...0127  r_ekk72   -1
    y...0127  r_ekk231  -1
    y...0128  MinOBJ..  3
    y...0128  UC..0128  -82
    y...0128  r_ekk248  -1
    y...0129  MinOBJ..  5
    y...0129  UC..0129  -82
    y...0129  r_ekk74   -1
    y...0129  r_ekk274  -1
    y...0129  r_ekk284  -1
    y...0129  r_ekk341  -0.5
    y...0129  r_ekk347  -0.0234375
    y...0129  r_ekk362  -0.75
    y...0129  r_ekk393  -1
    y...0129  r_ekk420  -0.75
    y...0129  r_ekk431  -0.75
    y...0130  MinOBJ..  5
    y...0130  UC..0130  -82
    y...0131  MinOBJ..  9
    y...0131  UC..0131  -82
    y...0131  r_ekk56   -1
    y...0131  r_ekk78   -0.780487804878049
    y...0131  r_ekk135  -1
    y...0131  r_ekk157  -1
    y...0131  r_ekk165  -0.0123456790123457
    y...0131  r_ekk197  -0.0123456790123457
    y...0131  r_ekk210  -1
    y...0132  MinOBJ..  9
    y...0132  UC..0132  -82
    y...0132  r_ekk165  -0.0123456790123457
    y...0132  r_ekk245  -1
    y...0133  MinOBJ..  2
    y...0133  UC..0133  -82
    y...0133  r_ekk278  -1
    y...0134  MinOBJ..  2
    y...0134  UC..0134  -82
    y...0134  r_ekk381  -1
    y...0135  MinOBJ..  10
    y...0135  UC..0135  -82
    y...0135  r_ekk165  -0.134146341463416
    y...0135  r_ekk364  -0.04052734375
    y...0135  r_ekk365  -0.04052734375
    y...0136  MinOBJ..  10
    y...0136  UC..0136  -82
    y...0136  r_ekk101  -1
    y...0136  r_ekk163  -1
    y...0137  MinOBJ..  9
    y...0137  UC..0137  -82
    y...0137  r_ekk156  -0.0234375
    y...0137  r_ekk166  -0.020263671875
    y...0137  r_ekk168  -1
    y...0137  r_ekk193  -1
    y...0138  MinOBJ..  9
    y...0138  UC..0138  -82
    y...0138  r_ekk156  -0.6171875
    y...0139  MinOBJ..  6
    y...0139  UC..0139  -82
    y...0139  r_ekk203  -1
    y...0139  r_ekk225  -0.04052734375
    y...0139  r_ekk230  -1
    y...0139  r_ekk244  -1
    y...0139  r_ekk254  -1
    y...0139  r_ekk271  -0.04052734375
    y...0139  r_ekk293  -0.518750000000001
    y...0140  MinOBJ..  6
    y...0140  UC..0140  -82
    y...0140  r_ekk127  -1
    y...0140  r_ekk260  -1
    y...0143  MinOBJ..  7
    y...0143  UC..0143  -82
    y...0143  r_ekk40   -1
    y...0143  r_ekk199  -0.073321288768443
    y...0143  r_ekk257  -1
    y...0143  r_ekk311  -1
    y...0143  r_ekk317  -1
    y...0143  r_ekk395  -1
    y...0143  r_ekk406  -1
    y...0143  r_ekk421  -1
    y...0144  MinOBJ..  7
    y...0144  UC..0144  -82
    y...0144  r_ekk197  -0.0975609756097569
    y...0144  r_ekk416  -1
    y...0145  MinOBJ..  3
    y...0145  UC..0145  -82
    y...0145  r_ekk287  -1
    y...0145  r_ekk345  -1
    y...0145  r_ekk404  -1
    y...0145  r_ekk422  -0.75
    y...0146  MinOBJ..  3
    y...0146  UC..0146  -82
    y...0146  r_ekk85   -1
    y...0146  r_ekk300  -1
    y...0146  r_ekk322  -1
    y...0146  r_ekk349  -1
    y...0147  MinOBJ..  3
    y...0147  UC..0147  -82
    y...0147  r_ekk87   -1
    y...0147  r_ekk288  -1
    y...0147  r_ekk339  -0.1
    y...0147  r_ekk410  -0.810791015625
    y...0147  r_ekk423  -1
    y...0148  MinOBJ..  3
    y...0148  UC..0148  -82
    y...0148  r_ekk74   -1
    y...0148  r_ekk90   -1
    y...0149  MinOBJ..  7
    y...0149  UC..0149  -82
    y...0149  r_ekk79   -1
    y...0149  r_ekk92   -1
    y...0149  r_ekk118  -1
    y...0149  r_ekk170  -1
    y...0150  MinOBJ..  7
    y...0150  UC..0150  -82
    y...0150  r_ekk105  -1
    y...0150  r_ekk287  -1
    y...0150  r_ekk385  -0.75
    y...0150  r_ekk422  -0.75
    y...0151  MinOBJ..  10
    y...0151  UC..0151  -82
    y...0151  r_ekk53   -1
    y...0151  r_ekk109  -0.020263671875
    y...0151  r_ekk119  -1
    y...0152  MinOBJ..  10
    y...0152  UC..0152  -82
    y...0152  r_ekk168  -1
    y...0152  r_ekk193  -1
    y...0155  MinOBJ..  5
    y...0155  UC..0155  -82
    y...0155  r_ekk7    -1
    y...0156  MinOBJ..  5
    y...0156  UC..0156  -82
    y...0156  r_ekk221  -1
    y...0156  r_ekk309  -0.625
    y...0156  r_ekk327  -1
    y...0156  r_ekk366  -0.04052734375
    y...0156  r_ekk376  -0.0390625
    y...0156  r_ekk384  -1
    y...0156  r_ekk419  -0.75
    y...0156  r_ekk428  -0.625
    y...0163  MinOBJ..  2
    y...0163  UC..0163  -82
    y...0163  r_ekk96   -1
    y...0164  MinOBJ..  2
    y...0164  UC..0164  -82
    y...0169  MinOBJ..  6
    y...0169  UC..0169  -82
    y...0169  r_ekk154  -4
    y...0170  MinOBJ..  6
    y...0170  UC..0170  -82
    y...0170  r_ekk43   -1
    y...0170  r_ekk188  -1
    y...0170  r_ekk327  -1
    y...0170  r_ekk403  -1
    y...0171  MinOBJ..  8
    y...0171  UC..0171  -82
    y...0171  r_ekk97   -1
    y...0171  r_ekk122  -1
    y...0171  r_ekk151  -1
    y...0171  r_ekk158  -1
    y...0171  r_ekk169  -1
    y...0171  r_ekk204  -1
    y...0171  r_ekk213  -0.024390243902439
    y...0171  r_ekk216  -1
    y...0172  MinOBJ..  8
    y...0172  UC..0172  -82
    y...0172  r_ekk46   -1
    y...0172  r_ekk73   -1
    y...0172  r_ekk89   -1
    y...0172  r_ekk137  -1
    y...0172  r_ekk150  -1
    y...0172  r_ekk161  -0.780487804878049
    y...0172  r_ekk218  -1
    y...0172  r_ekk237  -1
    y...0172  r_ekk246  -1
    y...0172  r_ekk258  -1
    y...0172  r_ekk402  -1
    y...0172  r_ekk409  -1
    y...0173  MinOBJ..  4
    y...0173  UC..0173  -82
    y...0173  r_ekk72   -1
    y...0173  r_ekk219  -1
    y...0174  MinOBJ..  4
    y...0174  UC..0174  -82
    y...0175  MinOBJ..  1
    y...0175  UC..0175  -82
    y...0175  r_ekk19   -1
    y...0176  MinOBJ..  1
    y...0176  UC..0176  -82
    y...0179  MinOBJ..  4
    y...0179  UC..0179  -82
    y...0179  r_ekk42   -1
    y...0179  r_ekk190  -1
    y...0180  MinOBJ..  4
    y...0180  UC..0180  -82
    y...0180  r_ekk84   -1
    y...0180  r_ekk103  -1
    y...0180  r_ekk141  -1
    y...0180  r_ekk199  -0.0246913580246914
    y...0181  MinOBJ..  5
    y...0181  UC..0181  -82
    y...0182  MinOBJ..  5
    y...0182  UC..0182  -82
    y...0185  MinOBJ..  1
    y...0185  UC..0185  -82
    y...0185  r_ekk304  -0.03125
    y...0185  r_ekk345  -1
    y...0185  r_ekk357  -0.048780487804878
    y...0185  r_ekk378  -0.75
    y...0185  r_ekk385  -0.75
    y...0185  r_ekk396  -1
    y...0185  r_ekk422  -0.75
    y...0186  MinOBJ..  1
    y...0186  UC..0186  -82
    y...0187  MinOBJ..  1
    y...0187  UC..0187  -82
    y...0187  r_ekk430  -1
    y...0188  MinOBJ..  1
    y...0188  UC..0188  -82
    y...0191  MinOBJ..  7
    y...0191  UC..0191  -82
    y...0191  r_ekk221  -1
    y...0191  r_ekk309  -0.625
    y...0191  r_ekk327  -1
    y...0191  r_ekk366  -0.04052734375
    y...0191  r_ekk370  -1
    y...0191  r_ekk376  -0.0390625
    y...0191  r_ekk384  -1
    y...0191  r_ekk403  -1
    y...0191  r_ekk419  -0.75
    y...0191  r_ekk428  -0.625
    y...0192  MinOBJ..  7
    y...0192  UC..0192  -82
    y...0193  MinOBJ..  8
    y...0193  UC..0193  -82
    y...0194  MinOBJ..  8
    y...0194  UC..0194  -82
    y...0194  r_ekk125  -1
    y...0194  r_ekk145  -0.020263671875
    y...0194  r_ekk176  -1
    y...0194  r_ekk193  -1
    y...0194  r_ekk212  -1
    y...0194  r_ekk224  -0.780487804878046
    y...0194  r_ekk328  -1
    y...0195  MinOBJ..  4
    y...0195  UC..0195  -82
    y...0195  r_ekk26   -1
    y...0195  r_ekk57   -1
    y...0195  r_ekk86   -1
    y...0195  r_ekk240  -1
    y...0196  MinOBJ..  4
    y...0196  UC..0196  -82
    y...0197  MinOBJ..  2
    y...0197  UC..0197  -82
    y...0198  MinOBJ..  2
    y...0198  UC..0198  -82
    y...0199  MinOBJ..  4
    y...0199  UC..0199  -82
    y...0199  r_ekk211  -1
    y...0199  r_ekk276  -1
    y...0199  r_ekk288  -1
    y...0199  r_ekk326  -1
    y...0199  r_ekk335  -1
    y...0199  r_ekk339  -0.1
    y...0199  r_ekk410  -0.810791015625
    y...0199  r_ekk418  -1
    y...0199  r_ekk423  -1
    y...0199  r_ekk429  -1
    y...0200  MinOBJ..  4
    y...0200  UC..0200  -82
    y...0200  r_ekk69   -1
    y...0200  r_ekk138  -1
    y...0201  MinOBJ..  6
    y...0201  UC..0201  -82
    y...0201  r_ekk177  -1
    y...0201  r_ekk192  -1
    y...0201  r_ekk347  -0.6171875
    y...0201  r_ekk431  -0.75
    y...0202  MinOBJ..  6
    y...0202  UC..0202  -82
    y...0202  r_ekk74   -1
    y...0202  r_ekk90   -1
    y...0202  r_ekk211  -1
    y...0202  r_ekk339  -0.2
    y...0202  r_ekk410  -1.62158203125
    y...0203  MinOBJ..  7
    y...0203  UC..0203  -82
    y...0204  MinOBJ..  7
    y...0204  UC..0204  -82
    y...0204  r_ekk79   -1
    y...0204  r_ekk92   -1
    y...0204  r_ekk118  -1
    y...0204  r_ekk304  -0.03125
    y...0204  r_ekk333  -1
    y...0204  r_ekk345  -1
    y...0204  r_ekk357  -0.048780487804878
    y...0204  r_ekk396  -1
    y...0204  r_ekk404  -1
    y...0205  MinOBJ..  8
    y...0205  UC..0205  -82
    y...0205  r_ekk41   -1
    y...0205  r_ekk98   -1
    y...0205  r_ekk110  -0.024390243902439
    y...0205  r_ekk148  -1
    y...0205  r_ekk298  -1
    y...0206  MinOBJ..  8
    y...0206  UC..0206  -82
    y...0206  r_ekk106  -1
    y...0206  r_ekk164  -0.75
    y...0206  r_ekk200  -0.0234375
    y...0206  r_ekk227  -0.020263671875
    y...0206  r_ekk267  -1
    y...0206  r_ekk308  -0.75
    y...0206  r_ekk328  -1
    y...0206  r_ekk338  -1
    y...0206  r_ekk413  -1
    y...0207  MinOBJ..  8
    y...0207  UC..0207  -82
    y...0207  r_ekk18   -1
    y...0207  r_ekk64   -1
    y...0207  r_ekk88   -1
    y...0207  r_ekk195  -0.020263671875
    y...0207  r_ekk235  -1
    y...0207  r_ekk291  -1
    y...0208  MinOBJ..  8
    y...0208  UC..0208  -82
    y...0208  r_ekk66   -1
    y...0208  r_ekk173  -1
    y...0208  r_ekk195  -0.830810546875
    y...0208  r_ekk220  -1
    y...0208  r_ekk290  -1
    y...0208  r_ekk296  -1
    y...0208  r_ekk319  -0.04052734375
    y...0208  r_ekk424  -1
    y...0211  MinOBJ..  3
    y...0211  UC..0211  -82
    y...0211  r_ekk381  -1
    y...0212  MinOBJ..  3
    y...0212  UC..0212  -82
    y...0212  r_ekk340  -1
    y...0215  MinOBJ..  3
    y...0215  UC..0215  -82
    y...0215  r_ekk106  -1
    y...0215  r_ekk308  -0.75
    y...0216  MinOBJ..  3
    y...0216  UC..0216  -82
    y...0216  r_ekk200  -0.0234375
    y...0217  MinOBJ..  9
    y...0217  UC..0217  -82
    y...0218  MinOBJ..  9
    y...0218  UC..0218  -82
    y...0218  r_ekk165  -0.134146341463416
    y...0218  r_ekk364  -0.04052734375
    y...0218  r_ekk365  -0.04052734375
    y...0221  MinOBJ..  10
    y...0221  UC..0221  -82
    y...0222  MinOBJ..  10
    y...0222  UC..0222  -82
    y...0222  r_ekk88   -1
    y...0222  r_ekk235  -1
    y...0222  r_ekk255  -1
    y...0222  r_ekk268  -1
    y...0222  r_ekk373  -1
    y...0222  r_ekk417  -1
    y...0222  r_ekk427  -1
    y...0223  MinOBJ..  2
    y...0223  UC..0223  -82
    y...0223  r_ekk146  -1
    y...0224  MinOBJ..  2
    y...0224  UC..0224  -82
    y...0224  r_ekk203  -1
    y...0225  MinOBJ..  9
    y...0225  UC..0225  -82
    y...0225  r_ekk41   -1
    y...0225  r_ekk98   -1
    y...0225  r_ekk110  -0.024390243902439
    y...0225  r_ekk148  -1
    y...0225  r_ekk175  -1
    y...0225  r_ekk224  -0.780487804878046
    y...0225  r_ekk328  -1
    y...0225  r_ekk338  -1
    y...0226  MinOBJ..  9
    y...0226  UC..0226  -82
    y...0226  r_ekk102  -1
    y...0226  r_ekk121  -1
    y...0226  r_ekk139  -1
    y...0226  r_ekk174  -1
    y...0226  r_ekk207  -1
    y...0226  r_ekk262  -0.8206787109375
    y...0226  r_ekk413  -1
    y...0227  MinOBJ..  10
    y...0227  UC..0227  -82
    y...0227  r_ekk104  -1
    y...0227  r_ekk280  -1
    y...0228  MinOBJ..  10
    y...0228  UC..0228  -82
    y...0228  r_ekk177  -1
    y...0228  r_ekk192  -1
    y...0228  r_ekk275  -1
    y...0228  r_ekk372  -1
    y...0228  r_ekk393  -1
    y...0228  r_ekk431  -0.75
    y...0231  MinOBJ..  2
    y...0231  UC..0231  -82
    y...0231  r_ekk156  -0.6171875
    y...0232  MinOBJ..  2
    y...0232  UC..0232  -82
    y...0232  r_ekk53   -1
    y...0233  MinOBJ..  9
    y...0233  UC..0233  -82
    y...0233  r_ekk17   -1
    y...0233  r_ekk52   -1
    y...0233  r_ekk133  -1
    y...0233  r_ekk197  -0.0975609756097569
    y...0233  r_ekk302  -0.75
    y...0233  r_ekk312  -0.04052734375
    y...0233  r_ekk329  -0.6484375
    y...0233  r_ekk339  -0.0975609756097562
    y...0233  r_ekk410  -0.791015625
    y...0234  MinOBJ..  9
    y...0234  UC..0234  -82
    y...0234  r_ekk74   -1
    y...0234  r_ekk274  -1
    y...0234  r_ekk284  -1
    y...0234  r_ekk295  -1
    y...0234  r_ekk307  -1
    y...0234  r_ekk315  -1
    y...0234  r_ekk324  -1
    y...0234  r_ekk341  -0.5
    y...0234  r_ekk347  -0.0234375
    y...0234  r_ekk362  -0.75
    y...0234  r_ekk393  -1
    y...0234  r_ekk400  -1
    y...0234  r_ekk410  -3.1640625
    y...0234  r_ekk420  -0.75
    y...0234  r_ekk431  -0.75
    y...0237  MinOBJ..  10
    y...0237  UC..0237  -82
    y...0237  r_ekk87   -1
    y...0237  r_ekk211  -1
    y...0237  r_ekk275  -1
    y...0237  r_ekk288  -1
    y...0237  r_ekk339  -0.690243902439028
    y...0237  r_ekk347  -0.0234375
    y...0237  r_ekk351  -1
    y...0237  r_ekk362  -0.75
    y...0237  r_ekk372  -1
    y...0237  r_ekk393  -1
    y...0237  r_ekk410  -3.1640625
    y...0237  r_ekk420  -0.75
    y...0237  r_ekk423  -1
    y...0237  r_ekk430  -1
    y...0237  r_ekk431  -0.75
    y...0238  MinOBJ..  10
    y...0238  UC..0238  -82
    y...0243  MinOBJ..  10
    y...0243  UC..0243  -82
    y...0243  r_ekk381  -1
    y...0244  MinOBJ..  10
    y...0244  UC..0244  -82
    y...0244  r_ekk106  -1
    y...0244  r_ekk164  -0.75
    y...0244  r_ekk175  -1
    y...0244  r_ekk200  -0.0234375
    y...0244  r_ekk227  -0.020263671875
    y...0244  r_ekk267  -1
    y...0244  r_ekk308  -0.75
    y...0244  r_ekk328  -1
    y...0244  r_ekk338  -1
    y...0244  r_ekk413  -1
    y...0245  MinOBJ..  6
    y...0245  UC..0245  -82
    y...0245  r_ekk40   -1
    y...0245  r_ekk340  -1
    y...0245  r_ekk415  -1
    y...0246  MinOBJ..  6
    y...0246  UC..0246  -82
    y...0246  r_ekk80   -1
    y...0246  r_ekk120  -1
    y...0246  r_ekk142  -0.0987654320987655
    y...0246  r_ekk177  -1
    y...0247  MinOBJ..  3
    y...0247  UC..0247  -82
    y...0247  r_ekk125  -1
    y...0247  r_ekk145  -0.020263671875
    y...0247  r_ekk176  -1
    y...0247  r_ekk193  -1
    y...0247  r_ekk212  -1
    y...0247  r_ekk224  -0.780487804878046
    y...0247  r_ekk328  -1
    y...0248  MinOBJ..  3
    y...0248  UC..0248  -82
    y...0249  MinOBJ..  9
    y...0249  UC..0249  -82
    y...0249  r_ekk151  -1
    y...0249  r_ekk204  -1
    y...0249  r_ekk213  -0.024390243902439
    y...0249  r_ekk216  -1
    y...0249  r_ekk413  -1
    y...0250  MinOBJ..  9
    y...0250  UC..0250  -82
    y...0251  MinOBJ..  6
    y...0251  UC..0251  -82
    y...0251  r_ekk10   -1
    y...0251  r_ekk366  -0.04052734375
    y...0251  r_ekk370  -1
    y...0251  r_ekk384  -1
    y...0252  MinOBJ..  6
    y...0252  UC..0252  -82
    y...0252  r_ekk120  -1
    y...0252  r_ekk142  -0.0987654320987655
    y...0252  r_ekk257  -1
    y...0252  r_ekk317  -1
    y...0252  r_ekk395  -1
    y...0252  r_ekk406  -1
    y...0253  MinOBJ..  9
    y...0253  UC..0253  -82
    y...0253  r_ekk67   -1
    y...0253  r_ekk82   -1
    y...0253  r_ekk292  -0.553873697916667
    y...0253  r_ekk321  -0.04052734375
    y...0253  r_ekk433  -0.046875
    y...0254  MinOBJ..  9
    y...0254  UC..0254  -82
    y...0254  r_ekk76   -0.6171875
    y...0254  r_ekk163  -1
    y...0254  r_ekk187  -1
    y...0254  r_ekk273  -1
    y...0254  r_ekk292  -0.020263671875
    y...0254  r_ekk321  -0.6322265625
    y...0255  MinOBJ..  8
    y...0255  UC..0255  -82
    y...0256  MinOBJ..  8
    y...0256  UC..0256  -82
    y...0256  r_ekk247  -1
    y...0256  r_ekk278  -1
    y...0256  r_ekk286  -1
    y...0256  r_ekk350  -1
    y...0256  r_ekk360  -1
    y...0257  MinOBJ..  1
    y...0257  UC..0257  -82
    y...0258  MinOBJ..  1
    y...0258  UC..0258  -82
    y...0258  r_ekk49   -0.0078125
    y...0258  r_ekk112  -1
    y...0259  MinOBJ..  3
    y...0259  UC..0259  -82
    y...0260  MinOBJ..  3
    y...0260  UC..0260  -82
    y...0260  r_ekk388  -1
    y...0261  MinOBJ..  10
    y...0261  UC..0261  -82
    y...0261  r_ekk45   -1
    y...0261  r_ekk189  -1
    y...0261  r_ekk269  -1
    y...0261  r_ekk278  -1
    y...0261  r_ekk286  -1
    y...0261  r_ekk352  -0.75
    y...0261  r_ekk379  -0.75
    y...0261  r_ekk386  -1
    y...0261  r_ekk387  -0.020263671875
    y...0261  r_ekk432  -1
    y...0262  MinOBJ..  10
    y...0262  UC..0262  -82
    y...0263  MinOBJ..  9
    y...0263  UC..0263  -82
    y...0263  r_ekk349  -1
    y...0263  r_ekk357  -0.048780487804878
    y...0264  MinOBJ..  9
    y...0264  UC..0264  -82
    y...0264  r_ekk19   -1
    y...0264  r_ekk85   -1
    y...0264  r_ekk105  -1
    y...0264  r_ekk322  -1
    y...0264  r_ekk333  -1
    y...0264  r_ekk378  -0.75
    y...0267  MinOBJ..  5
    y...0267  UC..0267  -82
    y...0267  r_ekk106  -1
    y...0267  r_ekk164  -0.75
    y...0267  r_ekk175  -1
    y...0267  r_ekk200  -0.0234375
    y...0267  r_ekk227  -0.020263671875
    y...0267  r_ekk267  -1
    y...0267  r_ekk328  -1
    y...0268  MinOBJ..  5
    y...0268  UC..0268  -82
    y...0268  r_ekk227  -0.553873697916667
    y...0269  MinOBJ..  2
    y...0269  UC..0269  -82
    y...0269  r_ekk167  -1
    y...0270  MinOBJ..  2
    y...0270  UC..0270  -82
    y...0270  r_ekk233  -1
    y...0270  r_ekk256  -1
    y...0270  r_ekk332  -1
    y...0270  r_ekk369  -1
    y...0270  r_ekk383  -1
    y...0270  r_ekk421  -1
    y...0270  r_ekk426  -1
    y...0271  MinOBJ..  4
    y...0271  UC..0271  -82
    y...0271  r_ekk120  -1
    y...0271  r_ekk142  -0.0987654320987655
    y...0271  r_ekk154  -0.813895781637742
    y...0271  r_ekk257  -1
    y...0272  MinOBJ..  4
    y...0272  UC..0272  -82
    y...0273  MinOBJ..  3
    y...0273  UC..0273  -82
    y...0273  r_ekk238  -1
    y...0273  r_ekk247  -1
    y...0273  r_ekk334  -1
    y...0273  r_ekk350  -1
    y...0273  r_ekk360  -1
    y...0273  r_ekk432  -1
    y...0274  MinOBJ..  3
    y...0274  UC..0274  -82
    y...0274  r_ekk374  -1
    y...0275  MinOBJ..  10
    y...0275  UC..0275  -82
    y...0275  r_ekk297  -1
    y...0275  r_ekk335  -1
    y...0275  r_ekk385  -0.75
    y...0275  r_ekk392  -1
    y...0275  r_ekk418  -1
    y...0275  r_ekk422  -0.75
    y...0276  MinOBJ..  10
    y...0276  UC..0276  -82
    y...0276  r_ekk97   -1
    y...0276  r_ekk122  -1
    y...0276  r_ekk151  -1
    y...0276  r_ekk158  -1
    y...0276  r_ekk169  -1
    y...0276  r_ekk204  -1
    y...0276  r_ekk213  -0.024390243902439
    y...0276  r_ekk216  -1
    y...0277  MinOBJ..  4
    y...0277  UC..0277  -82
    y...0277  r_ekk338  -1
    y...0278  MinOBJ..  4
    y...0278  UC..0278  -82
    y...0278  r_ekk220  -1
    y...0278  r_ekk290  -1
    y...0278  r_ekk331  -0.0173085530598958
    y...0281  MinOBJ..  10
    y...0281  UC..0281  -82
    y...0281  r_ekk170  -1
    y...0282  MinOBJ..  10
    y...0282  UC..0282  -82
    y...0282  r_ekk29   -1
    y...0282  r_ekk63   -1
    y...0282  r_ekk197  -0.0975609756097569
    y...0282  r_ekk205  -1
    y...0283  MinOBJ..  6
    y...0283  UC..0283  -82
    y...0283  r_ekk123  -1
    y...0283  r_ekk149  -1
    y...0283  r_ekk171  -1
    y...0283  r_ekk276  -1
    y...0283  r_ekk429  -1
    y...0284  MinOBJ..  6
    y...0284  UC..0284  -82
    y...0284  r_ekk297  -1
    y...0284  r_ekk335  -1
    y...0284  r_ekk409  -1
    y...0285  MinOBJ..  2
    y...0285  UC..0285  -82
    y...0286  MinOBJ..  2
    y...0286  UC..0286  -82
    y...0287  MinOBJ..  9
    y...0287  UC..0287  -82
    y...0287  r_ekk34   -1
    y...0287  r_ekk60   -1
    y...0287  r_ekk104  -1
    y...0287  r_ekk228  -1
    y...0287  r_ekk266  -1
    y...0287  r_ekk313  -1
    y...0287  r_ekk355  -1
    y...0288  MinOBJ..  9
    y...0288  UC..0288  -82
    y...0288  r_ekk47   -1
    y...0288  r_ekk75   -1
    y...0288  r_ekk381  -1
    y...0289  MinOBJ..  5
    y...0289  UC..0289  -82
    y...0289  r_ekk199  -0.073321288768443
    y...0289  r_ekk289  -1
    y...0289  r_ekk332  -1
    y...0289  r_ekk369  -1
    y...0289  r_ekk383  -1
    y...0289  r_ekk426  -1
    y...0290  MinOBJ..  5
    y...0290  UC..0290  -82
    y...0290  r_ekk286  -1
    y...0290  r_ekk356  -0.6171875
    y...0295  MinOBJ..  9
    y...0295  UC..0295  -82
    y...0295  r_ekk59   -1
    y...0295  r_ekk83   -1
    y...0295  r_ekk117  -1
    y...0295  r_ekk358  -1
    y...0295  r_ekk371  -0.75
    y...0296  MinOBJ..  9
    y...0296  UC..0296  -82
    y...0296  r_ekk388  -1
    y...0297  MinOBJ..  10
    y...0297  UC..0297  -82
    y...0298  MinOBJ..  10
    y...0298  UC..0298  -82
    y...0298  r_ekk197  -0.0975609756097569
    y...0298  r_ekk381  -1
    y...0298  r_ekk416  -1
    y...0299  MinOBJ..  7
    y...0299  UC..0299  -82
    y...0300  MinOBJ..  7
    y...0300  UC..0300  -82
    y...0300  r_ekk101  -1
    y...0300  r_ekk163  -1
    y...0300  r_ekk265  -1
    y...0300  r_ekk285  -1
    y...0300  r_ekk348  -1
    y...0300  r_ekk354  -0.015625
    y...0300  r_ekk371  -0.75
    y...0300  r_ekk377  -1
    y...0300  r_ekk399  -1
    y...0300  r_ekk414  -1
    y...0301  MinOBJ..  2
    y...0301  UC..0301  -82
    y...0301  r_ekk70   -1
    y...0301  r_ekk126  -1
    y...0301  r_ekk316  -1
    y...0302  MinOBJ..  2
    y...0302  UC..0302  -82
    y...0302  r_ekk45   -1
    y...0303  MinOBJ..  5
    y...0303  UC..0303  -82
    y...0303  r_ekk430  -1
    y...0304  MinOBJ..  5
    y...0304  UC..0304  -82
    y...0305  MinOBJ..  1
    y...0305  UC..0305  -82
    y...0305  r_ekk89   -1
    y...0306  MinOBJ..  1
    y...0306  UC..0306  -82
    y...0306  r_ekk140  -1
    y...0306  r_ekk309  -0.625
    y...0306  r_ekk376  -0.0390625
    y...0307  MinOBJ..  3
    y...0307  UC..0307  -82
    y...0307  r_ekk233  -1
    y...0307  r_ekk289  -1
    y...0307  r_ekk332  -1
    y...0307  r_ekk356  -0.0234375
    y...0307  r_ekk369  -1
    y...0307  r_ekk383  -1
    y...0307  r_ekk426  -1
    y...0308  MinOBJ..  3
    y...0308  UC..0308  -82
    y...0308  r_ekk73   -1
    y...0308  r_ekk89   -1
    y...0308  r_ekk250  -1
    y...0308  r_ekk402  -1
    y...0309  MinOBJ..  7
    y...0309  UC..0309  -82
    y...0309  r_ekk49   -0.0078125
    y...0309  r_ekk112  -1
    y...0309  r_ekk178  -0.020263671875
    y...0309  r_ekk183  -1
    y...0310  MinOBJ..  7
    y...0310  UC..0310  -82
    y...0310  r_ekk49   -0.6328125
    y...0310  r_ekk198  -0.625
    y...0311  MinOBJ..  1
    y...0311  UC..0311  -82
    y...0311  r_ekk393  -1
    y...0312  MinOBJ..  1
    y...0312  UC..0312  -82
    y...0312  r_ekk252  -1
    y...0313  MinOBJ..  4
    y...0313  UC..0313  -82
    y...0313  r_ekk44   -1
    y...0313  r_ekk143  -1
    y...0313  r_ekk195  -0.020263671875
    y...0313  r_ekk291  -1
    y...0313  r_ekk303  -0.04052734375
    y...0313  r_ekk310  -1
    y...0313  r_ekk319  -0.04052734375
    y...0313  r_ekk320  -0.75
    y...0313  r_ekk330  -0.03125
    y...0313  r_ekk331  -0.0346171061197917
    y...0314  MinOBJ..  4
    y...0314  UC..0314  -82
    y...0314  r_ekk235  -1
    y...0314  r_ekk268  -1
    y...0314  r_ekk373  -1
    y...0314  r_ekk417  -1
    y...0314  r_ekk427  -1
    y...0315  MinOBJ..  9
    y...0315  UC..0315  -82
    y...0315  r_ekk381  -1
    y...0316  MinOBJ..  9
    y...0316  UC..0316  -82
    y...0316  r_ekk70   -1
    y...0316  r_ekk126  -1
    y...0316  r_ekk189  -1
    y...0316  r_ekk269  -1
    y...0316  r_ekk278  -1
    y...0316  r_ekk306  -1
    y...0316  r_ekk316  -1
    y...0316  r_ekk352  -0.75
    y...0316  r_ekk379  -0.75
    y...0316  r_ekk386  -1
    y...0316  r_ekk432  -1
    y...0319  MinOBJ..  5
    y...0319  UC..0319  -82
    y...0320  MinOBJ..  5
    y...0320  UC..0320  -82
    y...0320  r_ekk190  -1
    y...0320  r_ekk237  -1
    y...0320  r_ekk246  -1
    y...0320  r_ekk343  -1
    y...0320  r_ekk353  -1
    y...0321  MinOBJ..  9
    y...0321  UC..0321  -82
    y...0322  MinOBJ..  9
    y...0322  UC..0322  -82
    y...0327  MinOBJ..  3
    y...0327  UC..0327  -82
    y...0327  r_ekk256  -1
    y...0327  r_ekk305  -1
    y...0327  r_ekk415  -1
    y...0327  r_ekk421  -1
    y...0328  MinOBJ..  3
    y...0328  UC..0328  -82
    y...0328  r_ekk13   -1
    y...0328  r_ekk62   -1
    y...0335  MinOBJ..  7
    y...0335  UC..0335  -82
    y...0335  r_ekk215  -1
    y...0336  MinOBJ..  7
    y...0336  UC..0336  -82
    y...0336  r_ekk338  -1
    y...0337  MinOBJ..  5
    y...0337  UC..0337  -82
    y...0337  r_ekk238  -1
    y...0337  r_ekk247  -1
    y...0337  r_ekk299  -1
    y...0337  r_ekk325  -1
    y...0337  r_ekk334  -1
    y...0337  r_ekk350  -1
    y...0337  r_ekk360  -1
    y...0337  r_ekk374  -1
    y...0337  r_ekk432  -1
    y...0338  MinOBJ..  5
    y...0338  UC..0338  -82
    y...0339  MinOBJ..  3
    y...0339  UC..0339  -82
    y...0340  MinOBJ..  3
    y...0340  UC..0340  -82
    y...0340  r_ekk11   -1
    y...0347  MinOBJ..  10
    y...0347  UC..0347  -82
    y...0347  r_ekk269  -1
    y...0348  MinOBJ..  10
    y...0348  UC..0348  -82
    y...0349  MinOBJ..  3
    y...0349  UC..0349  -82
    y...0349  r_ekk257  -1
    y...0349  r_ekk311  -1
    y...0349  r_ekk317  -1
    y...0349  r_ekk395  -1
    y...0349  r_ekk406  -1
    y...0350  MinOBJ..  3
    y...0350  UC..0350  -82
    y...0350  r_ekk32   -1
    y...0350  r_ekk108  -0.04052734375
    y...0350  r_ekk196  -0.04052734375
    y...0350  r_ekk251  -0.0303955078125
    y...0350  r_ekk256  -1
    y...0350  r_ekk263  -0.04052734375
    y...0350  r_ekk369  -1
    y...0350  r_ekk383  -1
    y...0357  MinOBJ..  8
    y...0357  UC..0357  -82
    y...0357  r_ekk43   -1
    y...0357  r_ekk188  -1
    y...0357  r_ekk327  -1
    y...0357  r_ekk403  -1
    y...0357  r_ekk419  -0.75
    y...0357  r_ekk428  -0.625
    y...0358  MinOBJ..  8
    y...0358  UC..0358  -82
    y...0358  r_ekk154  -4
    y...0358  r_ekk381  -1
    y...0359  MinOBJ..  5
    y...0359  UC..0359  -82
    y...0359  r_ekk94   -1
    y...0360  MinOBJ..  5
    y...0360  UC..0360  -82
    y...0360  r_ekk366  -0.04052734375
    y...0361  MinOBJ..  9
    y...0361  UC..0361  -82
    y...0362  MinOBJ..  9
    y...0362  UC..0362  -82
    y...0362  r_ekk238  -1
    y...0362  r_ekk247  -1
    y...0362  r_ekk278  -1
    y...0362  r_ekk299  -1
    y...0362  r_ekk325  -1
    y...0362  r_ekk334  -1
    y...0362  r_ekk350  -1
    y...0362  r_ekk360  -1
    y...0362  r_ekk374  -1
    y...0362  r_ekk432  -1
    y...0363  MinOBJ..  6
    y...0363  UC..0363  -82
    y...0363  r_ekk69   -1
    y...0363  r_ekk138  -1
    y...0363  r_ekk339  -0.390243902439028
    y...0363  r_ekk410  -3.1640625
    y...0364  MinOBJ..  6
    y...0364  UC..0364  -82
    y...0364  r_ekk286  -1
    y...0364  r_ekk381  -1
    y...0365  MinOBJ..  8
    y...0365  UC..0365  -82
    y...0365  r_ekk73   -1
    y...0365  r_ekk89   -1
    y...0365  r_ekk336  -1
    y...0365  r_ekk402  -1
    y...0366  MinOBJ..  8
    y...0366  UC..0366  -82
    y...0366  r_ekk30   -1
    y...0366  r_ekk61   -1
    y...0366  r_ekk84   -1
    y...0366  r_ekk199  -0.0123456790123457
    y...0366  r_ekk226  -0.020263671875
    y...0367  MinOBJ..  2
    y...0367  UC..0367  -82
    y...0367  r_ekk20   -1
    y...0367  r_ekk136  -1
    y...0368  MinOBJ..  2
    y...0368  UC..0368  -82
    y...0368  r_ekk136  -1
    y...0368  r_ekk304  -0.640625
    y...0368  r_ekk345  -1
    y...0368  r_ekk357  -1
    y...0368  r_ekk404  -1
    y...0369  MinOBJ..  10
    y...0369  UC..0369  -82
    y...0370  MinOBJ..  10
    y...0370  UC..0370  -82
    y...0370  r_ekk238  -1
    y...0370  r_ekk247  -1
    y...0370  r_ekk299  -1
    y...0370  r_ekk325  -1
    y...0370  r_ekk334  -1
    y...0370  r_ekk350  -1
    y...0370  r_ekk360  -1
    y...0370  r_ekk374  -1
    y...0370  r_ekk432  -1
    y...0371  MinOBJ..  5
    y...0371  UC..0371  -82
    y...0371  r_ekk185  -1
    y...0371  r_ekk222  -1
    y...0371  r_ekk279  -1
    y...0371  r_ekk302  -0.75
    y...0371  r_ekk312  -0.04052734375
    y...0371  r_ekk329  -0.6484375
    y...0371  r_ekk342  -1
    y...0371  r_ekk363  -0.75
    y...0371  r_ekk375  -0.75
    y...0371  r_ekk380  -0.625
    y...0371  r_ekk405  -0.75
    y...0371  r_ekk416  -1
    y...0372  MinOBJ..  5
    y...0372  UC..0372  -82
    y...0373  MinOBJ..  8
    y...0373  UC..0373  -82
    y...0373  r_ekk36   -1
    y...0373  r_ekk116  -1
    y...0373  r_ekk242  -1
    y...0374  MinOBJ..  8
    y...0374  UC..0374  -82
    y...0374  r_ekk146  -1
    y...0374  r_ekk159  -1
    y...0374  r_ekk244  -1
    y...0377  MinOBJ..  5
    y...0377  UC..0377  -82
    y...0377  r_ekk80   -1
    y...0377  r_ekk120  -1
    y...0377  r_ekk142  -0.0987654320987655
    y...0377  r_ekk154  -0.813895781637742
    y...0377  r_ekk406  -1
    y...0378  MinOBJ..  5
    y...0378  UC..0378  -82
    y...0378  r_ekk177  -1
    y...0378  r_ekk192  -1
    y...0378  r_ekk241  -1
    y...0378  r_ekk311  -1
    y...0379  MinOBJ..  1
    y...0379  UC..0379  -82
    y...0379  r_ekk145  -0.830810546875
    y...0379  r_ekk176  -1
    y...0379  r_ekk294  -1
    y...0380  MinOBJ..  1
    y...0380  UC..0380  -82
    y...0380  r_ekk145  -0.020263671875
    y...0380  r_ekk176  -1
    y...0380  r_ekk193  -1
    y...0383  MinOBJ..  6
    y...0383  UC..0383  -82
    y...0383  r_ekk155  -0.780487804878021
    y...0383  r_ekk194  -1
    y...0383  r_ekk259  -0.780487804878021
    y...0383  r_ekk277  -1
    y...0384  MinOBJ..  6
    y...0384  UC..0384  -82
    y...0384  r_ekk106  -1
    y...0384  r_ekk164  -0.75
    y...0384  r_ekk175  -1
    y...0384  r_ekk200  -0.0234375
    y...0384  r_ekk227  -0.020263671875
    y...0384  r_ekk267  -1
    y...0384  r_ekk308  -0.75
    y...0384  r_ekk328  -1
    y...0384  r_ekk338  -1
    y...0385  MinOBJ..  7
    y...0385  UC..0385  -82
    y...0385  r_ekk47   -1
    y...0385  r_ekk75   -1
    y...0386  MinOBJ..  7
    y...0386  UC..0386  -82
    y...0386  r_ekk337  -0.780487804878064
    y...0387  MinOBJ..  5
    y...0387  UC..0387  -82
    y...0388  MinOBJ..  5
    y...0388  UC..0388  -82
    y...0388  r_ekk140  -1
    y...0388  r_ekk160  -1
    y...0388  r_ekk309  -0.625
    y...0388  r_ekk327  -1
    y...0388  r_ekk343  -1
    y...0388  r_ekk353  -1
    y...0388  r_ekk376  -0.0390625
    y...0388  r_ekk394  -1
    y...0388  r_ekk402  -1
    y...0388  r_ekk428  -0.625
    y...0393  MinOBJ..  2
    y...0393  UC..0393  -82
    y...0393  r_ekk29   -1
    y...0393  r_ekk205  -1
    y...0394  MinOBJ..  2
    y...0394  UC..0394  -82
    y...0394  r_ekk5    -1
    y...0395  MinOBJ..  10
    y...0395  UC..0395  -82
    y...0395  r_ekk35   -1
    y...0395  r_ekk55   -1
    y...0395  r_ekk121  -1
    y...0395  r_ekk139  -1
    y...0395  r_ekk186  -1
    y...0395  r_ekk225  -0.04052734375
    y...0395  r_ekk236  -1
    y...0395  r_ekk242  -1
    y...0395  r_ekk271  -0.04052734375
    y...0395  r_ekk293  -0.518750000000001
    y...0396  MinOBJ..  10
    y...0396  UC..0396  -82
    y...0396  r_ekk127  -1
    y...0396  r_ekk159  -1
    y...0396  r_ekk260  -1
    y...0397  MinOBJ..  4
    y...0397  UC..0397  -82
    y...0397  r_ekk17   -1
    y...0398  MinOBJ..  4
    y...0398  UC..0398  -82
    y...0398  r_ekk342  -1
    y...0398  r_ekk410  -3.1640625
    y...0399  MinOBJ..  9
    y...0399  UC..0399  -82
    y...0399  r_ekk28   -1
    y...0399  r_ekk109  -0.830810546875
    y...0399  r_ekk166  -0.540364583333333
    y...0399  r_ekk332  -1
    y...0399  r_ekk426  -1
    y...0400  MinOBJ..  9
    y...0400  UC..0400  -82
    y...0400  r_ekk109  -0.020263671875
    y...0400  r_ekk119  -1
    y...0400  r_ekk166  -0.020263671875
    y...0405  MinOBJ..  6
    y...0405  UC..0405  -82
    y...0405  r_ekk224  -0.780487804878046
    y...0405  r_ekk328  -1
    y...0405  r_ekk338  -1
    y...0406  MinOBJ..  6
    y...0406  UC..0406  -82
    y...0406  r_ekk142  -0.780487804878035
    y...0406  r_ekk154  -4
    y...0407  MinOBJ..  1
    y...0407  UC..0407  -82
    y...0407  r_ekk38   -1
    y...0408  MinOBJ..  1
    y...0408  UC..0408  -82
    y...0408  r_ekk275  -1
    y...0409  MinOBJ..  3
    y...0409  UC..0409  -82
    y...0409  r_ekk34   -1
    y...0409  r_ekk266  -1
    y...0409  r_ekk273  -1
    y...0410  MinOBJ..  3
    y...0410  UC..0410  -82
    y...0410  r_ekk115  -1
    y...0410  r_ekk280  -1
    y...0413  MinOBJ..  1
    y...0413  UC..0413  -82
    y...0413  r_ekk276  -1
    y...0413  r_ekk297  -1
    y...0414  MinOBJ..  1
    y...0414  UC..0414  -82
    y...0414  r_ekk326  -1
    y...0417  MinOBJ..  3
    y...0417  UC..0417  -82
    y...0417  r_ekk69   -1
    y...0417  r_ekk301  -1
    y...0417  r_ekk351  -1
    y...0417  r_ekk372  -1
    y...0417  r_ekk392  -1
    y...0417  r_ekk430  -1
    y...0418  MinOBJ..  3
    y...0418  UC..0418  -82
    y...0418  r_ekk74   -1
    y...0418  r_ekk90   -1
    y...0419  MinOBJ..  2
    y...0419  UC..0419  -82
    y...0420  MinOBJ..  2
    y...0420  UC..0420  -82
    y...0421  MinOBJ..  3
    y...0421  UC..0421  -82
    y...0421  r_ekk28   -1
    y...0422  MinOBJ..  3
    y...0422  UC..0422  -82
    y...0422  r_ekk13   -1
    y...0422  r_ekk233  -1
    y...0422  r_ekk251  -0.0303955078125
    y...0422  r_ekk289  -1
    y...0422  r_ekk336  -1
    y...0422  r_ekk407  -0.75
    y...0423  MinOBJ..  10
    y...0423  UC..0423  -82
    y...0423  r_ekk109  -0.020263671875
    y...0423  r_ekk119  -1
    y...0423  r_ekk166  -0.020263671875
    y...0424  MinOBJ..  10
    y...0424  UC..0424  -82
    y...0424  r_ekk122  -1
    y...0429  MinOBJ..  7
    y...0429  UC..0429  -82
    y...0429  r_ekk364  -0.04052734375
    y...0429  r_ekk365  -0.04052734375
    y...0430  MinOBJ..  7
    y...0430  UC..0430  -82
    y...0430  r_ekk162  -1
    y...0433  MinOBJ..  7
    y...0433  UC..0433  -82
    y...0434  MinOBJ..  7
    y...0434  UC..0434  -82
    y...0434  r_ekk286  -1
    y...0437  MinOBJ..  10
    y...0437  UC..0437  -82
    y...0437  r_ekk36   -1
    y...0437  r_ekk116  -1
    y...0437  r_ekk186  -1
    y...0437  r_ekk225  -0.04052734375
    y...0437  r_ekk242  -1
    y...0437  r_ekk254  -1
    y...0437  r_ekk271  -0.04052734375
    y...0437  r_ekk293  -0.518750000000001
    y...0437  r_ekk339  -0.199999999999999
    y...0437  r_ekk410  -1.62158203125
    y...0438  MinOBJ..  10
    y...0438  UC..0438  -82
    y...0438  r_ekk87   -1
    y...0438  r_ekk211  -1
    y...0438  r_ekk275  -1
    y...0438  r_ekk339  -0.199999999999999
    y...0438  r_ekk372  -1
    y...0438  r_ekk393  -1
    y...0438  r_ekk410  -1.62158203125
    y...0438  r_ekk420  -0.75
    y...0438  r_ekk431  -0.75
    y...0441  MinOBJ..  3
    y...0441  UC..0441  -82
    y...0441  r_ekk88   -1
    y...0441  r_ekk268  -1
    y...0441  r_ekk373  -1
    y...0441  r_ekk417  -1
    y...0441  r_ekk427  -1
    y...0442  MinOBJ..  3
    y...0442  UC..0442  -82
    y...0442  r_ekk181  -1
    y...0442  r_ekk208  -1
    y...0445  MinOBJ..  9
    y...0445  UC..0445  -82
    y...0445  r_ekk65   -1
    y...0445  r_ekk177  -1
    y...0445  r_ekk192  -1
    y...0445  r_ekk217  -1
    y...0445  r_ekk382  -1
    y...0446  MinOBJ..  9
    y...0446  UC..0446  -82
    y...0446  r_ekk219  -1
    y...0447  MinOBJ..  1
    y...0447  UC..0447  -82
    y...0447  r_ekk184  -1
    y...0448  MinOBJ..  1
    y...0448  UC..0448  -82
    y...0448  r_ekk152  -1
    y...0448  r_ekk249  -1
    y...0448  r_ekk281  -0.75
    y...0451  MinOBJ..  3
    y...0451  UC..0451  -82
    y...0452  MinOBJ..  3
    y...0452  UC..0452  -82
    y...0452  r_ekk203  -1
    y...0452  r_ekk230  -1
    y...0452  r_ekk244  -1
    y...0455  MinOBJ..  10
    y...0455  UC..0455  -82
    y...0455  r_ekk101  -1
    y...0455  r_ekk163  -1
    y...0455  r_ekk206  -1
    y...0455  r_ekk265  -1
    y...0455  r_ekk285  -1
    y...0456  MinOBJ..  10
    y...0456  UC..0456  -82
    y...0456  r_ekk118  -1
    y...0456  r_ekk413  -1
    y...0457  MinOBJ..  9
    y...0457  UC..0457  -82
    y...0457  r_ekk34   -1
    y...0457  r_ekk60   -1
    y...0457  r_ekk104  -1
    y...0457  r_ekk187  -1
    y...0458  MinOBJ..  9
    y...0458  UC..0458  -82
    y...0458  r_ekk23   -1
    y...0458  r_ekk59   -1
    y...0458  r_ekk83   -1
    y...0461  MinOBJ..  7
    y...0461  UC..0461  -82
    y...0462  MinOBJ..  7
    y...0462  UC..0462  -82
    y...0463  MinOBJ..  9
    y...0463  UC..0463  -82
    y...0463  r_ekk146  -1
    y...0463  r_ekk159  -1
    y...0463  r_ekk244  -1
    y...0463  r_ekk254  -1
    y...0464  MinOBJ..  9
    y...0464  UC..0464  -82
    y...0464  r_ekk27   -1
    y...0464  r_ekk54   -0.780487804878049
    y...0464  r_ekk81   -1
    y...0464  r_ekk93   -1
    y...0464  r_ekk124  -1
    y...0464  r_ekk155  -0.780487804878021
    y...0464  r_ekk194  -1
    y...0464  r_ekk259  -0.780487804878021
    y...0464  r_ekk277  -1
    y...0464  r_ekk373  -1
    y...0467  MinOBJ..  7
    y...0467  UC..0467  -82
    y...0467  r_ekk89   -1
    y...0467  r_ekk402  -1
    y...0467  r_ekk413  -1
    y...0468  MinOBJ..  7
    y...0468  UC..0468  -82
    y...0469  MinOBJ..  5
    y...0469  UC..0469  -82
    y...0470  MinOBJ..  5
    y...0470  UC..0470  -82
    y...0475  MinOBJ..  3
    y...0475  UC..0475  -82
    y...0476  MinOBJ..  3
    y...0476  UC..0476  -82
    y...0476  r_ekk9    -1
    y...0477  MinOBJ..  3
    y...0477  UC..0477  -82
    y...0477  r_ekk48   -0.6328125
    y...0477  r_ekk336  -1
    y...0477  r_ekk401  -1
    y...0478  MinOBJ..  3
    y...0478  UC..0478  -82
    y...0478  r_ekk48   -0.0078125
    y...0478  r_ekk51   -1
    y...0479  MinOBJ..  9
    y...0479  UC..0479  -82
    y...0479  r_ekk71   -1
    y...0479  r_ekk174  -1
    y...0479  r_ekk234  -0.5
    y...0479  r_ekk394  -1
    y...0479  r_ekk413  -1
    y...0480  MinOBJ..  9
    y...0480  UC..0480  -82
    y...0480  r_ekk381  -1
    y...0483  MinOBJ..  7
    y...0483  UC..0483  -82
    y...0483  r_ekk45   -1
    y...0483  r_ekk189  -1
    y...0483  r_ekk278  -1
    y...0483  r_ekk352  -0.75
    y...0483  r_ekk379  -0.75
    y...0483  r_ekk386  -1
    y...0483  r_ekk387  -0.020263671875
    y...0483  r_ekk432  -1
    y...0484  MinOBJ..  7
    y...0484  UC..0484  -82
    y...0484  r_ekk381  -1
    y...0485  MinOBJ..  9
    y...0485  UC..0485  -82
    y...0486  MinOBJ..  9
    y...0486  UC..0486  -82
    y...0495  MinOBJ..  1
    y...0495  UC..0495  -82
    y...0495  r_ekk149  -1
    y...0495  r_ekk326  -1
    y...0495  r_ekk335  -1
    y...0495  r_ekk398  -1
    y...0496  MinOBJ..  1
    y...0496  UC..0496  -82
    y...0496  r_ekk345  -1
    y...0496  r_ekk396  -1
    y...0496  r_ekk404  -1
    y...0497  MinOBJ..  2
    y...0497  UC..0497  -82
    y...0497  r_ekk327  -1
    y...0497  r_ekk343  -1
    y...0497  r_ekk353  -1
    y...0498  MinOBJ..  2
    y...0498  UC..0498  -82
    y...0498  r_ekk8    -1
    y...0499  MinOBJ..  8
    y...0499  UC..0499  -82
    y...0499  r_ekk381  -1
    y...0500  MinOBJ..  8
    y...0500  UC..0500  -82
    y...0500  r_ekk142  -0.780487804878035
    y...0500  r_ekk154  -4
    y...0500  r_ekk337  -0.780487804878064
    y...0501  MinOBJ..  10
    y...0501  UC..0501  -82
    y...0502  MinOBJ..  10
    y...0502  UC..0502  -82
    y...0502  r_ekk219  -1
    y...0502  r_ekk231  -1
    y...0503  MinOBJ..  2
    y...0503  UC..0503  -82
    y...0503  r_ekk82   -1
    y...0504  MinOBJ..  2
    y...0504  UC..0504  -82
    y...0504  r_ekk25   -1
    y...0507  MinOBJ..  4
    y...0507  UC..0507  -82
    y...0507  r_ekk189  -1
    y...0507  r_ekk269  -1
    y...0507  r_ekk286  -1
    y...0508  MinOBJ..  4
    y...0508  UC..0508  -82
    y...0508  r_ekk6    -1
    y...0511  MinOBJ..  3
    y...0511  UC..0511  -82
    y...0512  MinOBJ..  3
    y...0512  UC..0512  -82
    y...0513  MinOBJ..  2
    y...0513  UC..0513  -82
    y...0513  r_ekk24   -1
    y...0513  r_ekk182  -1
    y...0513  r_ekk229  -1
    y...0514  MinOBJ..  2
    y...0514  UC..0514  -82
    y...0519  MinOBJ..  10
    y...0519  UC..0519  -82
    y...0520  MinOBJ..  10
    y...0520  UC..0520  -82
    y...0521  MinOBJ..  3
    y...0521  UC..0521  -82
    y...0521  r_ekk4    -1
    y...0522  MinOBJ..  3
    y...0522  UC..0522  -82
    y...0522  r_ekk184  -1
    y...0522  r_ekk359  -1
    y...0525  MinOBJ..  1
    y...0525  UC..0525  -82
    y...0525  r_ekk3    -1
    y...0526  MinOBJ..  1
    y...0526  UC..0526  -82
    y...0527  MinOBJ..  3
    y...0527  UC..0527  -82
    y...0527  r_ekk116  -1
    y...0528  MinOBJ..  3
    y...0528  UC..0528  -82
    y...0528  r_ekk35   -1
    y...0529  MinOBJ..  3
    y...0529  UC..0529  -82
    y...0529  r_ekk81   -1
    y...0529  r_ekk93   -1
    y...0529  r_ekk225  -0.04052734375
    y...0529  r_ekk271  -0.04052734375
    y...0529  r_ekk293  -0.518750000000001
    y...0530  MinOBJ..  3
    y...0530  UC..0530  -82
    y...0530  r_ekk293  -0.518750000000001
    y...0530  r_ekk397  -1
    y...0533  MinOBJ..  8
    y...0533  UC..0533  -82
    y...0533  r_ekk132  -1
    y...0533  r_ekk147  -1
    y...0533  r_ekk272  -1
    y...0534  MinOBJ..  8
    y...0534  UC..0534  -82
    y...0534  r_ekk1    -1
    y...0543  MinOBJ..  2
    y...0543  UC..0543  -82
    y...0543  r_ekk101  -1
    y...0544  MinOBJ..  2
    y...0544  UC..0544  -82
    y...0544  r_ekk228  -1
    y...0544  r_ekk266  -1
    y...0544  r_ekk313  -1
    y...0544  r_ekk368  -1
    y...0547  MinOBJ..  7
    y...0547  UC..0547  -82
    y...0547  r_ekk381  -1
    y...0548  MinOBJ..  7
    y...0548  UC..0548  -82
    y...0548  r_ekk103  -1
    y...0548  r_ekk141  -1
    y...0548  r_ekk199  -0.0246913580246914
    y...0548  r_ekk233  -1
    y...0548  r_ekk336  -1
    y...0551  MinOBJ..  5
    y...0551  UC..0551  -82
    y...0551  r_ekk88   -1
    y...0551  r_ekk235  -1
    y...0551  r_ekk255  -1
    y...0551  r_ekk373  -1
    y...0552  MinOBJ..  5
    y...0552  UC..0552  -82
    y...0552  r_ekk124  -1
    y...0552  r_ekk155  -0.780487804878021
    y...0552  r_ekk194  -1
    y...0552  r_ekk259  -0.780487804878021
    y...0552  r_ekk277  -1
    y...0552  r_ekk361  -1
    y...0553  MinOBJ..  2
    y...0553  UC..0553  -82
    y...0554  MinOBJ..  2
    y...0554  UC..0554  -82
    y...0554  r_ekk220  -1
    y...0563  MinOBJ..  1
    y...0563  UC..0563  -82
    y...0564  MinOBJ..  1
    y...0564  UC..0564  -82
    y...0564  r_ekk188  -1
    y...0565  MinOBJ..  6
    y...0565  UC..0565  -82
    y...0565  r_ekk170  -1
    y...0566  MinOBJ..  6
    y...0566  UC..0566  -82
    y...0569  MinOBJ..  8
    y...0569  UC..0569  -82
    y...0569  r_ekk68   -1
    y...0569  r_ekk209  -1
    y...0569  r_ekk227  -0.020263671875
    y...0569  r_ekk267  -1
    y...0570  MinOBJ..  8
    y...0570  UC..0570  -82
    y...0570  r_ekk104  -1
    y...0570  r_ekk128  -0.963414634146342
    y...0570  r_ekk200  -0.6171875
    y...0570  r_ekk280  -1
    y...0570  r_ekk323  -1
    y...0570  r_ekk346  -1
    y...0570  r_ekk355  -1
    y...0570  r_ekk368  -1
    y...0571  MinOBJ..  7
    y...0571  UC..0571  -82
    y...0571  r_ekk165  -0.134146341463416
    y...0572  MinOBJ..  7
    y...0572  UC..0572  -82
    y...0572  r_ekk32   -1
    y...0572  r_ekk108  -0.04052734375
    y...0572  r_ekk196  -0.04052734375
    y...0572  r_ekk199  -0.073321288768443
    y...0572  r_ekk251  -0.0303955078125
    y...0572  r_ekk256  -1
    y...0572  r_ekk263  -0.04052734375
    y...0572  r_ekk369  -1
    y...0572  r_ekk383  -1
    y...0572  r_ekk407  -0.75
    y...0572  r_ekk415  -1
    y...0572  r_ekk421  -1
    y...0577  MinOBJ..  2
    y...0577  UC..0577  -82
    y...0578  MinOBJ..  2
    y...0578  UC..0578  -82
    y...0578  r_ekk286  -1
    y...0579  MinOBJ..  4
    y...0579  UC..0579  -82
    y...0579  r_ekk59   -1
    y...0580  MinOBJ..  4
    y...0580  UC..0580  -82
    y...0580  r_ekk91   -1
    y...0580  r_ekk348  -1
    y...0580  r_ekk354  -0.015625
    y...0580  r_ekk399  -1
    y...0580  r_ekk414  -1
    y...0583  MinOBJ..  7
    y...0583  UC..0583  -82
    y...0583  r_ekk190  -1
    y...0583  r_ekk202  -1
    y...0583  r_ekk226  -0.020263671875
    y...0583  r_ekk232  -1
    y...0583  r_ekk243  -1
    y...0583  r_ekk253  -1
    y...0583  r_ekk412  -1
    y...0583  r_ekk425  -0.75
    y...0584  MinOBJ..  7
    y...0584  UC..0584  -82
    y...0585  MinOBJ..  4
    y...0585  UC..0585  -82
    y...0585  r_ekk165  -0.134146341463416
    y...0586  MinOBJ..  4
    y...0586  UC..0586  -82
    y...0589  MinOBJ..  1
    y...0589  UC..0589  -82
    y...0589  r_ekk39   -1
    y...0590  MinOBJ..  1
    y...0590  UC..0590  -82
    y...0590  r_ekk129  -1
    y...0591  MinOBJ..  5
    y...0591  UC..0591  -82
    y...0591  r_ekk120  -1
    y...0591  r_ekk142  -0.879253236976801
    y...0591  r_ekk154  -4
    y...0591  r_ekk257  -1
    y...0592  MinOBJ..  5
    y...0592  UC..0592  -82
    y...0593  MinOBJ..  1
    y...0593  UC..0593  -82
    y...0593  r_ekk228  -1
    y...0594  MinOBJ..  1
    y...0594  UC..0594  -82
    y...0594  r_ekk95   -1
    y...0595  MinOBJ..  3
    y...0595  UC..0595  -82
    y...0595  r_ekk126  -1
    y...0595  r_ekk306  -1
    y...0595  r_ekk316  -1
    y...0595  r_ekk377  -1
    y...0595  r_ekk387  -0.020263671875
    y...0595  r_ekk399  -1
    y...0595  r_ekk414  -1
    y...0596  MinOBJ..  3
    y...0596  UC..0596  -82
    y...0596  r_ekk238  -1
    y...0596  r_ekk247  -1
    y...0596  r_ekk325  -1
    y...0596  r_ekk360  -1
    y...0597  MinOBJ..  8
    y...0597  UC..0597  -82
    y...0597  r_ekk203  -1
    y...0597  r_ekk230  -1
    y...0597  r_ekk244  -1
    y...0598  MinOBJ..  8
    y...0598  UC..0598  -82
    y...0599  MinOBJ..  1
    y...0599  UC..0599  -82
    y...0599  r_ekk151  -1
    y...0600  MinOBJ..  1
    y...0600  UC..0600  -82
    y...0601  MinOBJ..  7
    y...0601  UC..0601  -82
    y...0601  r_ekk78   -0.780487804878049
    y...0601  r_ekk114  -1
    y...0601  r_ekk135  -1
    y...0601  r_ekk157  -1
    y...0601  r_ekk165  -0.0123456790123457
    y...0601  r_ekk197  -0.0123456790123457
    y...0601  r_ekk210  -1
    y...0602  MinOBJ..  7
    y...0602  UC..0602  -82
    y...0602  r_ekk29   -1
    y...0602  r_ekk63   -1
    y...0602  r_ekk165  -0.0123456790123457
    y...0603  MinOBJ..  1
    y...0603  UC..0603  -82
    y...0603  r_ekk331  -0.709650675455729
    y...0604  MinOBJ..  1
    y...0604  UC..0604  -82
    y...0604  r_ekk290  -1
    y...0609  MinOBJ..  2
    y...0609  UC..0609  -82
    y...0610  MinOBJ..  2
    y...0610  UC..0610  -82
    y...0610  r_ekk284  -1
    y...0610  r_ekk295  -1
    y...0610  r_ekk341  -0.5
    y...0610  r_ekk347  -0.0234375
    y...0610  r_ekk400  -1
    y...0610  r_ekk420  -0.75
    y...0610  r_ekk431  -0.75
    y...0611  MinOBJ..  3
    y...0611  UC..0611  -82
    y...0611  r_ekk354  -0.625
    y...0612  MinOBJ..  3
    y...0612  UC..0612  -82
    y...0612  r_ekk348  -1
    y...0612  r_ekk354  -0.015625
    y...0612  r_ekk371  -0.75
    y...0612  r_ekk377  -1
    y...0612  r_ekk414  -1
    y...0631  MinOBJ..  6
    y...0631  UC..0631  -82
    y...0631  r_ekk108  -0.830810546875
    y...0631  r_ekk122  -1
    y...0631  r_ekk251  -0.0303955078125
    y...0631  r_ekk263  -0.04052734375
    y...0632  MinOBJ..  6
    y...0632  UC..0632  -82
    y...0632  r_ekk28   -1
    y...0632  r_ekk62   -1
    y...0632  r_ekk108  -0.04052734375
    y...0632  r_ekk196  -0.04052734375
    y...0632  r_ekk199  -0.073321288768443
    y...0632  r_ekk251  -0.0303955078125
    y...0632  r_ekk263  -0.04052734375
    y...0633  MinOBJ..  6
    y...0633  UC..0633  -82
    y...0633  r_ekk337  -0.780487804878064
    y...0634  MinOBJ..  6
    y...0634  UC..0634  -82
    y...0634  r_ekk177  -1
    y...0634  r_ekk192  -1
    y...0634  r_ekk217  -1
    y...0634  r_ekk408  -1
    y...0643  MinOBJ..  3
    y...0643  UC..0643  -82
    y...0643  r_ekk14   -1
    y...0643  r_ekk23   -1
    y...0644  MinOBJ..  3
    y...0644  UC..0644  -82
    y...0644  r_ekk117  -1
    y...0644  r_ekk367  -1
    y...0644  r_ekk388  -1
    y...0647  MinOBJ..  10
    y...0647  UC..0647  -82
    y...0647  r_ekk338  -1
    y...0648  MinOBJ..  10
    y...0648  UC..0648  -82
    y...0648  r_ekk2    -1
    y...0648  r_ekk278  -1
    y...0649  MinOBJ..  1
    y...0649  UC..0649  -82
    y...0649  r_ekk22   -1
    y...0650  MinOBJ..  1
    y...0650  UC..0650  -82
    y...0651  MinOBJ..  3
    y...0651  UC..0651  -82
    y...0651  r_ekk394  -1
    y...0652  MinOBJ..  3
    y...0652  UC..0652  -82
    y...0652  r_ekk102  -1
    y...0655  MinOBJ..  6
    y...0655  UC..0655  -82
    y...0656  MinOBJ..  6
    y...0656  UC..0656  -82
    y...0656  r_ekk255  -1
    y...0657  MinOBJ..  5
    y...0657  UC..0657  -82
    y...0657  r_ekk265  -1
    y...0657  r_ekk285  -1
    y...0657  r_ekk299  -1
    y...0657  r_ekk306  -1
    y...0657  r_ekk316  -1
    y...0657  r_ekk334  -1
    y...0657  r_ekk377  -1
    y...0657  r_ekk387  -0.020263671875
    y...0657  r_ekk399  -1
    y...0657  r_ekk414  -1
    y...0658  MinOBJ..  5
    y...0658  UC..0658  -82
    y...0658  r_ekk26   -1
    y...0658  r_ekk57   -1
    y...0658  r_ekk219  -1
    y...0658  r_ekk231  -1
    y...0658  r_ekk240  -1
    y...0661  MinOBJ..  1
    y...0661  UC..0661  -82
    y...0661  r_ekk32   -1
    y...0662  MinOBJ..  1
    y...0662  UC..0662  -82
    y...0662  r_ekk289  -1
    y...0665  MinOBJ..  1
    y...0665  UC..0665  -82
    y...0665  r_ekk268  -1
    y...0665  r_ekk319  -0.04052734375
    y...0665  r_ekk427  -1
    y...0666  MinOBJ..  1
    y...0666  UC..0666  -82
    y...0666  r_ekk81   -1
    y...0667  MinOBJ..  6
    y...0667  UC..0667  -82
    y...0667  r_ekk71   -1
    y...0667  r_ekk174  -1
    y...0667  r_ekk394  -1
    y...0668  MinOBJ..  6
    y...0668  UC..0668  -82
    y...0669  MinOBJ..  6
    y...0669  UC..0669  -82
    y...0669  r_ekk144  -0.6328125
    y...0670  MinOBJ..  6
    y...0670  UC..0670  -82
    y...0670  r_ekk129  -1
    y...0670  r_ekk144  -0.0078125
    y...0670  r_ekk147  -1
    y...0670  r_ekk272  -1
    y...0671  MinOBJ..  2
    y...0671  UC..0671  -82
    y...0672  MinOBJ..  2
    y...0672  UC..0672  -82
    y...0672  r_ekk395  -1
    y...0672  r_ekk406  -1
    y...0673  MinOBJ..  3
    y...0673  UC..0673  -82
    y...0673  r_ekk288  -1
    y...0673  r_ekk301  -1
    y...0673  r_ekk339  -0.390243902439028
    y...0673  r_ekk392  -1
    y...0673  r_ekk410  -3.1640625
    y...0673  r_ekk418  -1
    y...0674  MinOBJ..  3
    y...0674  UC..0674  -82
    y...0674  r_ekk149  -1
    y...0674  r_ekk171  -1
    y...0674  r_ekk297  -1
    y...0675  MinOBJ..  5
    y...0675  UC..0675  -82
    y...0676  MinOBJ..  5
    y...0676  UC..0676  -82
    y...0676  r_ekk30   -1
    y...0676  r_ekk84   -1
    y...0676  r_ekk141  -1
    y...0676  r_ekk199  -0.0980126467931344
    y...0676  r_ekk226  -0.020263671875
    y...0676  r_ekk250  -1
    y...0676  r_ekk411  -0.780487804878049
    y...0676  r_ekk425  -0.75
    y...0679  MinOBJ..  3
    y...0679  UC..0679  -82
    y...0679  r_ekk111  -1
    y...0680  MinOBJ..  3
    y...0680  UC..0680  -82
    y...0680  r_ekk41   -1
    y...0680  r_ekk298  -1
    y...0681  MinOBJ..  2
    y...0681  UC..0681  -82
    y...0681  r_ekk218  -1
    y...0681  r_ekk336  -1
    y...0682  MinOBJ..  2
    y...0682  UC..0682  -82
    y...0682  r_ekk46   -1
    y...0682  r_ekk150  -1
    y...0682  r_ekk237  -1
    y...0682  r_ekk246  -1
    y...0689  MinOBJ..  3
    y...0689  UC..0689  -82
    y...0690  MinOBJ..  3
    y...0690  UC..0690  -82
    y...0693  MinOBJ..  8
    y...0693  UC..0693  -82
    y...0693  r_ekk74   -1
    y...0693  r_ekk252  -1
    y...0693  r_ekk284  -1
    y...0693  r_ekk315  -1
    y...0693  r_ekk324  -1
    y...0693  r_ekk339  -0.390243902439028
    y...0693  r_ekk341  -0.5
    y...0693  r_ekk410  -3.1640625
    y...0694  MinOBJ..  8
    y...0694  UC..0694  -82
    y...0694  r_ekk42   -1
    y...0695  MinOBJ..  10
    y...0695  UC..0695  -82
    y...0695  r_ekk142  -0.780487804878035
    y...0695  r_ekk154  -4
    y...0695  r_ekk327  -1
    y...0695  r_ekk402  -1
    y...0696  MinOBJ..  10
    y...0696  UC..0696  -82
    y...0696  r_ekk102  -1
    y...0696  r_ekk121  -1
    y...0696  r_ekk139  -1
    y...0696  r_ekk174  -1
    y...0696  r_ekk207  -1
    y...0696  r_ekk298  -1
    y...0696  r_ekk376  -0.6015625
    y...0696  r_ekk394  -0.5
    y...0699  MinOBJ..  8
    y...0699  UC..0699  -82
    y...0700  MinOBJ..  8
    y...0700  UC..0700  -82
    y...0700  r_ekk278  -1
    y...0700  r_ekk286  -1
    y...0700  r_ekk325  -1
    y...0700  r_ekk374  -1
    y...0707  MinOBJ..  8
    y...0707  UC..0707  -82
    y...0707  r_ekk7    -1
    y...0707  r_ekk22   -1
    y...0707  r_ekk142  -0.780487804878035
    y...0707  r_ekk154  -4
    y...0707  r_ekk370  -1
    y...0707  r_ekk403  -1
    y...0708  MinOBJ..  8
    y...0708  UC..0708  -82
    y...0708  r_ekk177  -1
    y...0708  r_ekk192  -1
    y...0708  r_ekk217  -1
    y...0715  MinOBJ..  2
    y...0715  UC..0715  -82
    y...0715  r_ekk401  -1
    y...0716  MinOBJ..  2
    y...0716  UC..0716  -82
    y...0716  r_ekk97   -1
    y...0717  MinOBJ..  10
    y...0717  UC..0717  -82
    y...0717  r_ekk142  -0.780487804878035
    y...0717  r_ekk154  -4
    y...0717  r_ekk221  -1
    y...0717  r_ekk258  -1
    y...0717  r_ekk327  -1
    y...0717  r_ekk366  -0.04052734375
    y...0717  r_ekk370  -1
    y...0717  r_ekk384  -1
    y...0717  r_ekk419  -0.75
    y...0717  r_ekk428  -0.625
    y...0718  MinOBJ..  10
    y...0718  UC..0718  -82
    y...0718  r_ekk15   -1
    y...0718  r_ekk50   -0.0078125
    y...0718  r_ekk107  -1
    y...0718  r_ekk264  -1
    y...0719  MinOBJ..  2
    y...0719  UC..0719  -82
    y...0720  MinOBJ..  2
    y...0720  UC..0720  -82
    y...0721  MinOBJ..  1
    y...0721  UC..0721  -82
    y...0721  r_ekk30   -1
    y...0722  MinOBJ..  1
    y...0722  UC..0722  -82
    y...0722  r_ekk130  -1
    y...0722  r_ekk199  -0.0123456790123457
    y...0722  r_ekk243  -1
    y...0725  MinOBJ..  1
    y...0725  UC..0725  -82
    y...0726  MinOBJ..  1
    y...0726  UC..0726  -82
    y...0749  MinOBJ..  1
    y...0749  UC..0749  -82
    y...0750  MinOBJ..  1
    y...0750  UC..0750  -82
    y...0750  r_ekk60   -1
    y...0750  r_ekk292  -0.020263671875
    y...0753  MinOBJ..  8
    y...0753  UC..0753  -82
    y...0753  r_ekk39   -1
    y...0753  r_ekk132  -1
    y...0754  MinOBJ..  8
    y...0754  UC..0754  -82
    y...0754  r_ekk123  -1
    y...0754  r_ekk165  -0.87819933754893
    y...0754  r_ekk287  -1
    y...0754  r_ekk297  -1
    y...0754  r_ekk304  -0.03125
    y...0754  r_ekk345  -1
    y...0754  r_ekk357  -0.048780487804878
    y...0754  r_ekk378  -0.75
    y...0754  r_ekk385  -0.75
    y...0754  r_ekk396  -1
    y...0754  r_ekk404  -1
    y...0754  r_ekk422  -0.75
    y...0754  r_ekk429  -1
    y...0763  MinOBJ..  3
    y...0763  UC..0763  -82
    y...0763  r_ekk240  -1
    y...0764  MinOBJ..  3
    y...0764  UC..0764  -82
    y...0764  r_ekk26   -1
    y...0764  r_ekk219  -1
    y...0764  r_ekk231  -1
    y...0773  MinOBJ..  2
    y...0773  UC..0773  -82
    y...0774  MinOBJ..  2
    y...0774  UC..0774  -82
    y...0774  r_ekk338  -1
    y...0781  MinOBJ..  9
    y...0781  UC..0781  -82
    y...0781  r_ekk286  -1
    y...0781  r_ekk381  -1
    y...0782  MinOBJ..  9
    y...0782  UC..0782  -82
    y...0782  r_ekk72   -1
    y...0783  MinOBJ..  8
    y...0783  UC..0783  -82
    y...0783  r_ekk252  -1
    y...0783  r_ekk274  -1
    y...0783  r_ekk307  -1
    y...0783  r_ekk324  -1
    y...0784  MinOBJ..  8
    y...0784  UC..0784  -82
    y...0785  MinOBJ..  10
    y...0785  UC..0785  -82
    y...0785  r_ekk153  -1
    y...0785  r_ekk165  -0.134146341463416
    y...0785  r_ekk191  -1
    y...0785  r_ekk210  -1
    y...0785  r_ekk223  -1
    y...0785  r_ekk270  -1
    y...0786  MinOBJ..  10
    y...0786  UC..0786  -82
    y...0786  r_ekk74   -1
    y...0786  r_ekk252  -1
    y...0786  r_ekk339  -0.390243902439028
    y...0786  r_ekk410  -3.1640625
    y...0787  MinOBJ..  1
    y...0787  UC..0787  -82
    y...0788  MinOBJ..  1
    y...0788  UC..0788  -82
    y...0791  MinOBJ..  8
    y...0791  UC..0791  -82
    y...0791  r_ekk0    -1
    y...0791  r_ekk21   -1
    y...0791  r_ekk113  -1
    y...0791  r_ekk134  -1
    y...0791  r_ekk208  -1
    y...0792  MinOBJ..  8
    y...0792  UC..0792  -82
    y...0792  r_ekk136  -1
    y...0792  r_ekk287  -1
    y...0793  MinOBJ..  10
    y...0793  UC..0793  -82
    y...0793  r_ekk105  -1
    y...0793  r_ekk333  -1
    y...0794  MinOBJ..  10
    y...0794  UC..0794  -82
    y...0794  r_ekk71   -1
    y...0794  r_ekk102  -1
    y...0794  r_ekk174  -1
    y...0794  r_ekk207  -1
    y...0794  r_ekk234  -0.5
    y...0794  r_ekk394  -0.5
    y...0794  r_ekk413  -1
    y...0799  MinOBJ..  7
    y...0799  UC..0799  -82
    y...0799  r_ekk197  -0.914784703402589
    y...0800  MinOBJ..  7
    y...0800  UC..0800  -82
    y...0800  r_ekk197  -0.0975609756097569
    y...0800  r_ekk416  -1
    y...0801  MinOBJ..  4
    y...0801  UC..0801  -82
    y...0802  MinOBJ..  4
    y...0802  UC..0802  -82
    y...0802  r_ekk108  -0.04052734375
    y...0802  r_ekk196  -0.04052734375
    y...0802  r_ekk251  -0.0303955078125
    y...0802  r_ekk263  -0.04052734375
    y...0802  r_ekk289  -1
    y...0802  r_ekk314  -1
    y...0802  r_ekk336  -1
    y...0802  r_ekk356  -0.0234375
    y...0802  r_ekk401  -1
    y...0803  MinOBJ..  6
    y...0803  UC..0803  -82
    y...0804  MinOBJ..  6
    y...0804  UC..0804  -82
    y...0805  MinOBJ..  1
    y...0805  UC..0805  -82
    y...0805  r_ekk268  -1
    y...0805  r_ekk417  -1
    y...0806  MinOBJ..  1
    y...0806  UC..0806  -82
    y...0806  r_ekk361  -1
    y...0815  MinOBJ..  7
    y...0815  UC..0815  -82
    y...0816  MinOBJ..  7
    y...0816  UC..0816  -82
    y...0823  MinOBJ..  9
    y...0823  UC..0823  -82
    y...0823  r_ekk16   -1
    y...0823  r_ekk201  -1
    y...0823  r_ekk215  -1
    y...0824  MinOBJ..  9
    y...0824  UC..0824  -82
    y...0829  MinOBJ..  2
    y...0829  UC..0829  -82
    y...0830  MinOBJ..  2
    y...0830  UC..0830  -82
    y...0830  r_ekk229  -1
    y...0830  r_ekk248  -1
    y...0830  r_ekk390  -1
    y...0830  r_ekk397  -1
    y...0837  MinOBJ..  8
    y...0837  UC..0837  -82
    y...0837  r_ekk47   -1
    y...0837  r_ekk75   -1
    y...0837  r_ekk110  -0.975609756097561
    y...0837  r_ekk381  -1
    y...0838  MinOBJ..  8
    y...0838  UC..0838  -82
    y...0838  r_ekk41   -1
    y...0838  r_ekk98   -1
    y...0838  r_ekk148  -1
    y...0839  MinOBJ..  8
    y...0839  UC..0839  -82
    y...0839  r_ekk381  -1
    y...0840  MinOBJ..  8
    y...0840  UC..0840  -82
    y...0840  r_ekk61   -1
    y...0840  r_ekk103  -1
    y...0840  r_ekk199  -0.0123456790123457
    y...0841  MinOBJ..  1
    y...0841  UC..0841  -82
    y...0841  r_ekk361  -1
    y...0841  r_ekk427  -1
    y...0842  MinOBJ..  1
    y...0842  UC..0842  -82
    y...0842  r_ekk417  -1
    y...0849  MinOBJ..  7
    y...0849  UC..0849  -82
    y...0850  MinOBJ..  7
    y...0850  UC..0850  -82
    y...0853  MinOBJ..  9
    y...0853  UC..0853  -82
    y...0854  MinOBJ..  9
    y...0854  UC..0854  -82
    y...0855  MinOBJ..  9
    y...0855  UC..0855  -82
    y...0855  r_ekk77   -0.6328125
    y...0855  r_ekk133  -1
    y...0855  r_ekk172  -1
    y...0855  r_ekk197  -0.0975609756097569
    y...0855  r_ekk222  -1
    y...0855  r_ekk302  -0.75
    y...0855  r_ekk312  -0.04052734375
    y...0855  r_ekk329  -0.6484375
    y...0855  r_ekk342  -1
    y...0855  r_ekk363  -0.75
    y...0855  r_ekk375  -0.75
    y...0855  r_ekk380  -0.625
    y...0856  MinOBJ..  9
    y...0856  UC..0856  -82
    y...0856  r_ekk48   -0.0078125
    y...0856  r_ekk51   -1
    y...0856  r_ekk77   -0.0078125
    y...0856  r_ekk108  -0.04052734375
    y...0856  r_ekk167  -1
    y...0856  r_ekk196  -0.04052734375
    y...0856  r_ekk199  -0.073321288768443
    y...0856  r_ekk251  -0.0303955078125
    y...0856  r_ekk263  -0.04052734375
    y...0856  r_ekk289  -1
    y...0856  r_ekk305  -1
    y...0856  r_ekk314  -1
    y...0856  r_ekk356  -0.0234375
    y...0856  r_ekk391  -0.75
    y...0856  r_ekk407  -0.75
    y...0856  r_ekk415  -1
    y...0857  MinOBJ..  8
    y...0857  UC..0857  -82
    y...0857  r_ekk197  -0.0975609756097569
    y...0858  MinOBJ..  8
    y...0858  UC..0858  -82
    y...0869  MinOBJ..  5
    y...0869  UC..0869  -82
    y...0869  r_ekk153  -1
    y...0869  r_ekk191  -1
    y...0869  r_ekk210  -1
    y...0869  r_ekk270  -1
    y...0870  MinOBJ..  5
    y...0870  UC..0870  -82
    y...0870  r_ekk58   -1
    y...0875  MinOBJ..  6
    y...0875  UC..0875  -82
    y...0875  r_ekk387  -0.553873697916667
    y...0876  MinOBJ..  6
    y...0876  UC..0876  -82
    y...0876  r_ekk70   -1
    y...0876  r_ekk126  -1
    y...0876  r_ekk179  -0.780487804878049
    y...0876  r_ekk282  -1
    y...0876  r_ekk306  -1
    y...0876  r_ekk316  -1
    y...0876  r_ekk379  -0.75
    y...0876  r_ekk386  -1
    y...0876  r_ekk387  -0.020263671875
    y...0876  r_ekk432  -1
    y...0879  MinOBJ..  5
    y...0879  UC..0879  -82
    y...0879  r_ekk278  -1
    y...0880  MinOBJ..  5
    y...0880  UC..0880  -82
    y...0880  r_ekk381  -1
    y...0883  MinOBJ..  4
    y...0883  UC..0883  -82
    y...0883  r_ekk413  -1
    y...0884  MinOBJ..  4
    y...0884  UC..0884  -82
    y...0884  r_ekk79   -1
    y...0884  r_ekk170  -1
    y...0884  r_ekk333  -1
    y...0885  MinOBJ..  10
    y...0885  UC..0885  -82
    y...0886  MinOBJ..  10
    y...0886  UC..0886  -82
    y...0887  MinOBJ..  9
    y...0887  UC..0887  -82
    y...0887  r_ekk96   -1
    y...0887  r_ekk135  -1
    y...0887  r_ekk153  -1
    y...0887  r_ekk191  -1
    y...0887  r_ekk210  -1
    y...0887  r_ekk270  -1
    y...0888  MinOBJ..  9
    y...0888  UC..0888  -82
    y...0888  r_ekk40   -1
    y...0888  r_ekk340  -1
    y...0899  MinOBJ..  10
    y...0899  UC..0899  -82
    y...0899  r_ekk194  -1
    y...0899  r_ekk259  -0.780487804878021
    y...0899  r_ekk277  -1
    y...0899  r_ekk381  -1
    y...0900  MinOBJ..  10
    y...0900  UC..0900  -82
    y...0900  r_ekk74   -1
    y...0900  r_ekk252  -1
    y...0900  r_ekk339  -0.390243902439028
    y...0900  r_ekk410  -3.1640625
    y...0901  MinOBJ..  7
    y...0901  UC..0901  -82
    y...0902  MinOBJ..  7
    y...0902  UC..0902  -82
    y...0905  MinOBJ..  5
    y...0905  UC..0905  -82
    y...0905  r_ekk125  -1
    y...0905  r_ekk212  -1
    y...0905  r_ekk224  -0.780487804878046
    y...0905  r_ekk328  -1
    y...0906  MinOBJ..  5
    y...0906  UC..0906  -82
    y...0906  r_ekk148  -1
    y...0906  r_ekk212  -1
    y...0906  r_ekk224  -0.780487804878046
    y...0906  r_ekk328  -1
    y...0911  MinOBJ..  5
    y...0911  UC..0911  -82
    y...0911  r_ekk430  -1
    y...0912  MinOBJ..  5
    y...0912  UC..0912  -82
    y...0912  r_ekk104  -1
    y...0912  r_ekk280  -1
    y...0913  MinOBJ..  9
    y...0913  UC..0913  -82
    y...0913  r_ekk37   -1
    y...0913  r_ekk56   -1
    y...0913  r_ekk114  -1
    y...0913  r_ekk131  -1
    y...0913  r_ekk157  -1
    y...0913  r_ekk197  -0.0246913580246914
    y...0914  MinOBJ..  9
    y...0914  UC..0914  -82
    y...0914  r_ekk165  -0.134146341463416
    y...0915  MinOBJ..  8
    y...0915  UC..0915  -82
    y...0915  r_ekk339  -0.390243902439028
    y...0915  r_ekk410  -3.1640625
    y...0916  MinOBJ..  8
    y...0916  UC..0916  -82
    y...0916  r_ekk104  -1
    y...0916  r_ekk269  -1
    y...0916  r_ekk280  -1
    y...0916  r_ekk286  -1
    y...0917  MinOBJ..  1
    y...0917  UC..0917  -82
    y...0917  r_ekk176  -1
    y...0917  r_ekk212  -1
    y...0918  MinOBJ..  1
    y...0918  UC..0918  -82
    y...0918  r_ekk125  -1
    y...0918  r_ekk224  -0.780487804878046
    y...0918  r_ekk328  -1
    y...0919  MinOBJ..  1
    y...0919  UC..0919  -82
    y...0920  MinOBJ..  1
    y...0920  UC..0920  -82
    y...0921  MinOBJ..  6
    y...0921  UC..0921  -82
    y...0921  r_ekk127  -1
    y...0921  r_ekk165  -0.134146341463416
    y...0921  r_ekk214  -0.04052734375
    y...0921  r_ekk260  -1
    y...0921  r_ekk261  -0.04052734375
    y...0921  r_ekk281  -0.75
    y...0921  r_ekk318  -0.6484375
    y...0921  r_ekk321  -0.04052734375
    y...0921  r_ekk344  -0.6484375
    y...0921  r_ekk364  -0.04052734375
    y...0921  r_ekk365  -0.04052734375
    y...0921  r_ekk433  -0.046875
    y...0922  MinOBJ..  6
    y...0922  UC..0922  -82
    y...0922  r_ekk286  -1
    y...0923  MinOBJ..  4
    y...0923  UC..0923  -82
    y...0924  MinOBJ..  4
    y...0924  UC..0924  -82
    y...0924  r_ekk111  -1
    y...0924  r_ekk175  -1
    y...0924  r_ekk262  -0.020263671875
    y...0925  MinOBJ..  6
    y...0925  UC..0925  -82
    y...0925  r_ekk286  -1
    y...0926  MinOBJ..  6
    y...0926  UC..0926  -82
    y...0926  r_ekk277  -1
    y...0937  MinOBJ..  8
    y...0937  UC..0937  -82
    y...0937  r_ekk339  -0.390243902439028
    y...0937  r_ekk410  -3.1640625
    y...0938  MinOBJ..  8
    y...0938  UC..0938  -82
    y...0938  r_ekk11   -1
    y...0945  MinOBJ..  6
    y...0945  UC..0945  -82
    y...0945  r_ekk408  -1
    y...0946  MinOBJ..  6
    y...0946  UC..0946  -82
    y...0946  r_ekk24   -1
    y...0946  r_ekk65   -1
    y...0946  r_ekk182  -1
    y...0946  r_ekk217  -1
    y...0946  r_ekk390  -1
    y...0947  MinOBJ..  1
    y...0947  UC..0947  -82
    y...0947  r_ekk117  -1
    y...0948  MinOBJ..  1
    y...0948  UC..0948  -82
    y...0953  MinOBJ..  2
    y...0953  UC..0953  -82
    y...0953  r_ekk392  -1
    y...0953  r_ekk430  -1
    y...0954  MinOBJ..  2
    y...0954  UC..0954  -82
    y...0961  MinOBJ..  8
    y...0961  UC..0961  -82
    y...0961  r_ekk105  -1
    y...0961  r_ekk333  -1
    y...0962  MinOBJ..  8
    y...0962  UC..0962  -82
    y...0962  r_ekk381  -1
    y...0975  MinOBJ..  10
    y...0975  UC..0975  -82
    y...0975  r_ekk25   -1
    y...0975  r_ekk67   -1
    y...0975  r_ekk321  -0.04052734375
    y...0975  r_ekk433  -0.046875
    y...0976  MinOBJ..  10
    y...0976  UC..0976  -82
    y...0976  r_ekk76   -0.6171875
    y...0976  r_ekk249  -1
    y...0979  MinOBJ..  2
    y...0979  UC..0979  -82
    y...0980  MinOBJ..  2
    y...0980  UC..0980  -82
    y...0981  MinOBJ..  4
    y...0981  UC..0981  -82
    y...0981  r_ekk353  -1
    y...0982  MinOBJ..  4
    y...0982  UC..0982  -82
    y...0982  r_ekk140  -1
    y...0982  r_ekk160  -1
    y...0982  r_ekk309  -0.625
    y...0982  r_ekk327  -1
    y...0982  r_ekk376  -0.0390625
    y...0982  r_ekk428  -0.625
    y...0985  MinOBJ..  7
    y...0985  UC..0985  -82
    y...0986  MinOBJ..  7
    y...0986  UC..0986  -82
    y...0986  r_ekk102  -1
    y...0986  r_ekk413  -1
    y...0987  MinOBJ..  10
    y...0987  UC..0987  -82
    y...0987  r_ekk15   -1
    y...0987  r_ekk309  -0.625
    y...0987  r_ekk376  -0.0390625
    y...0987  r_ekk403  -1
    y...0988  MinOBJ..  10
    y...0988  UC..0988  -82
    y...0988  r_ekk50   -0.6328125
    y...0988  r_ekk73   -1
    y...0988  r_ekk89   -1
    y...0988  r_ekk107  -1
    y...0988  r_ekk237  -1
    y...0988  r_ekk246  -1
    y...0988  r_ekk258  -1
    y...0988  r_ekk264  -1
    y...0988  r_ekk402  -1
    y...0991  MinOBJ..  3
    y...0991  UC..0991  -82
    y...0991  r_ekk177  -1
    y...0992  MinOBJ..  3
    y...0992  UC..0992  -82
    y...0992  r_ekk142  -0.780487804878035
    y...0992  r_ekk154  -4
    y...0992  r_ekk257  -1
    y...0992  r_ekk317  -1
    y...0995  MinOBJ..  9
    y...0995  UC..0995  -82
    y...0995  r_ekk136  -1
    y...0995  r_ekk255  -1
    y...0995  r_ekk304  -0.609375
    y...0995  r_ekk357  -0.975609756097561
    y...0996  MinOBJ..  9
    y...0996  UC..0996  -82
    y...0996  r_ekk20   -1
    y...0996  r_ekk21   -1
    y...0996  r_ekk105  -1
    y...0996  r_ekk333  -1
    y...0999  MinOBJ..  9
    y...0999  UC..0999  -82
    y...0999  r_ekk142  -0.780487804878035
    y...0999  r_ekk154  -4
    y...0999  r_ekk317  -1
    y...0999  r_ekk395  -1
    y...0999  r_ekk406  -1
    y...1000  MinOBJ..  9
    y...1000  UC..1000  -82
    y...1000  r_ekk286  -1
    y...1000  r_ekk381  -1
    y...1001  MinOBJ..  10
    y...1001  UC..1001  -82
    y...1001  r_ekk3    -1
    y...1001  r_ekk100  -1
    y...1001  r_ekk173  -1
    y...1001  r_ekk220  -1
    y...1001  r_ekk268  -1
    y...1001  r_ekk290  -1
    y...1001  r_ekk296  -1
    y...1001  r_ekk303  -0.04052734375
    y...1001  r_ekk319  -0.04052734375
    y...1001  r_ekk330  -0.6328125
    y...1001  r_ekk331  -0.0346171061197917
    y...1001  r_ekk361  -1
    y...1001  r_ekk417  -1
    y...1001  r_ekk427  -1
    y...1002  MinOBJ..  10
    y...1002  UC..1002  -82
    y...1002  r_ekk6    -1
    y...1002  r_ekk45   -1
    y...1002  r_ekk278  -1
    y...1002  r_ekk303  -0.830810546875
    y...1002  r_ekk319  -0.830810546875
    y...1002  r_ekk330  -0.0390625
    y...1002  r_ekk331  -0.0519256591796875
    y...1002  r_ekk352  -0.75
    y...1002  r_ekk386  -1
    y...1002  r_ekk387  -0.020263671875
    y...1003  MinOBJ..  4
    y...1003  UC..1003  -82
    y...1003  r_ekk274  -1
    y...1003  r_ekk295  -1
    y...1003  r_ekk347  -0.0234375
    y...1003  r_ekk362  -0.75
    y...1003  r_ekk400  -1
    y...1003  r_ekk431  -0.75
    y...1004  MinOBJ..  4
    y...1004  UC..1004  -82
    y...1005  MinOBJ..  1
    y...1005  UC..1005  -82
    y...1006  MinOBJ..  1
    y...1006  UC..1006  -82
    y...1006  r_ekk288  -1
    y...1006  r_ekk339  -0.1
    y...1006  r_ekk362  -0.75
    y...1006  r_ekk410  -3.1640625
    y...1006  r_ekk423  -1
    y...1006  r_ekk430  -1
    y...1007  MinOBJ..  6
    y...1007  UC..1007  -82
    y...1008  MinOBJ..  6
    y...1008  UC..1008  -82
    y...1009  MinOBJ..  9
    y...1009  UC..1009  -82
    y...1009  r_ekk215  -1
    y...1010  MinOBJ..  9
    y...1010  UC..1010  -82
    y...1010  r_ekk16   -1
    y...1010  r_ekk245  -1
    y...1010  r_ekk279  -1
    y...1010  r_ekk405  -0.75
    y...1011  MinOBJ..  9
    y...1011  UC..1011  -82
    y...1012  MinOBJ..  9
    y...1012  UC..1012  -82
    y...1012  r_ekk123  -1
    y...1012  r_ekk149  -1
    y...1012  r_ekk171  -1
    y...1012  r_ekk326  -1
    y...1012  r_ekk385  -0.75
    y...1012  r_ekk392  -1
    y...1012  r_ekk418  -1
    y...1012  r_ekk422  -0.75
    y...1012  r_ekk429  -1
    y...1013  MinOBJ..  2
    y...1013  UC..1013  -82
    y...1013  r_ekk169  -1
    y...1013  r_ekk216  -1
    y...1013  r_ekk409  -1
    y...1014  MinOBJ..  2
    y...1014  UC..1014  -82
    y...1014  r_ekk213  -0.975609756097561
    y...1015  MinOBJ..  9
    y...1015  UC..1015  -82
    y...1015  r_ekk381  -1
    y...1016  MinOBJ..  9
    y...1016  UC..1016  -82
    y...1016  r_ekk123  -1
    y...1016  r_ekk149  -1
    y...1016  r_ekk171  -1
    y...1016  r_ekk276  -1
    y...1016  r_ekk297  -1
    y...1016  r_ekk326  -1
    y...1016  r_ekk335  -1
    y...1016  r_ekk385  -0.75
    y...1016  r_ekk392  -1
    y...1016  r_ekk398  -1
    y...1016  r_ekk418  -1
    y...1016  r_ekk422  -0.75
    y...1016  r_ekk429  -1
    y...1017  MinOBJ..  9
    y...1017  UC..1017  -82
    y...1017  r_ekk2    -1
    y...1017  r_ekk282  -1
    y...1018  MinOBJ..  9
    y...1018  UC..1018  -82
    y...1018  r_ekk189  -1
    y...1018  r_ekk269  -1
    y...1018  r_ekk286  -1
    y...1019  MinOBJ..  2
    y...1019  UC..1019  -82
    y...1020  MinOBJ..  2
    y...1020  UC..1020  -82
    y...1021  MinOBJ..  5
    y...1021  UC..1021  -82
    y...1021  r_ekk36   -1
    y...1021  r_ekk254  -1
    y...1022  MinOBJ..  5
    y...1022  UC..1022  -82
    y...1022  r_ekk55   -1
    y...1022  r_ekk139  -1
    y...1023  MinOBJ..  3
    y...1023  UC..1023  -82
    y...1024  MinOBJ..  3
    y...1024  UC..1024  -82
    y...1025  MinOBJ..  10
    y...1025  UC..1025  -82
    y...1025  r_ekk245  -1
    y...1025  r_ekk279  -1
    y...1025  r_ekk405  -0.75
    y...1026  MinOBJ..  10
    y...1026  UC..1026  -82
    y...1026  r_ekk349  -1
    y...1026  r_ekk357  -0.048780487804878
    y...1027  MinOBJ..  1
    y...1027  UC..1027  -82
    y...1027  r_ekk345  -1
    y...1027  r_ekk357  -0.048780487804878
    y...1027  r_ekk404  -1
    y...1028  MinOBJ..  1
    y...1028  UC..1028  -82
    y...1029  MinOBJ..  2
    y...1029  UC..1029  -82
    y...1029  r_ekk46   -1
    y...1029  r_ekk137  -1
    y...1029  r_ekk142  -0.0987654320987655
    y...1029  r_ekk218  -1
    y...1029  r_ekk409  -1
    y...1030  MinOBJ..  2
    y...1030  UC..1030  -82
    y...1030  r_ekk107  -1
    y...1030  r_ekk142  -0.0987654320987655
    y...1030  r_ekk154  -0.813895781637741
    y...1030  r_ekk161  -0.790123456790124
    y...1030  r_ekk258  -1
    y...1031  MinOBJ..  3
    y...1031  UC..1031  -82
    y...1032  MinOBJ..  3
    y...1032  UC..1032  -82
    y...1033  MinOBJ..  5
    y...1033  UC..1033  -82
    y...1033  r_ekk44   -1
    y...1033  r_ekk255  -1
    y...1034  MinOBJ..  5
    y...1034  UC..1034  -82
    y...1034  r_ekk18   -1
    y...1035  MinOBJ..  7
    y...1035  UC..1035  -82
    y...1035  r_ekk104  -1
    y...1035  r_ekk280  -1
    y...1036  MinOBJ..  7
    y...1036  UC..1036  -82
    y...1036  r_ekk70   -1
    y...1036  r_ekk126  -1
    y...1036  r_ekk189  -1
    y...1036  r_ekk278  -1
    y...1036  r_ekk306  -1
    y...1036  r_ekk316  -1
    y...1036  r_ekk352  -0.75
    y...1036  r_ekk379  -0.75
    y...1036  r_ekk386  -1
    y...1037  MinOBJ..  3
    y...1037  UC..1037  -82
    y...1037  r_ekk194  -1
    y...1037  r_ekk259  -0.780487804878021
    y...1037  r_ekk277  -1
    y...1037  r_ekk381  -1
    y...1038  MinOBJ..  3
    y...1038  UC..1038  -82
    y...1038  r_ekk124  -1
    y...1038  r_ekk417  -1
    y...1039  MinOBJ..  3
    y...1039  UC..1039  -82
    y...1040  MinOBJ..  3
    y...1040  UC..1040  -82
    y...1041  MinOBJ..  8
    y...1041  UC..1041  -82
    y...1042  MinOBJ..  8
    y...1042  UC..1042  -82
    y...1043  MinOBJ..  2
    y...1043  UC..1043  -82
    y...1044  MinOBJ..  2
    y...1044  UC..1044  -82
    y...1045  MinOBJ..  1
    y...1045  UC..1045  -82
    y...1046  MinOBJ..  1
    y...1046  UC..1046  -82
    y...1046  r_ekk301  -1
    y...1046  r_ekk351  -1
    y...1047  MinOBJ..  4
    y...1047  UC..1047  -82
    y...1048  MinOBJ..  4
    y...1048  UC..1048  -82
    y...1048  r_ekk24   -1
    y...1048  r_ekk65   -1
    y...1049  MinOBJ..  10
    y...1049  UC..1049  -82
    y...1050  MinOBJ..  10
    y...1050  UC..1050  -82
    y...1051  MinOBJ..  2
    y...1051  UC..1051  -82
    y...1051  r_ekk339  -0.390243902439028
    y...1051  r_ekk351  -1
    y...1051  r_ekk372  -1
    y...1051  r_ekk392  -1
    y...1051  r_ekk410  -3.1640625
    y...1051  r_ekk430  -1
    y...1052  MinOBJ..  2
    y...1052  UC..1052  -82
    y...1052  r_ekk33   -1
    y...1053  MinOBJ..  7
    y...1053  UC..1053  -82
    y...1053  r_ekk176  -1
    y...1053  r_ekk193  -1
    y...1053  r_ekk212  -1
    y...1054  MinOBJ..  7
    y...1054  UC..1054  -82
    y...1055  MinOBJ..  9
    y...1055  UC..1055  -82
    y...1056  MinOBJ..  9
    y...1056  UC..1056  -82
    y...1057  MinOBJ..  6
    y...1057  UC..1057  -82
    y...1058  MinOBJ..  6
    y...1058  UC..1058  -82
    y...1059  MinOBJ..  6
    y...1059  UC..1059  -82
    y...1059  r_ekk263  -0.830810546875
    y...1060  MinOBJ..  6
    y...1060  UC..1060  -82
    y...1060  r_ekk263  -0.04052734375
    y...1060  r_ekk401  -1
    y...1061  MinOBJ..  7
    y...1061  UC..1061  -82
    y...1061  r_ekk83   -1
    y...1061  r_ekk91   -1
    y...1061  r_ekk358  -1
    y...1061  r_ekk367  -1
    y...1061  r_ekk388  -1
    y...1062  MinOBJ..  7
    y...1062  UC..1062  -82
    y...1062  r_ekk206  -1
    y...1062  r_ekk285  -1
    y...1063  MinOBJ..  4
    y...1063  UC..1063  -82
    y...1063  r_ekk85   -1
    y...1063  r_ekk300  -1
    y...1063  r_ekk304  -0.03125
    y...1063  r_ekk322  -1
    y...1063  r_ekk349  -1
    y...1063  r_ekk357  -0.048780487804878
    y...1063  r_ekk378  -0.75
    y...1063  r_ekk396  -1
    y...1064  MinOBJ..  4
    y...1064  UC..1064  -82
    y...1065  MinOBJ..  6
    y...1065  UC..1065  -82
    y...1065  r_ekk123  -1
    y...1065  r_ekk272  -1
    y...1065  r_ekk297  -1
    y...1065  r_ekk429  -1
    y...1066  MinOBJ..  6
    y...1066  UC..1066  -82
    y...1066  r_ekk105  -1
    y...1066  r_ekk333  -1
    y...1067  MinOBJ..  7
    y...1067  UC..1067  -82
    y...1068  MinOBJ..  7
    y...1068  UC..1068  -82
    y...1069  MinOBJ..  8
    y...1069  UC..1069  -82
    y...1069  r_ekk87   -1
    y...1069  r_ekk211  -1
    y...1069  r_ekk339  -0.2
    y...1069  r_ekk410  -1.62158203125
    y...1069  r_ekk420  -0.75
    y...1069  r_ekk431  -0.75
    y...1070  MinOBJ..  8
    y...1070  UC..1070  -82
    y...1070  r_ekk177  -1
    y...1070  r_ekk192  -1
    y...1070  r_ekk339  -0.390243902439028
    y...1070  r_ekk410  -3.1640625
    y...1070  r_ekk431  -0.75
    y...1071  MinOBJ..  6
    y...1071  UC..1071  -82
    y...1072  MinOBJ..  6
    y...1072  UC..1072  -82
    y...1072  r_ekk278  -1
    y...1073  MinOBJ..  2
    y...1073  UC..1073  -82
    y...1073  r_ekk229  -1
    y...1073  r_ekk248  -1
    y...1073  r_ekk389  -1
    y...1073  r_ekk408  -1
    y...1074  MinOBJ..  2
    y...1074  UC..1074  -82
    y...1074  r_ekk275  -1
    y...1074  r_ekk339  -0.390243902439028
    y...1074  r_ekk372  -1
    y...1074  r_ekk393  -1
    y...1074  r_ekk410  -3.1640625
    y...1075  MinOBJ..  5
    y...1075  UC..1075  -82
    y...1075  r_ekk0    -1
    y...1075  r_ekk378  -0.75
    y...1075  r_ekk385  -0.75
    y...1075  r_ekk396  -1
    y...1075  r_ekk422  -0.75
    y...1076  MinOBJ..  5
    y...1076  UC..1076  -82
    y...1076  r_ekk134  -1
    y...1076  r_ekk208  -1
    y...1077  MinOBJ..  1
    y...1077  UC..1077  -82
    y...1077  r_ekk14   -1
    y...1078  MinOBJ..  1
    y...1078  UC..1078  -82
    y...1078  r_ekk273  -1
    y...1079  MinOBJ..  7
    y...1079  UC..1079  -82
    y...1079  r_ekk61   -1
    y...1079  r_ekk130  -1
    y...1079  r_ekk199  -0.0123456790123457
    y...1079  r_ekk250  -1
    y...1079  r_ekk411  -0.780487804878049
    y...1080  MinOBJ..  7
    y...1080  UC..1080  -82
    y...1080  r_ekk199  -0.939024390243903
    y...1080  r_ekk253  -1
    y...1081  MinOBJ..  10
    y...1081  UC..1081  -82
    y...1081  r_ekk188  -1
    y...1081  r_ekk337  -0.780487804878064
    y...1082  MinOBJ..  10
    y...1082  UC..1082  -82
    y...1082  r_ekk109  -0.020263671875
    y...1082  r_ekk119  -1
    y...1082  r_ekk166  -0.020263671875
    y...1083  MinOBJ..  7
    y...1083  UC..1083  -82
    y...1084  MinOBJ..  7
    y...1084  UC..1084  -82
    y...1085  MinOBJ..  3
    y...1085  UC..1085  -82
    y...1085  r_ekk27   -1
    y...1086  MinOBJ..  3
    y...1086  UC..1086  -82
    y...1086  r_ekk225  -0.6646484375
    y...1086  r_ekk271  -0.6322265625
    y...1086  r_ekk293  -0.518750000000001
    y...1086  r_ekk361  -1
    y...1086  r_ekk373  -1
    y...1086  r_ekk417  -1
    y...1087  MinOBJ..  7
    y...1087  UC..1087  -82
    y...1087  r_ekk102  -1
    y...1087  r_ekk174  -1
    y...1087  r_ekk207  -1
    y...1087  r_ekk298  -1
    y...1087  r_ekk394  -0.5
    y...1087  r_ekk413  -1
    y...1088  MinOBJ..  7
    y...1088  UC..1088  -82
    y...1088  r_ekk35   -1
    y...1088  r_ekk55   -1
    y...1088  r_ekk186  -1
    y...1088  r_ekk225  -0.04052734375
    y...1088  r_ekk236  -1
    y...1088  r_ekk242  -1
    y...1088  r_ekk271  -0.04052734375
    y...1088  r_ekk293  -0.518750000000001
    y...1089  MinOBJ..  10
    y...1089  UC..1089  -82
    y...1089  r_ekk142  -0.780487804878035
    y...1089  r_ekk154  -4
    y...1090  MinOBJ..  10
    y...1090  UC..1090  -82
    y...1090  r_ekk165  -0.134146341463416
    y...1090  r_ekk260  -1
    y...1090  r_ekk321  -0.04052734375
    y...1090  r_ekk433  -0.046875
    y...1091  MinOBJ..  6
    y...1091  UC..1091  -82
    y...1091  r_ekk71   -1
    y...1091  r_ekk174  -1
    y...1092  MinOBJ..  6
    y...1092  UC..1092  -82
    y...1092  r_ekk8    -1
    y...1092  r_ekk140  -1
    y...1092  r_ekk142  -0.780487804878035
    y...1092  r_ekk154  -4
    y...1092  r_ekk160  -1
    y...1092  r_ekk309  -0.625
    y...1092  r_ekk366  -0.04052734375
    y...1092  r_ekk376  -0.0390625
    y...1092  r_ekk402  -1
    y...1093  MinOBJ..  1
    y...1093  UC..1093  -82
    y...1093  r_ekk185  -1
    y...1093  r_ekk416  -1
    y...1094  MinOBJ..  1
    y...1094  UC..1094  -82
    y...1094  r_ekk172  -1
    y...1095  MinOBJ..  6
    y...1095  UC..1095  -82
    y...1095  r_ekk274  -1
    y...1095  r_ekk307  -1
    y...1095  r_ekk324  -1
    y...1096  MinOBJ..  6
    y...1096  UC..1096  -82
    y...1097  MinOBJ..  10
    y...1097  UC..1097  -82
    y...1098  MinOBJ..  10
    y...1098  UC..1098  -82
    y...1098  r_ekk100  -1
    y...1098  r_ekk173  -1
    y...1098  r_ekk268  -1
    y...1098  r_ekk296  -1
    y...1098  r_ekk319  -0.04052734375
    y...1098  r_ekk361  -1
    y...1098  r_ekk417  -1
    y...1098  r_ekk427  -1
    y...1099  MinOBJ..  7
    y...1099  UC..1099  -82
    y...1099  r_ekk38   -1
    y...1099  r_ekk90   -1
    y...1099  r_ekk211  -1
    y...1099  r_ekk339  -0.2
    y...1099  r_ekk341  -0.5
    y...1099  r_ekk351  -1
    y...1099  r_ekk372  -1
    y...1099  r_ekk410  -1.62158203125
    y...1100  MinOBJ..  7
    y...1100  UC..1100  -82
    y...1100  r_ekk274  -1
    y...1100  r_ekk284  -1
    y...1100  r_ekk295  -1
    y...1100  r_ekk307  -1
    y...1100  r_ekk315  -1
    y...1100  r_ekk324  -1
    y...1101  MinOBJ..  9
    y...1101  UC..1101  -82
    y...1102  MinOBJ..  9
    y...1102  UC..1102  -82
    y...1103  MinOBJ..  3
    y...1103  UC..1103  -82
    y...1104  MinOBJ..  3
    y...1104  UC..1104  -82
    y...1104  r_ekk338  -1
    y...1105  MinOBJ..  4
    y...1105  UC..1105  -82
    y...1105  r_ekk233  -1
    y...1105  r_ekk305  -1
    y...1105  r_ekk336  -1
    y...1105  r_ekk356  -0.0234375
    y...1105  r_ekk391  -0.75
    y...1105  r_ekk401  -1
    y...1106  MinOBJ..  4
    y...1106  UC..1106  -82
    y...1106  r_ekk40   -1
    y...1106  r_ekk340  -1
    y...1107  MinOBJ..  4
    y...1107  UC..1107  -82
    y...1107  r_ekk121  -1
    y...1107  r_ekk139  -1
    y...1107  r_ekk298  -1
    y...1108  MinOBJ..  4
    y...1108  UC..1108  -82
    y...1108  r_ekk71   -1
    y...1109  MinOBJ..  7
    y...1109  UC..1109  -82
    y...1109  r_ekk99   -1
    y...1109  r_ekk302  -0.75
    y...1109  r_ekk312  -0.04052734375
    y...1109  r_ekk329  -0.6484375
    y...1109  r_ekk380  -0.625
    y...1110  MinOBJ..  7
    y...1110  UC..1110  -82
    y...1110  r_ekk5    -1
    y...1110  r_ekk63   -1
    y...1111  MinOBJ..  3
    y...1111  UC..1111  -82
    y...1111  r_ekk123  -1
    y...1112  MinOBJ..  3
    y...1112  UC..1112  -82
    y...1112  r_ekk211  -1
    y...1112  r_ekk339  -0.1
    y...1112  r_ekk347  -0.0234375
    y...1112  r_ekk351  -1
    y...1112  r_ekk372  -1
    y...1112  r_ekk410  -0.810791015625
    y...1112  r_ekk423  -1
    y...1112  r_ekk430  -1
    y...1113  MinOBJ..  7
    y...1113  UC..1113  -82
    y...1113  r_ekk37   -1
    y...1113  r_ekk96   -1
    y...1113  r_ekk131  -1
    y...1113  r_ekk153  -1
    y...1113  r_ekk191  -1
    y...1113  r_ekk197  -0.0123456790123457
    y...1114  MinOBJ..  7
    y...1114  UC..1114  -82
    y...1115  MinOBJ..  4
    y...1115  UC..1115  -82
    y...1115  r_ekk323  -1
    y...1115  r_ekk346  -1
    y...1115  r_ekk355  -1
    y...1115  r_ekk368  -1
    y...1116  MinOBJ..  4
    y...1116  UC..1116  -82
    y...1116  r_ekk269  -1
    y...1116  r_ekk286  -1
    y...1117  MinOBJ..  6
    y...1117  UC..1117  -82
    y...1117  r_ekk167  -1
    y...1117  r_ekk199  -0.073321288768443
    y...1117  r_ekk305  -1
    y...1117  r_ekk391  -0.75
    y...1117  r_ekk407  -0.75
    y...1117  r_ekk415  -1
    y...1118  MinOBJ..  6
    y...1118  UC..1118  -82
    y...1118  r_ekk337  -0.780487804878064
    y...1119  MinOBJ..  10
    y...1119  UC..1119  -82
    y...1120  MinOBJ..  10
    y...1120  UC..1120  -82
    y...1121  MinOBJ..  1
    y...1121  UC..1121  -82
    y...1122  MinOBJ..  1
    y...1122  UC..1122  -82
    y...1122  r_ekk98   -1
    y...1122  r_ekk110  -0.024390243902439
    y...1123  MinOBJ..  2
    y...1123  UC..1123  -82
    y...1123  r_ekk286  -1
    y...1124  MinOBJ..  2
    y...1124  UC..1124  -82
    y...1125  MinOBJ..  9
    y...1125  UC..1125  -82
    y...1125  r_ekk72   -1
    y...1125  r_ekk86   -1
    y...1125  r_ekk299  -1
    y...1125  r_ekk306  -1
    y...1125  r_ekk316  -1
    y...1125  r_ekk334  -1
    y...1125  r_ekk387  -0.020263671875
    y...1126  MinOBJ..  9
    y...1126  UC..1126  -82
    y...1126  r_ekk101  -1
    y...1126  r_ekk163  -1
    y...1126  r_ekk206  -1
    y...1126  r_ekk348  -1
    y...1126  r_ekk354  -0.015625
    y...1126  r_ekk371  -0.75
    y...1127  MinOBJ..  4
    y...1127  UC..1127  -82
    y...1128  MinOBJ..  4
    y...1128  UC..1128  -82
    y...1128  r_ekk184  -1
    y...1128  r_ekk261  -0.04052734375
    y...1128  r_ekk318  -0.6484375
    y...1128  r_ekk344  -0.6484375
    y...1128  r_ekk359  -1
    y...1128  r_ekk364  -0.04052734375
    y...1128  r_ekk365  -0.04052734375
    y...1129  MinOBJ..  7
    y...1129  UC..1129  -82
    y...1129  r_ekk95   -1
    y...1129  r_ekk115  -1
    y...1129  r_ekk163  -1
    y...1129  r_ekk187  -1
    y...1130  MinOBJ..  7
    y...1130  UC..1130  -82
    y...1131  MinOBJ..  3
    y...1131  UC..1131  -82
    y...1131  r_ekk171  -1
    y...1131  r_ekk276  -1
    y...1131  r_ekk392  -1
    y...1131  r_ekk418  -1
    y...1132  MinOBJ..  3
    y...1132  UC..1132  -82
    y...1132  r_ekk272  -1
    y...1132  r_ekk287  -1
    y...1132  r_ekk357  -0.048780487804878
    y...1133  MinOBJ..  1
    y...1133  UC..1133  -82
    y...1134  MinOBJ..  1
    y...1134  UC..1134  -82
    y...1134  r_ekk194  -1
    y...1134  r_ekk381  -1
    y...1135  MinOBJ..  10
    y...1135  UC..1135  -82
    y...1135  r_ekk44   -1
    y...1135  r_ekk64   -1
    y...1135  r_ekk88   -1
    y...1135  r_ekk128  -0.963414634146342
    y...1135  r_ekk143  -1
    y...1135  r_ekk195  -0.020263671875
    y...1135  r_ekk235  -1
    y...1135  r_ekk255  -1
    y...1135  r_ekk291  -1
    y...1135  r_ekk303  -0.04052734375
    y...1135  r_ekk310  -1
    y...1135  r_ekk319  -0.020263671875
    y...1135  r_ekk320  -0.75
    y...1135  r_ekk330  -0.03125
    y...1135  r_ekk331  -0.0346171061197917
    y...1136  MinOBJ..  10
    y...1136  UC..1136  -82
    y...1136  r_ekk68   -1
    y...1136  r_ekk106  -1
    y...1136  r_ekk164  -0.75
    y...1136  r_ekk200  -0.0234375
    y...1136  r_ekk209  -1
    y...1136  r_ekk227  -0.020263671875
    y...1136  r_ekk267  -1
    y...1136  r_ekk308  -0.75
    y...1137  MinOBJ..  3
    y...1137  UC..1137  -82
    y...1137  r_ekk151  -1
    y...1137  r_ekk204  -1
    y...1137  r_ekk213  -0.024390243902439
    y...1137  r_ekk216  -1
    y...1138  MinOBJ..  3
    y...1138  UC..1138  -82
    y...1138  r_ekk338  -1
    y...1139  MinOBJ..  7
    y...1139  UC..1139  -82
    y...1140  MinOBJ..  7
    y...1140  UC..1140  -82
    y...1141  MinOBJ..  9
    y...1141  UC..1141  -82
    y...1141  r_ekk47   -1
    y...1141  r_ekk75   -1
    y...1141  r_ekk249  -1
    y...1141  r_ekk381  -1
    y...1142  MinOBJ..  9
    y...1142  UC..1142  -82
    y...1142  r_ekk31   -1
    y...1142  r_ekk58   -1
    y...1142  r_ekk214  -0.04052734375
    y...1142  r_ekk223  -1
    y...1142  r_ekk261  -0.04052734375
    y...1142  r_ekk281  -0.75
    y...1142  r_ekk318  -0.6484375
    y...1142  r_ekk344  -0.6484375
    y...1142  r_ekk359  -1
    y...1143  MinOBJ..  6
    y...1143  UC..1143  -82
    y...1144  MinOBJ..  6
    y...1144  UC..1144  -82
    y...1145  MinOBJ..  9
    y...1145  UC..1145  -82
    y...1145  r_ekk132  -1
    y...1145  r_ekk165  -0.134146341463416
    y...1146  MinOBJ..  9
    y...1146  UC..1146  -82
    y...1147  MinOBJ..  2
    y...1147  UC..1147  -82
    y...1148  MinOBJ..  2
    y...1148  UC..1148  -82
    y...1149  MinOBJ..  6
    y...1149  UC..1149  -82
    y...1149  r_ekk142  -0.780487804878035
    y...1149  r_ekk154  -4
    y...1149  r_ekk178  -0.8206787109375
    y...1150  MinOBJ..  6
    y...1150  UC..1150  -82
    y...1150  r_ekk178  -0.020263671875
    y...1150  r_ekk183  -1
    y...1151  MinOBJ..  2
    y...1151  UC..1151  -82
    y...1151  r_ekk175  -1
    y...1151  r_ekk262  -0.020263671875
    y...1151  r_ekk298  -1
    y...1152  MinOBJ..  2
    y...1152  UC..1152  -82
    y...1152  r_ekk110  -0.0237953599048186
    y...1153  MinOBJ..  10
    y...1153  UC..1153  -82
    y...1154  MinOBJ..  10
    y...1154  UC..1154  -82
    y...1154  r_ekk74   -1
    y...1154  r_ekk339  -0.390243902439028
    y...1154  r_ekk410  -3.1640625
    y...1155  MinOBJ..  3
    y...1155  UC..1155  -82
    y...1155  r_ekk52   -1
    y...1156  MinOBJ..  3
    y...1156  UC..1156  -82
    y...1156  r_ekk172  -1
    y...1156  r_ekk222  -1
    y...1156  r_ekk363  -0.75
    y...1156  r_ekk375  -0.75
    y...1157  MinOBJ..  4
    y...1157  UC..1157  -82
    y...1157  r_ekk31   -1
    y...1157  r_ekk152  -1
    y...1157  r_ekk214  -0.04052734375
    y...1157  r_ekk249  -1
    y...1157  r_ekk261  -0.04052734375
    y...1157  r_ekk318  -0.6484375
    y...1157  r_ekk344  -0.6484375
    y...1157  r_ekk359  -1
    y...1157  r_ekk433  -0.046875
    y...1158  MinOBJ..  4
    y...1158  UC..1158  -82
    y...1158  r_ekk214  -0.6646484375
    y...1159  MinOBJ..  5
    y...1159  UC..1159  -82
    y...1159  r_ekk103  -1
    y...1159  r_ekk141  -1
    y...1159  r_ekk199  -0.0980126467931344
    y...1159  r_ekk250  -1
    y...1159  r_ekk411  -0.780487804878049
    y...1160  MinOBJ..  5
    y...1160  UC..1160  -82
    y...1160  r_ekk161  -0.780487804878049
    y...1160  r_ekk218  -1
    y...1160  r_ekk258  -1
    y...1160  r_ekk409  -1
    y...1161  MinOBJ..  7
    y...1161  UC..1161  -82
    y...1162  MinOBJ..  7
    y...1162  UC..1162  -82
    y...1162  r_ekk44   -1
    y...1162  r_ekk64   -1
    y...1162  r_ekk88   -1
    y...1162  r_ekk143  -1
    y...1162  r_ekk235  -1
    y...1162  r_ekk291  -1
    y...1162  r_ekk303  -0.04052734375
    y...1162  r_ekk310  -1
    y...1162  r_ekk319  -0.04052734375
    y...1162  r_ekk320  -0.75
    y...1162  r_ekk330  -0.03125
    y...1162  r_ekk331  -0.0346171061197917
    y...1163  MinOBJ..  10
    y...1163  UC..1163  -82
    y...1163  r_ekk9    -1
    y...1163  r_ekk66   -1
    y...1163  r_ekk173  -1
    y...1163  r_ekk220  -1
    y...1163  r_ekk290  -1
    y...1163  r_ekk296  -1
    y...1164  MinOBJ..  10
    y...1164  UC..1164  -82
    y...1165  MinOBJ..  8
    y...1165  UC..1165  -82
    y...1165  r_ekk75   -1
    y...1165  r_ekk381  -1
    y...1166  MinOBJ..  8
    y...1166  UC..1166  -82
    y...1167  MinOBJ..  7
    y...1167  UC..1167  -82
    y...1168  MinOBJ..  7
    y...1168  UC..1168  -82
    y...1168  r_ekk239  -1
    y...1168  r_ekk403  -1
    y...1169  MinOBJ..  9
    y...1169  UC..1169  -82
    y...1169  r_ekk269  -1
    y...1169  r_ekk286  -1
    y...1169  r_ekk381  -1
    y...1169  r_ekk403  -1
    y...1170  MinOBJ..  9
    y...1170  UC..1170  -82
    y...1170  r_ekk12   -1
    y...1170  r_ekk142  -0.780487804878035
    y...1170  r_ekk154  -4
    y...1170  r_ekk221  -1
    y...1171  MinOBJ..  10
    y...1171  UC..1171  -82
    y...1171  r_ekk197  -0.0975609756097569
    y...1171  r_ekk205  -1
    y...1172  MinOBJ..  10
    y...1172  UC..1172  -82
    y...1172  r_ekk37   -1
    y...1172  r_ekk56   -1
    y...1172  r_ekk96   -1
    y...1172  r_ekk153  -1
    y...1172  r_ekk191  -1
    y...1172  r_ekk197  -0.0123456790123457
    y...1172  r_ekk270  -1
    y...1173  MinOBJ..  2
    y...1173  UC..1173  -82
    y...1173  r_ekk80   -1
    y...1173  r_ekk199  -0.073321288768443
    y...1173  r_ekk241  -1
    y...1174  MinOBJ..  2
    y...1174  UC..1174  -82
    y...1174  r_ekk395  -1
    y...1174  r_ekk406  -1
    y...1175  MinOBJ..  8
    y...1175  UC..1175  -82
    y...1175  r_ekk74   -1
    y...1176  MinOBJ..  8
    y...1176  UC..1176  -82
    y...1176  r_ekk211  -1
    y...1176  r_ekk276  -1
    y...1176  r_ekk288  -1
    y...1176  r_ekk301  -1
    y...1176  r_ekk326  -1
    y...1176  r_ekk335  -1
    y...1176  r_ekk339  -0.1
    y...1176  r_ekk347  -0.0234375
    y...1176  r_ekk351  -1
    y...1176  r_ekk372  -1
    y...1176  r_ekk392  -1
    y...1176  r_ekk410  -0.810791015625
    y...1176  r_ekk418  -1
    y...1176  r_ekk423  -1
    y...1176  r_ekk429  -1
    y...1176  r_ekk430  -1
    y...1177  MinOBJ..  5
    y...1177  UC..1177  -82
    y...1177  r_ekk229  -1
    y...1177  r_ekk248  -1
    y...1177  r_ekk389  -1
    y...1177  r_ekk408  -1
    y...1178  MinOBJ..  5
    y...1178  UC..1178  -82
    y...1178  r_ekk177  -1
    y...1178  r_ekk199  -0.073321288768443
    y...1178  r_ekk241  -1
    y...1178  r_ekk257  -1
    y...1178  r_ekk311  -1
    y...1178  r_ekk317  -1
    y...1179  MinOBJ..  2
    y...1179  UC..1179  -82
    y...1180  MinOBJ..  2
    y...1180  UC..1180  -82
    y...1181  MinOBJ..  5
    y...1181  UC..1181  -82
    y...1181  r_ekk338  -1
    y...1182  MinOBJ..  5
    y...1182  UC..1182  -82
    y...1182  r_ekk118  -1
    y...1183  MinOBJ..  4
    y...1183  UC..1183  -82
    y...1183  r_ekk197  -0.0975609756097569
    y...1183  r_ekk381  -1
    y...1183  r_ekk416  -1
    y...1184  MinOBJ..  4
    y...1184  UC..1184  -82
    y...1185  MinOBJ..  7
    y...1185  UC..1185  -82
    y...1185  r_ekk106  -1
    y...1185  r_ekk164  -0.75
    y...1185  r_ekk175  -1
    y...1185  r_ekk200  -0.0234375
    y...1185  r_ekk227  -0.020263671875
    y...1185  r_ekk267  -1
    y...1185  r_ekk308  -0.75
    y...1185  r_ekk328  -1
    y...1185  r_ekk338  -1
    y...1185  r_ekk413  -1
    y...1186  MinOBJ..  7
    y...1186  UC..1186  -82
    y...1186  r_ekk381  -1
    y...1187  MinOBJ..  6
    y...1187  UC..1187  -82
    y...1188  MinOBJ..  6
    y...1188  UC..1188  -82
    y...1188  r_ekk159  -1
    y...1188  r_ekk225  -0.04052734375
    y...1188  r_ekk254  -1
    y...1188  r_ekk293  -0.518750000000001
    y...1189  MinOBJ..  3
    y...1189  UC..1189  -82
    y...1189  r_ekk219  -1
    y...1189  r_ekk248  -1
    y...1190  MinOBJ..  3
    y...1190  UC..1190  -82
    y...1191  MinOBJ..  1
    y...1191  UC..1191  -82
    y...1191  r_ekk133  -1
    y...1192  MinOBJ..  1
    y...1192  UC..1192  -82
    y...1192  r_ekk279  -1
    y...1193  MinOBJ..  4
    y...1193  UC..1193  -82
    y...1193  r_ekk220  -1
    y...1193  r_ekk290  -1
    y...1193  r_ekk331  -0.0173085530598958
    y...1194  MinOBJ..  4
    y...1194  UC..1194  -82
    y...1194  r_ekk75   -1
    y...1194  r_ekk286  -1
    y...1194  r_ekk381  -1
    y...1195  MinOBJ..  9
    y...1195  UC..1195  -82
    y...1195  r_ekk105  -1
    y...1195  r_ekk287  -1
    y...1195  r_ekk333  -1
    y...1196  MinOBJ..  9
    y...1196  UC..1196  -82
    y...1197  MinOBJ..  4
    y...1197  UC..1197  -82
    y...1198  MinOBJ..  4
    y...1198  UC..1198  -82
    y...1199  MinOBJ..  3
    y...1199  UC..1199  -82
    y...1199  r_ekk140  -1
    y...1199  r_ekk160  -1
    y...1199  r_ekk343  -1
    y...1199  r_ekk353  -1
    y...1199  r_ekk366  -0.04052734375
    y...1199  r_ekk394  -1
    y...1199  r_ekk428  -0.625
    y...1200  MinOBJ..  3
    y...1200  UC..1200  -82
    y...1200  r_ekk366  -0.830810546875
    y...1200  r_ekk376  -0.0390625
    y...1201  MinOBJ..  8
    y...1201  UC..1201  -82
    y...1201  r_ekk94   -1
    y...1201  r_ekk142  -0.780487804878035
    y...1201  r_ekk154  -4
    y...1202  MinOBJ..  8
    y...1202  UC..1202  -82
    y...1202  r_ekk338  -1
    y...1203  MinOBJ..  8
    y...1203  UC..1203  -82
    y...1203  r_ekk339  -0.390243902439028
    y...1203  r_ekk410  -3.1640625
    y...1204  MinOBJ..  8
    y...1204  UC..1204  -82
    y...1204  r_ekk95   -1
    y...1204  r_ekk115  -1
    y...1204  r_ekk163  -1
    y...1204  r_ekk187  -1
    y...1204  r_ekk313  -1
    y...1204  r_ekk323  -1
    y...1204  r_ekk346  -1
    y...1204  r_ekk355  -1
    y...1204  r_ekk368  -1
    y...1205  MinOBJ..  10
    y...1205  UC..1205  -82
    y...1205  r_ekk47   -1
    y...1205  r_ekk75   -1
    y...1205  r_ekk142  -0.780487804878035
    y...1205  r_ekk154  -4
    y...1205  r_ekk381  -1
    y...1206  MinOBJ..  10
    y...1206  UC..1206  -82
    y...1207  MinOBJ..  4
    y...1207  UC..1207  -82
    y...1207  r_ekk70   -1
    y...1207  r_ekk189  -1
    y...1207  r_ekk269  -1
    y...1207  r_ekk352  -0.75
    y...1207  r_ekk379  -0.75
    y...1207  r_ekk386  -1
    y...1208  MinOBJ..  4
    y...1208  UC..1208  -82
    y...1208  r_ekk299  -1
    y...1208  r_ekk334  -1
    y...1208  r_ekk374  -1
    y...1208  r_ekk377  -1
    y...1208  r_ekk399  -1
    y...1208  r_ekk414  -1
    y...1209  MinOBJ..  6
    y...1209  UC..1209  -82
    y...1210  MinOBJ..  6
    y...1210  UC..1210  -82
    y...1211  MinOBJ..  8
    y...1211  UC..1211  -82
    y...1211  r_ekk72   -1
    y...1211  r_ekk86   -1
    y...1211  r_ekk240  -1
    y...1211  r_ekk339  -0.0987654320987647
    y...1211  r_ekk410  -0.80078125
    y...1212  MinOBJ..  8
    y...1212  UC..1212  -82
    y...1212  r_ekk33   -1
    y...1212  r_ekk69   -1
    y...1212  r_ekk138  -1
    y...1212  r_ekk301  -1
    y...1212  r_ekk339  -0.0987654320987654
    y...1212  r_ekk410  -0.80078125
    y...1213  MinOBJ..  5
    y...1213  UC..1213  -82
    y...1214  MinOBJ..  5
    y...1214  UC..1214  -82
    y...1215  MinOBJ..  1
    y...1215  UC..1215  -82
    y...1216  MinOBJ..  1
    y...1216  UC..1216  -82
    y...1216  r_ekk239  -1
    y...1216  r_ekk403  -1
    y...1217  MinOBJ..  8
    y...1217  UC..1217  -82
    y...1218  MinOBJ..  8
    y...1218  UC..1218  -82
    y...1219  MinOBJ..  6
    y...1219  UC..1219  -82
    y...1219  r_ekk251  -0.0303955078125
    y...1220  MinOBJ..  6
    y...1220  UC..1220  -82
    y...1220  r_ekk62   -1
    y...1220  r_ekk108  -0.04052734375
    y...1220  r_ekk196  -0.04052734375
    y...1220  r_ekk199  -0.073321288768443
    y...1220  r_ekk251  -0.830810546875
    y...1220  r_ekk263  -0.04052734375
    y...1220  r_ekk356  -0.0234375
    y...1220  r_ekk391  -0.75
    y...1220  r_ekk401  -1
    y...1221  MinOBJ..  3
    y...1221  UC..1221  -82
    y...1222  MinOBJ..  3
    y...1222  UC..1222  -82
    y...1222  r_ekk286  -1
    y...1223  MinOBJ..  8
    y...1223  UC..1223  -82
    y...1223  r_ekk206  -1
    y...1224  MinOBJ..  8
    y...1224  UC..1224  -82
    y...1224  r_ekk84   -1
    y...1224  r_ekk103  -1
    y...1224  r_ekk141  -1
    y...1224  r_ekk199  -0.0246913580246914
    y...1224  r_ekk226  -0.020263671875
    y...1224  r_ekk232  -1
    y...1224  r_ekk243  -1
    y...1224  r_ekk253  -1
    y...1224  r_ekk412  -1
    y...1224  r_ekk425  -0.75
    y...1225  MinOBJ..  5
    y...1225  UC..1225  -82
    y...1225  r_ekk138  -1
    y...1226  MinOBJ..  5
    y...1226  UC..1226  -82
    y...1226  r_ekk38   -1
    y...1226  r_ekk211  -1
    y...1226  r_ekk339  -0.2
    y...1226  r_ekk341  -1
    y...1226  r_ekk347  -0.0234375
    y...1226  r_ekk351  -1
    y...1226  r_ekk362  -0.75
    y...1226  r_ekk372  -1
    y...1226  r_ekk393  -1
    y...1226  r_ekk410  -1.62158203125
    y...1226  r_ekk420  -0.75
    y...1226  r_ekk431  -0.75
    y...1227  MinOBJ..  5
    y...1227  UC..1227  -82
    y...1227  r_ekk100  -1
    y...1227  r_ekk173  -1
    y...1227  r_ekk220  -1
    y...1227  r_ekk296  -1
    y...1228  MinOBJ..  5
    y...1228  UC..1228  -82
    y...1228  r_ekk124  -1
    y...1228  r_ekk155  -0.780487804878021
    y...1228  r_ekk194  -1
    y...1228  r_ekk259  -0.780487804878021
    y...1228  r_ekk277  -1
    y...1228  r_ekk373  -1
    y...1229  MinOBJ..  10
    y...1229  UC..1229  -82
    y...1229  r_ekk65   -1
    y...1229  r_ekk177  -1
    y...1229  r_ekk192  -1
    y...1229  r_ekk217  -1
    y...1229  r_ekk248  -1
    y...1230  MinOBJ..  10
    y...1230  UC..1230  -82
    y...1230  r_ekk27   -1
    y...1230  r_ekk54   -0.780487804878049
    y...1230  r_ekk124  -1
    y...1230  r_ekk155  -0.780487804878021
    y...1230  r_ekk194  -1
    y...1230  r_ekk259  -0.780487804878021
    y...1230  r_ekk277  -1
    y...1230  r_ekk373  -1
    y...1231  MinOBJ..  9
    y...1231  UC..1231  -82
    y...1231  r_ekk124  -1
    y...1231  r_ekk361  -1
    y...1231  r_ekk427  -1
    y...1232  MinOBJ..  9
    y...1232  UC..1232  -82
    y...1232  r_ekk413  -1
    y...1233  MinOBJ..  4
    y...1233  UC..1233  -82
    y...1233  r_ekk190  -1
    y...1233  r_ekk237  -1
    y...1233  r_ekk246  -1
    y...1234  MinOBJ..  4
    y...1234  UC..1234  -82
    y...1234  r_ekk142  -0.780487804878035
    y...1234  r_ekk154  -4
    y...1234  r_ekk160  -1
    y...1234  r_ekk327  -1
    y...1235  MinOBJ..  10
    y...1235  UC..1235  -82
    y...1235  r_ekk94   -1
    y...1235  r_ekk142  -0.780487804878035
    y...1235  r_ekk154  -4
    y...1235  r_ekk353  -1
    y...1235  r_ekk402  -1
    y...1235  r_ekk413  -1
    y...1236  MinOBJ..  10
    y...1236  UC..1236  -82
    y...1236  r_ekk286  -1
    y...1236  r_ekk381  -1
    y...1237  MinOBJ..  1
    y...1237  UC..1237  -82
    y...1237  r_ekk135  -1
    y...1238  MinOBJ..  1
    y...1238  UC..1238  -82
    y...1238  r_ekk223  -1
    y...1239  MinOBJ..  5
    y...1239  UC..1239  -82
    y...1239  r_ekk72   -1
    y...1239  r_ekk86   -1
    y...1239  r_ekk265  -1
    y...1239  r_ekk285  -1
    y...1240  MinOBJ..  5
    y...1240  UC..1240  -82
    y...1240  r_ekk126  -1
    y...1240  r_ekk278  -1
    y...1240  r_ekk286  -1
    y...1240  r_ekk374  -1
    y...1241  MinOBJ..  6
    y...1241  UC..1241  -82
    y...1241  r_ekk413  -1
    y...1242  MinOBJ..  6
    y...1242  UC..1242  -82
    y...1242  r_ekk97   -1
    y...1242  r_ekk122  -1
    y...1242  r_ekk409  -1
    y...1243  MinOBJ..  9
    y...1243  UC..1243  -82
    y...1243  r_ekk25   -1
    y...1243  r_ekk67   -1
    y...1243  r_ekk433  -0.046875
    y...1244  MinOBJ..  9
    y...1244  UC..1244  -82
    y...1244  r_ekk76   -0.6171875
    y...1244  r_ekk224  -0.780487804878046
    y...1244  r_ekk328  -1
    y...1244  r_ekk338  -1
    y...1245  MinOBJ..  1
    y...1245  UC..1245  -82
    y...1245  r_ekk417  -1
    y...1246  MinOBJ..  1
    y...1246  UC..1246  -82
    y...1246  r_ekk268  -1
    y...1246  r_ekk319  -0.04052734375
    y...1246  r_ekk361  -1
    y...1246  r_ekk373  -1
    y...1247  MinOBJ..  9
    y...1247  UC..1247  -82
    y...1247  r_ekk4    -1
    y...1247  r_ekk162  -1
    y...1247  r_ekk214  -0.04052734375
    y...1248  MinOBJ..  9
    y...1248  UC..1248  -82
    y...1249  MinOBJ..  1
    y...1249  UC..1249  -82
    y...1249  r_ekk408  -1
    y...1250  MinOBJ..  1
    y...1250  UC..1250  -82
    MARK0001  'MARKER'                 'INTEND'
RHS
    RHS_V     CNS..003  1
    RHS_V     CNS..009  1
    RHS_V     CNS..012  1
    RHS_V     CNS..015  1
    RHS_V     CNS..016  1
    RHS_V     CNS..031  1
    RHS_V     CNS..038  1
    RHS_V     CNS..043  1
    RHS_V     CNS..073  1
    RHS_V     CNS..077  1
    RHS_V     CNS..083  1
    RHS_V     CNS..084  1
    RHS_V     CNS..091  1
    RHS_V     CNS..098  1
    RHS_V     CNS..103  1
    RHS_V     CNS..118  1
    RHS_V     CNS..123  1
    RHS_V     CNS..129  1
    RHS_V     CNS..130  1
    RHS_V     CNS..132  2
    RHS_V     CNS..133  2
    RHS_V     CNS..138  1
    RHS_V     CNS..146  1
    RHS_V     CNS..154  1
    RHS_V     CNS..156  1
    RHS_V     CNS..174  1
    RHS_V     CNS..184  1
    RHS_V     CNS..188  1
    RHS_V     CNS..190  1
    RHS_V     CNS..201  1
    RHS_V     CNS..203  1
    RHS_V     CNS..204  1
    RHS_V     CNS..215  1
    RHS_V     CNS..216  1
    RHS_V     CNS..217  1
    RHS_V     CNS..224  1
    RHS_V     CNS..232  2
    RHS_V     CNS..238  1
    RHS_V     CNS..240  1
    RHS_V     CNS..241  1
    RHS_V     CNS..246  1
    RHS_V     CNS..249  1
    RHS_V     CNS..254  1
    RHS_V     CNS..264  2
    RHS_V     CNS..265  1
    RHS_V     CNS..271  2
    RHS_V     CNS..272  1
    RHS_V     CNS..277  1
    RHS_V     CNS..281  1
    RHS_V     CNS..284  1
    RHS_V     CNS..298  1
    RHS_V     CNS..309  1
    RHS_V     CNS..311  1
    RHS_V     CNS..320  -82
    RHS_V     CNS..335  1
    RHS_V     CNS..340  1
    RHS_V     CNS..342  1
    RHS_V     CNS..357  1
    RHS_V     CNS..360  1
    RHS_V     CNS..363  1
    RHS_V     CNS..367  1
    RHS_V     CNS..387  1
    RHS_V     CNS..400  1
    RHS_V     CNS..409  1
    RHS_V     CNS..414  1
    RHS_V     CNS..425  2
    RHS_V     CNS..437  1
    RHS_V     CNS..439  1
    RHS_V     CNS..448  1
    RHS_V     CNS..479  1
    RHS_V     CNS..482  1
    RHS_V     CNS..489  2
    RHS_V     CNS..494  1
    RHS_V     CNS..496  1
    RHS_V     CNS..498  2
    RHS_V     r_ekk0    -1
    RHS_V     r_ekk1    -1
    RHS_V     r_ekk2    -1
    RHS_V     r_ekk3    -1
    RHS_V     r_ekk4    -1
    RHS_V     r_ekk5    -1
    RHS_V     r_ekk6    -1
    RHS_V     r_ekk7    -1
    RHS_V     r_ekk8    -1
    RHS_V     r_ekk9    -1
    RHS_V     r_ekk10   -1
    RHS_V     r_ekk11   -1
    RHS_V     r_ekk12   -1
    RHS_V     r_ekk13   -1
    RHS_V     r_ekk14   -1
    RHS_V     r_ekk15   -1
    RHS_V     r_ekk16   -1
    RHS_V     r_ekk17   -1
    RHS_V     r_ekk18   -1
    RHS_V     r_ekk19   -1
    RHS_V     r_ekk20   -1
    RHS_V     r_ekk21   -1
    RHS_V     r_ekk22   -1
    RHS_V     r_ekk23   -1
    RHS_V     r_ekk24   -1
    RHS_V     r_ekk25   -1
    RHS_V     r_ekk26   -1
    RHS_V     r_ekk27   -1
    RHS_V     r_ekk28   -1
    RHS_V     r_ekk29   -1
    RHS_V     r_ekk30   -1
    RHS_V     r_ekk31   -1
    RHS_V     r_ekk32   -1
    RHS_V     r_ekk33   -1
    RHS_V     r_ekk34   -1
    RHS_V     r_ekk35   -1
    RHS_V     r_ekk36   -1
    RHS_V     r_ekk37   -1
    RHS_V     r_ekk38   -1
    RHS_V     r_ekk39   -1
    RHS_V     r_ekk40   -1
    RHS_V     r_ekk41   -1
    RHS_V     r_ekk42   -1
    RHS_V     r_ekk43   -1
    RHS_V     r_ekk44   -1
    RHS_V     r_ekk45   -1
    RHS_V     r_ekk46   -1
    RHS_V     r_ekk47   -1
    RHS_V     r_ekk48   -0.0078125
    RHS_V     r_ekk49   -0.0078125
    RHS_V     r_ekk50   -0.0078125
    RHS_V     r_ekk51   -1
    RHS_V     r_ekk52   -1
    RHS_V     r_ekk53   -1
    RHS_V     r_ekk54   -0.780487804878049
    RHS_V     r_ekk55   -1
    RHS_V     r_ekk56   -1
    RHS_V     r_ekk57   -1
    RHS_V     r_ekk58   -1
    RHS_V     r_ekk59   -1
    RHS_V     r_ekk60   -1
    RHS_V     r_ekk61   -1
    RHS_V     r_ekk62   -1
    RHS_V     r_ekk63   -1
    RHS_V     r_ekk64   -1
    RHS_V     r_ekk65   -1
    RHS_V     r_ekk66   -1
    RHS_V     r_ekk67   -1
    RHS_V     r_ekk68   -1
    RHS_V     r_ekk69   -1
    RHS_V     r_ekk70   -1
    RHS_V     r_ekk71   -1
    RHS_V     r_ekk72   -1
    RHS_V     r_ekk73   -1
    RHS_V     r_ekk74   -1
    RHS_V     r_ekk75   -1
    RHS_V     r_ekk78   -0.780487804878049
    RHS_V     r_ekk79   -1
    RHS_V     r_ekk80   -1
    RHS_V     r_ekk81   -1
    RHS_V     r_ekk82   -1
    RHS_V     r_ekk83   -1
    RHS_V     r_ekk84   -1
    RHS_V     r_ekk85   -1
    RHS_V     r_ekk86   -1
    RHS_V     r_ekk87   -1
    RHS_V     r_ekk88   -1
    RHS_V     r_ekk89   -1
    RHS_V     r_ekk90   -1
    RHS_V     r_ekk91   -1
    RHS_V     r_ekk92   -1
    RHS_V     r_ekk93   -1
    RHS_V     r_ekk94   -1
    RHS_V     r_ekk95   -1
    RHS_V     r_ekk96   -1
    RHS_V     r_ekk97   -1
    RHS_V     r_ekk98   -1
    RHS_V     r_ekk99   -1
    RHS_V     r_ekk100  -1
    RHS_V     r_ekk101  -1
    RHS_V     r_ekk102  -1
    RHS_V     r_ekk103  -1
    RHS_V     r_ekk104  -1
    RHS_V     r_ekk105  -1
    RHS_V     r_ekk106  -1
    RHS_V     r_ekk107  -1
    RHS_V     r_ekk108  -0.04052734375
    RHS_V     r_ekk109  -0.020263671875
    RHS_V     r_ekk110  -0.024390243902439
    RHS_V     r_ekk111  -1
    RHS_V     r_ekk112  -1
    RHS_V     r_ekk113  -1
    RHS_V     r_ekk114  -1
    RHS_V     r_ekk115  -1
    RHS_V     r_ekk116  -1
    RHS_V     r_ekk117  -1
    RHS_V     r_ekk118  -1
    RHS_V     r_ekk119  -1
    RHS_V     r_ekk120  -1
    RHS_V     r_ekk121  -1
    RHS_V     r_ekk122  -1
    RHS_V     r_ekk123  -1
    RHS_V     r_ekk124  -1
    RHS_V     r_ekk125  -1
    RHS_V     r_ekk126  -1
    RHS_V     r_ekk127  -1
    RHS_V     r_ekk129  -1
    RHS_V     r_ekk130  -1
    RHS_V     r_ekk131  -1
    RHS_V     r_ekk132  -1
    RHS_V     r_ekk133  -1
    RHS_V     r_ekk134  -1
    RHS_V     r_ekk135  -1
    RHS_V     r_ekk136  -1
    RHS_V     r_ekk137  -1
    RHS_V     r_ekk138  -1
    RHS_V     r_ekk139  -1
    RHS_V     r_ekk140  -1
    RHS_V     r_ekk141  -1
    RHS_V     r_ekk142  -0.879253236976801
    RHS_V     r_ekk143  -1
    RHS_V     r_ekk145  -0.020263671875
    RHS_V     r_ekk146  -1
    RHS_V     r_ekk147  -1
    RHS_V     r_ekk148  -1
    RHS_V     r_ekk149  -1
    RHS_V     r_ekk150  -1
    RHS_V     r_ekk151  -1
    RHS_V     r_ekk152  -1
    RHS_V     r_ekk153  -1
    RHS_V     r_ekk154  -4.00000000000001
    RHS_V     r_ekk155  -0.780487804878021
    RHS_V     r_ekk157  -1
    RHS_V     r_ekk158  -1
    RHS_V     r_ekk159  -1
    RHS_V     r_ekk160  -1
    RHS_V     r_ekk161  -1.57061126166817
    RHS_V     r_ekk162  -1
    RHS_V     r_ekk163  -1
    RHS_V     r_ekk164  -0.75
    RHS_V     r_ekk165  -0.134146341463416
    RHS_V     r_ekk166  -0.020263671875
    RHS_V     r_ekk167  -1
    RHS_V     r_ekk168  -1
    RHS_V     r_ekk169  -1
    RHS_V     r_ekk170  -1
    RHS_V     r_ekk171  -1
    RHS_V     r_ekk172  -1
    RHS_V     r_ekk173  -1
    RHS_V     r_ekk174  -1
    RHS_V     r_ekk175  -1
    RHS_V     r_ekk176  -1
    RHS_V     r_ekk177  -2
    RHS_V     r_ekk178  -0.020263671875
    RHS_V     r_ekk179  -0.780487804878049
    RHS_V     r_ekk180  -1
    RHS_V     r_ekk181  -1
    RHS_V     r_ekk182  -1
    RHS_V     r_ekk183  -1
    RHS_V     r_ekk184  -1
    RHS_V     r_ekk185  -1
    RHS_V     r_ekk186  -1
    RHS_V     r_ekk187  -1
    RHS_V     r_ekk188  -1
    RHS_V     r_ekk189  -1
    RHS_V     r_ekk190  -1
    RHS_V     r_ekk191  -1
    RHS_V     r_ekk192  -1
    RHS_V     r_ekk193  -1
    RHS_V     r_ekk194  -1
    RHS_V     r_ekk195  -0.020263671875
    RHS_V     r_ekk196  -0.04052734375
    RHS_V     r_ekk197  -0.122252333634448
    RHS_V     r_ekk199  -0.11035832580548
    RHS_V     r_ekk200  -0.0234375
    RHS_V     r_ekk201  -1
    RHS_V     r_ekk202  -1
    RHS_V     r_ekk203  -1
    RHS_V     r_ekk204  -1
    RHS_V     r_ekk205  -1
    RHS_V     r_ekk206  -1
    RHS_V     r_ekk207  -1
    RHS_V     r_ekk208  -1
    RHS_V     r_ekk209  -1
    RHS_V     r_ekk210  -1
    RHS_V     r_ekk211  -1
    RHS_V     r_ekk212  -1
    RHS_V     r_ekk213  -0.024390243902439
    RHS_V     r_ekk214  -0.04052734375
    RHS_V     r_ekk215  -1
    RHS_V     r_ekk216  -1
    RHS_V     r_ekk217  -1
    RHS_V     r_ekk218  -1
    RHS_V     r_ekk219  -1
    RHS_V     r_ekk220  -1
    RHS_V     r_ekk221  -1
    RHS_V     r_ekk222  -1
    RHS_V     r_ekk223  -1
    RHS_V     r_ekk224  -1.56097560975609
    RHS_V     r_ekk225  -0.04052734375
    RHS_V     r_ekk226  -0.020263671875
    RHS_V     r_ekk227  -0.020263671875
    RHS_V     r_ekk228  -1
    RHS_V     r_ekk229  -1
    RHS_V     r_ekk230  -1
    RHS_V     r_ekk231  -1
    RHS_V     r_ekk232  -1
    RHS_V     r_ekk233  -1
    RHS_V     r_ekk234  -0.5
    RHS_V     r_ekk235  -1
    RHS_V     r_ekk236  -1
    RHS_V     r_ekk237  -1
    RHS_V     r_ekk238  -1
    RHS_V     r_ekk239  -1
    RHS_V     r_ekk240  -1
    RHS_V     r_ekk241  -1
    RHS_V     r_ekk242  -1
    RHS_V     r_ekk243  -1
    RHS_V     r_ekk244  -1
    RHS_V     r_ekk245  -1
    RHS_V     r_ekk246  -1
    RHS_V     r_ekk247  -1
    RHS_V     r_ekk248  -1
    RHS_V     r_ekk249  -1
    RHS_V     r_ekk250  -1
    RHS_V     r_ekk251  -0.0303955078125
    RHS_V     r_ekk252  -1
    RHS_V     r_ekk253  -1
    RHS_V     r_ekk254  -1
    RHS_V     r_ekk255  -1
    RHS_V     r_ekk256  -1
    RHS_V     r_ekk257  -1
    RHS_V     r_ekk258  -1
    RHS_V     r_ekk259  -0.780487804878021
    RHS_V     r_ekk260  -1
    RHS_V     r_ekk261  -0.04052734375
    RHS_V     r_ekk262  -0.020263671875
    RHS_V     r_ekk263  -0.04052734375
    RHS_V     r_ekk264  -1
    RHS_V     r_ekk265  -1
    RHS_V     r_ekk266  -1
    RHS_V     r_ekk267  -1
    RHS_V     r_ekk268  -1
    RHS_V     r_ekk269  -1
    RHS_V     r_ekk270  -1
    RHS_V     r_ekk271  -0.04052734375
    RHS_V     r_ekk272  -1
    RHS_V     r_ekk273  -1
    RHS_V     r_ekk274  -1
    RHS_V     r_ekk275  -1
    RHS_V     r_ekk276  -1
    RHS_V     r_ekk277  -1
    RHS_V     r_ekk278  -1
    RHS_V     r_ekk279  -1
    RHS_V     r_ekk280  -1
    RHS_V     r_ekk281  -0.75
    RHS_V     r_ekk282  -1
    RHS_V     r_ekk283  -1
    RHS_V     r_ekk284  -1
    RHS_V     r_ekk285  -1
    RHS_V     r_ekk286  -1
    RHS_V     r_ekk287  -1
    RHS_V     r_ekk288  -1
    RHS_V     r_ekk289  -1
    RHS_V     r_ekk290  -1
    RHS_V     r_ekk291  -1
    RHS_V     r_ekk292  -0.020263671875
    RHS_V     r_ekk293  -0.518750000000001
    RHS_V     r_ekk294  -1
    RHS_V     r_ekk295  -1
    RHS_V     r_ekk296  -1
    RHS_V     r_ekk297  -1
    RHS_V     r_ekk298  -1
    RHS_V     r_ekk299  -1
    RHS_V     r_ekk300  -1
    RHS_V     r_ekk301  -1
    RHS_V     r_ekk302  -0.75
    RHS_V     r_ekk303  -0.04052734375
    RHS_V     r_ekk304  -0.015625
    RHS_V     r_ekk305  -1
    RHS_V     r_ekk306  -1
    RHS_V     r_ekk307  -1
    RHS_V     r_ekk308  -0.75
    RHS_V     r_ekk309  -0.625
    RHS_V     r_ekk310  -1
    RHS_V     r_ekk311  -1
    RHS_V     r_ekk312  -0.04052734375
    RHS_V     r_ekk313  -1
    RHS_V     r_ekk314  -1
    RHS_V     r_ekk315  -1
    RHS_V     r_ekk316  -1
    RHS_V     r_ekk317  -1
    RHS_V     r_ekk318  -0.6484375
    RHS_V     r_ekk319  -0.04052734375
    RHS_V     r_ekk320  -0.75
    RHS_V     r_ekk321  -0.04052734375
    RHS_V     r_ekk322  -1
    RHS_V     r_ekk323  -1
    RHS_V     r_ekk324  -1
    RHS_V     r_ekk325  -1
    RHS_V     r_ekk326  -1
    RHS_V     r_ekk327  -1
    RHS_V     r_ekk328  -1
    RHS_V     r_ekk329  -0.6484375
    RHS_V     r_ekk330  -0.03125
    RHS_V     r_ekk331  -0.0346171061197917
    RHS_V     r_ekk332  -1
    RHS_V     r_ekk333  -1
    RHS_V     r_ekk334  -1
    RHS_V     r_ekk335  -1
    RHS_V     r_ekk336  -1
    RHS_V     r_ekk337  -0.780487804878064
    RHS_V     r_ekk338  -1
    RHS_V     r_ekk339  -0.787804878048784
    RHS_V     r_ekk340  -1
    RHS_V     r_ekk341  -1
    RHS_V     r_ekk342  -1
    RHS_V     r_ekk343  -1
    RHS_V     r_ekk344  -0.6484375
    RHS_V     r_ekk345  -1
    RHS_V     r_ekk346  -1
    RHS_V     r_ekk347  -0.0234375
    RHS_V     r_ekk348  -1
    RHS_V     r_ekk349  -1
    RHS_V     r_ekk350  -1
    RHS_V     r_ekk351  -1
    RHS_V     r_ekk352  -0.75
    RHS_V     r_ekk353  -1
    RHS_V     r_ekk354  -0.015625
    RHS_V     r_ekk355  -1
    RHS_V     r_ekk356  -0.0234375
    RHS_V     r_ekk357  -0.0243902439024389
    RHS_V     r_ekk358  -1
    RHS_V     r_ekk359  -1
    RHS_V     r_ekk360  -1
    RHS_V     r_ekk361  -1
    RHS_V     r_ekk362  -0.75
    RHS_V     r_ekk363  -0.75
    RHS_V     r_ekk364  -0.04052734375
    RHS_V     r_ekk365  -0.04052734375
    RHS_V     r_ekk366  -0.04052734375
    RHS_V     r_ekk367  -1
    RHS_V     r_ekk368  -1
    RHS_V     r_ekk369  -1
    RHS_V     r_ekk370  -1
    RHS_V     r_ekk371  -0.75
    RHS_V     r_ekk372  -1
    RHS_V     r_ekk373  -1
    RHS_V     r_ekk374  -1
    RHS_V     r_ekk375  -0.75
    RHS_V     r_ekk376  -0.0390625
    RHS_V     r_ekk377  -1
    RHS_V     r_ekk378  -0.75
    RHS_V     r_ekk379  -0.75
    RHS_V     r_ekk380  -0.625
    RHS_V     r_ekk381  -1
    RHS_V     r_ekk382  -1
    RHS_V     r_ekk383  -1
    RHS_V     r_ekk384  -1
    RHS_V     r_ekk385  -0.75
    RHS_V     r_ekk386  -1
    RHS_V     r_ekk387  -0.020263671875
    RHS_V     r_ekk388  -1
    RHS_V     r_ekk389  -1
    RHS_V     r_ekk390  -1
    RHS_V     r_ekk391  -0.75
    RHS_V     r_ekk392  -1
    RHS_V     r_ekk393  -1
    RHS_V     r_ekk394  -1
    RHS_V     r_ekk395  -1
    RHS_V     r_ekk396  -1
    RHS_V     r_ekk397  -1
    RHS_V     r_ekk398  -1
    RHS_V     r_ekk399  -1
    RHS_V     r_ekk400  -1
    RHS_V     r_ekk401  -1
    RHS_V     r_ekk402  -1
    RHS_V     r_ekk403  -1
    RHS_V     r_ekk404  -1
    RHS_V     r_ekk405  -0.75
    RHS_V     r_ekk406  -1
    RHS_V     r_ekk407  -0.75
    RHS_V     r_ekk408  -1
    RHS_V     r_ekk409  -1
    RHS_V     r_ekk410  -3.1640625
    RHS_V     r_ekk411  -0.780487804878049
    RHS_V     r_ekk412  -1
    RHS_V     r_ekk413  -1
    RHS_V     r_ekk414  -1
    RHS_V     r_ekk415  -1
    RHS_V     r_ekk416  -1
    RHS_V     r_ekk417  -1
    RHS_V     r_ekk418  -1
    RHS_V     r_ekk419  -0.75
    RHS_V     r_ekk420  -0.75
    RHS_V     r_ekk421  -1
    RHS_V     r_ekk422  -0.75
    RHS_V     r_ekk423  -1
    RHS_V     r_ekk424  -1
    RHS_V     r_ekk425  -0.75
    RHS_V     r_ekk426  -1
    RHS_V     r_ekk427  -1
    RHS_V     r_ekk428  -0.625
    RHS_V     r_ekk429  -1
    RHS_V     r_ekk430  -1
    RHS_V     r_ekk431  -0.75
    RHS_V     r_ekk432  -1
    RHS_V     r_ekk433  -0.046875
BOUNDS
 UP BOUND     x...0001  82
 UP BOUND     x...0002  82
 UP BOUND     x...0003  82
 UP BOUND     x...0004  82
 UP BOUND     x...0005  82
 UP BOUND     x...0006  82
 FX BOUND     x...0007  0
 FX BOUND     x...0008  0
 UP BOUND     x...0009  82
 UP BOUND     x...0010  82
 UP BOUND     x...0011  82
 UP BOUND     x...0012  82
 UP BOUND     x...0013  82
 UP BOUND     x...0014  82
 UP BOUND     x...0015  82
 FX BOUND     x...0016  0
 FX BOUND     x...0017  0
 FX BOUND     x...0018  0
 FX BOUND     x...0019  0
 FX BOUND     x...0020  0
 FX BOUND     x...0021  0
 UP BOUND     x...0022  82
 FX BOUND     x...0025  0
 UP BOUND     x...0026  82
 UP BOUND     x...0027  82
 UP BOUND     x...0028  82
 FX BOUND     x...0029  0
 UP BOUND     x...0030  82
 FX BOUND     x...0031  0
 UP BOUND     x...0032  82
 FX BOUND     x...0035  0
 FX BOUND     x...0036  0
 UP BOUND     x...0037  82
 FX BOUND     x...0038  0
 UP BOUND     x...0039  82
 FX BOUND     x...0040  0
 UP BOUND     x...0041  82
 UP BOUND     x...0042  82
 UP BOUND     x...0045  82
 UP BOUND     x...0046  82
 UP BOUND     x...0047  82
 UP BOUND     x...0048  82
 UP BOUND     x...0049  82
 FX BOUND     x...0050  0
 FX BOUND     x...0051  0
 FX BOUND     x...0052  0
 UP BOUND     x...0053  82
 UP BOUND     x...0054  82
 UP BOUND     x...0055  82
 UP BOUND     x...0056  82
 FX BOUND     x...0057  0
 FX BOUND     x...0058  0
 FX BOUND     x...0059  0
 UP BOUND     x...0060  82
 FX BOUND     x...0061  0
 FX BOUND     x...0062  0
 UP BOUND     x...0063  82
 UP BOUND     x...0064  82
 FX BOUND     x...0065  0
 UP BOUND     x...0066  82
 UP BOUND     x...0067  82
 UP BOUND     x...0068  82
 UP BOUND     x...0069  82
 UP BOUND     x...0070  82
 UP BOUND     x...0071  82
 UP BOUND     x...0072  82
 UP BOUND     x...0073  82
 FX BOUND     x...0074  0
 FX BOUND     x...0075  0
 FX BOUND     x...0076  0
 FX BOUND     x...0077  0
 UP BOUND     x...0078  82
 FX BOUND     x...0079  0
 UP BOUND     x...0080  82
 FX BOUND     x...0081  0
 FX BOUND     x...0082  0
 UP BOUND     x...0083  82
 UP BOUND     x...0084  82
 FX BOUND     x...0085  0
 FX BOUND     x...0086  0
 FX BOUND     x...0087  0
 UP BOUND     x...0088  82
 FX BOUND     x...0089  0
 FX BOUND     x...0090  0
 UP BOUND     x...0091  82
 UP BOUND     x...0092  82
 UP BOUND     x...0093  82
 UP BOUND     x...0094  82
 FX BOUND     x...0095  0
 FX BOUND     x...0096  0
 UP BOUND     x...0097  82
 FX BOUND     x...0098  0
 FX BOUND     x...0099  0
 FX BOUND     x...0100  0
 UP BOUND     x...0103  82
 FX BOUND     x...0104  0
 FX BOUND     x...0105  0
 UP BOUND     x...0106  82
 FX BOUND     x...0109  0
 UP BOUND     x...0110  82
 FX BOUND     x...0111  0
 UP BOUND     x...0112  82
 FX BOUND     x...0113  0
 FX BOUND     x...0114  0
 UP BOUND     x...0115  82
 FX BOUND     x...0116  0
 FX BOUND     x...0117  0
 UP BOUND     x...0118  82
 UP BOUND     x...0119  82
 FX BOUND     x...0120  0
 UP BOUND     x...0121  82
 UP BOUND     x...0122  82
 UP BOUND     x...0123  82
 UP BOUND     x...0124  82
 UP BOUND     x...0125  82
 FX BOUND     x...0126  0
 UP BOUND     x...0127  82
 FX BOUND     x...0128  0
 UP BOUND     x...0129  82
 FX BOUND     x...0130  0
 LO BOUND     x...0131  1
 UP BOUND     x...0131  2
 FX BOUND     x...0132  0
 FX BOUND     x...0133  0
 FX BOUND     x...0134  0
 FX BOUND     x...0135  0
 FX BOUND     x...0136  0
 UP BOUND     x...0137  82
 UP BOUND     x...0138  82
 FX BOUND     x...0139  0
 FX BOUND     x...0140  0
 UP BOUND     x...0143  82
 FX BOUND     x...0144  0
 UP BOUND     x...0145  82
 UP BOUND     x...0146  82
 UP BOUND     x...0147  82
 UP BOUND     x...0148  82
 UP BOUND     x...0149  82
 FX BOUND     x...0150  0
 UP BOUND     x...0151  82
 FX BOUND     x...0152  0
 UP BOUND     x...0155  82
 FX BOUND     x...0156  0
 FX BOUND     x...0163  0
 FX BOUND     x...0164  0
 FX BOUND     x...0169  0
 FX BOUND     x...0170  0
 UP BOUND     x...0171  82
 UP BOUND     x...0172  82
 FX BOUND     x...0173  0
 FX BOUND     x...0174  0
 UP BOUND     x...0175  82
 UP BOUND     x...0176  82
 UP BOUND     x...0179  82
 UP BOUND     x...0180  82
 UP BOUND     x...0181  82
 UP BOUND     x...0182  82
 UP BOUND     x...0185  82
 UP BOUND     x...0186  82
 FX BOUND     x...0187  0
 FX BOUND     x...0188  0
 UP BOUND     x...0191  82
 FX BOUND     x...0192  0
 FX BOUND     x...0193  0
 FX BOUND     x...0194  0
 UP BOUND     x...0195  82
 FX BOUND     x...0196  0
 FX BOUND     x...0197  0
 FX BOUND     x...0198  0
 UP BOUND     x...0199  82
 UP BOUND     x...0200  82
 UP BOUND     x...0201  82
 UP BOUND     x...0202  82
 FX BOUND     x...0203  0
 FX BOUND     x...0204  0
 UP BOUND     x...0205  82
 UP BOUND     x...0206  82
 UP BOUND     x...0207  82
 UP BOUND     x...0208  82
 FX BOUND     x...0211  0
 FX BOUND     x...0212  0
 FX BOUND     x...0215  0
 FX BOUND     x...0216  0
 FX BOUND     x...0217  0
 FX BOUND     x...0218  0
 FX BOUND     x...0221  0
 FX BOUND     x...0222  0
 UP BOUND     x...0223  82
 UP BOUND     x...0224  82
 UP BOUND     x...0225  82
 UP BOUND     x...0226  82
 FX BOUND     x...0227  0
 FX BOUND     x...0228  0
 UP BOUND     x...0231  82
 FX BOUND     x...0232  0
 FX BOUND     x...0233  0
 UP BOUND     x...0234  82
 FX BOUND     x...0237  0
 FX BOUND     x...0238  0
 FX BOUND     x...0243  0
 FX BOUND     x...0244  0
 FX BOUND     x...0245  0
 UP BOUND     x...0246  82
 FX BOUND     x...0247  0
 FX BOUND     x...0248  0
 FX BOUND     x...0249  0
 FX BOUND     x...0250  0
 FX BOUND     x...0251  0
 FX BOUND     x...0252  0
 FX BOUND     x...0253  0
 FX BOUND     x...0254  0
 FX BOUND     x...0255  0
 FX BOUND     x...0256  0
 UP BOUND     x...0257  82
 UP BOUND     x...0258  82
 FX BOUND     x...0259  0
 FX BOUND     x...0260  0
 UP BOUND     x...0261  82
 FX BOUND     x...0262  0
 FX BOUND     x...0263  0
 FX BOUND     x...0264  0
 FX BOUND     x...0267  0
 FX BOUND     x...0268  0
 UP BOUND     x...0269  82
 UP BOUND     x...0270  82
 FX BOUND     x...0271  0
 FX BOUND     x...0272  0
 FX BOUND     x...0273  0
 FX BOUND     x...0274  0
 FX BOUND     x...0275  0
 FX BOUND     x...0276  0
 FX BOUND     x...0277  0
 UP BOUND     x...0278  82
 FX BOUND     x...0281  0
 FX BOUND     x...0282  0
 FX BOUND     x...0283  0
 FX BOUND     x...0284  0
 FX BOUND     x...0285  0
 FX BOUND     x...0286  0
 FX BOUND     x...0287  0
 FX BOUND     x...0288  0
 FX BOUND     x...0289  0
 FX BOUND     x...0290  0
 FX BOUND     x...0295  0
 FX BOUND     x...0296  0
 FX BOUND     x...0297  0
 FX BOUND     x...0298  0
 FX BOUND     x...0299  0
 UP BOUND     x...0300  82
 UP BOUND     x...0301  82
 UP BOUND     x...0302  82
 FX BOUND     x...0303  0
 FX BOUND     x...0304  0
 UP BOUND     x...0305  82
 UP BOUND     x...0306  82
 UP BOUND     x...0307  82
 UP BOUND     x...0308  82
 FX BOUND     x...0309  0
 FX BOUND     x...0310  0
 FX BOUND     x...0311  0
 UP BOUND     x...0312  82
 UP BOUND     x...0313  82
 FX BOUND     x...0314  0
 FX BOUND     x...0315  0
 FX BOUND     x...0316  0
 FX BOUND     x...0319  0
 FX BOUND     x...0320  0
 FX BOUND     x...0321  0
 FX BOUND     x...0322  0
 UP BOUND     x...0327  82
 UP BOUND     x...0328  82
 FX BOUND     x...0335  0
 FX BOUND     x...0336  0
 FX BOUND     x...0337  0
 FX BOUND     x...0338  0
 FX BOUND     x...0339  0
 FX BOUND     x...0340  1
 FX BOUND     x...0347  0
 FX BOUND     x...0348  0
 UP BOUND     x...0349  82
 UP BOUND     x...0350  82
 FX BOUND     x...0357  0
 UP BOUND     x...0358  82
 FX BOUND     x...0359  1
 FX BOUND     x...0360  0
 FX BOUND     x...0361  0
 FX BOUND     x...0362  0
 FX BOUND     x...0363  0
 FX BOUND     x...0364  0
 UP BOUND     x...0365  82
 UP BOUND     x...0366  82
 FX BOUND     x...0367  2
 FX BOUND     x...0368  0
 FX BOUND     x...0369  0
 FX BOUND     x...0370  0
 FX BOUND     x...0371  0
 FX BOUND     x...0372  0
 UP BOUND     x...0373  82
 UP BOUND     x...0374  82
 UP BOUND     x...0377  82
 UP BOUND     x...0378  82
 UP BOUND     x...0379  82
 UP BOUND     x...0380  82
 FX BOUND     x...0383  0
 UP BOUND     x...0384  82
 UP BOUND     x...0385  82
 UP BOUND     x...0386  82
 FX BOUND     x...0387  0
 FX BOUND     x...0388  0
 UP BOUND     x...0393  1
 FX BOUND     x...0394  0
 FX BOUND     x...0395  0
 FX BOUND     x...0396  0
 UP BOUND     x...0397  82
 FX BOUND     x...0398  0
 UP BOUND     x...0399  82
 FX BOUND     x...0400  0
 UP BOUND     x...0405  82
 FX BOUND     x...0406  0
 UP BOUND     x...0407  82
 UP BOUND     x...0408  82
 UP BOUND     x...0409  82
 UP BOUND     x...0410  82
 FX BOUND     x...0413  0
 FX BOUND     x...0414  0
 FX BOUND     x...0417  0
 FX BOUND     x...0418  0
 FX BOUND     x...0419  0
 FX BOUND     x...0420  0
 UP BOUND     x...0421  82
 UP BOUND     x...0422  82
 FX BOUND     x...0423  0
 UP BOUND     x...0424  82
 FX BOUND     x...0429  0
 FX BOUND     x...0430  0
 FX BOUND     x...0433  0
 FX BOUND     x...0434  0
 FX BOUND     x...0437  0
 FX BOUND     x...0438  0
 FX BOUND     x...0441  0
 FX BOUND     x...0442  0
 UP BOUND     x...0445  82
 FX BOUND     x...0446  0
 UP BOUND     x...0447  82
 UP BOUND     x...0448  82
 UP BOUND     x...0451  82
 UP BOUND     x...0452  82
 FX BOUND     x...0455  0
 FX BOUND     x...0456  0
 UP BOUND     x...0457  82
 FX BOUND     x...0458  0
 FX BOUND     x...0461  0
 FX BOUND     x...0462  0
 UP BOUND     x...0463  82
 UP BOUND     x...0464  82
 FX BOUND     x...0467  0
 FX BOUND     x...0468  0
 FX BOUND     x...0469  0
 FX BOUND     x...0470  0
 FX BOUND     x...0475  0
 FX BOUND     x...0476  1
 UP BOUND     x...0477  82
 UP BOUND     x...0478  82
 FX BOUND     x...0479  0
 FX BOUND     x...0480  0
 FX BOUND     x...0483  0
 FX BOUND     x...0484  0
 FX BOUND     x...0485  0
 FX BOUND     x...0486  0
 UP BOUND     x...0495  82
 UP BOUND     x...0496  82
 UP BOUND     x...0497  82
 UP BOUND     x...0498  82
 FX BOUND     x...0499  0
 FX BOUND     x...0500  0
 FX BOUND     x...0501  0
 FX BOUND     x...0502  0
 FX BOUND     x...0503  0
 FX BOUND     x...0504  1
 UP BOUND     x...0507  82
 UP BOUND     x...0508  82
 FX BOUND     x...0511  0
 FX BOUND     x...0512  0
 UP BOUND     x...0513  82
 UP BOUND     x...0514  82
 FX BOUND     x...0519  0
 FX BOUND     x...0520  0
 UP BOUND     x...0521  82
 FX BOUND     x...0522  0
 UP BOUND     x...0525  82
 FX BOUND     x...0526  0
 UP BOUND     x...0527  82
 UP BOUND     x...0528  82
 FX BOUND     x...0529  0
 FX BOUND     x...0530  0
 UP BOUND     x...0533  82
 UP BOUND     x...0534  82
 UP BOUND     x...0543  82
 UP BOUND     x...0544  82
 FX BOUND     x...0547  0
 FX BOUND     x...0548  0
 UP BOUND     x...0551  82
 UP BOUND     x...0552  82
 FX BOUND     x...0553  0
 FX BOUND     x...0554  0
 FX BOUND     x...0563  0
 UP BOUND     x...0564  82
 FX BOUND     x...0565  0
 FX BOUND     x...0566  0
 FX BOUND     x...0569  0
 FX BOUND     x...0570  0
 FX BOUND     x...0571  0
 FX BOUND     x...0572  0
 FX BOUND     x...0577  0
 FX BOUND     x...0578  0
 UP BOUND     x...0579  82
 FX BOUND     x...0580  0
 UP BOUND     x...0583  82
 FX BOUND     x...0584  0
 FX BOUND     x...0585  0
 FX BOUND     x...0586  0
 UP BOUND     x...0589  82
 UP BOUND     x...0590  82
 FX BOUND     x...0591  0
 FX BOUND     x...0592  0
 FX BOUND     x...0593  0
 FX BOUND     x...0594  1
 UP BOUND     x...0595  82
 UP BOUND     x...0596  82
 FX BOUND     x...0597  0
 UP BOUND     x...0598  82
 UP BOUND     x...0599  82
 UP BOUND     x...0600  82
 FX BOUND     x...0601  0
 UP BOUND     x...0602  1
 FX BOUND     x...0603  0
 UP BOUND     x...0604  82
 FX BOUND     x...0609  0
 FX BOUND     x...0610  0
 FX BOUND     x...0611  0
 FX BOUND     x...0612  0
 UP BOUND     x...0631  82
 UP BOUND     x...0632  82
 UP BOUND     x...0633  82
 FX BOUND     x...0634  0
 UP BOUND     x...0643  82
 FX BOUND     x...0644  0
 FX BOUND     x...0647  0
 FX BOUND     x...0648  0
 UP BOUND     x...0649  82
 FX BOUND     x...0650  0
 FX BOUND     x...0651  0
 UP BOUND     x...0652  1
 FX BOUND     x...0655  0
 FX BOUND     x...0656  0
 UP BOUND     x...0657  82
 UP BOUND     x...0658  82
 UP BOUND     x...0661  82
 UP BOUND     x...0662  82
 UP BOUND     x...0665  82
 UP BOUND     x...0666  82
 FX BOUND     x...0667  0
 FX BOUND     x...0668  0
 FX BOUND     x...0669  0
 FX BOUND     x...0670  0
 FX BOUND     x...0671  0
 FX BOUND     x...0672  0
 UP BOUND     x...0673  82
 UP BOUND     x...0674  82
 FX BOUND     x...0675  0
 FX BOUND     x...0676  0
 UP BOUND     x...0679  82
 UP BOUND     x...0680  82
 UP BOUND     x...0681  82
 UP BOUND     x...0682  82
 FX BOUND     x...0689  0
 FX BOUND     x...0690  0
 FX BOUND     x...0693  0
 UP BOUND     x...0694  82
 FX BOUND     x...0695  0
 FX BOUND     x...0696  0
 FX BOUND     x...0699  0
 FX BOUND     x...0700  0
 FX BOUND     x...0707  0
 UP BOUND     x...0708  82
 UP BOUND     x...0715  82
 UP BOUND     x...0716  82
 UP BOUND     x...0717  82
 UP BOUND     x...0718  82
 FX BOUND     x...0719  0
 FX BOUND     x...0720  0
 UP BOUND     x...0721  82
 UP BOUND     x...0722  82
 FX BOUND     x...0725  0
 FX BOUND     x...0726  0
 FX BOUND     x...0749  0
 FX BOUND     x...0750  0
 UP BOUND     x...0753  82
 UP BOUND     x...0754  82
 FX BOUND     x...0763  0
 FX BOUND     x...0764  0
 FX BOUND     x...0773  0
 FX BOUND     x...0774  0
 FX BOUND     x...0781  0
 FX BOUND     x...0782  0
 FX BOUND     x...0783  0
 FX BOUND     x...0784  0
 FX BOUND     x...0785  0
 FX BOUND     x...0786  0
 FX BOUND     x...0787  0
 FX BOUND     x...0788  0
 FX BOUND     x...0791  1
 FX BOUND     x...0792  0
 FX BOUND     x...0793  0
 FX BOUND     x...0794  0
 FX BOUND     x...0799  0
 FX BOUND     x...0800  0
 UP BOUND     x...0801  82
 UP BOUND     x...0802  82
 FX BOUND     x...0803  0
 FX BOUND     x...0804  0
 UP BOUND     x...0805  82
 UP BOUND     x...0806  82
 FX BOUND     x...0815  0
 FX BOUND     x...0816  0
 FX BOUND     x...0823  1
 FX BOUND     x...0824  0
 FX BOUND     x...0829  0
 FX BOUND     x...0830  0
 FX BOUND     x...0837  0
 UP BOUND     x...0838  82
 FX BOUND     x...0839  0
 FX BOUND     x...0840  0
 FX BOUND     x...0841  0
 UP BOUND     x...0842  82
 FX BOUND     x...0849  0
 FX BOUND     x...0850  0
 FX BOUND     x...0853  0
 FX BOUND     x...0854  0
 FX BOUND     x...0855  0
 UP BOUND     x...0856  82
 FX BOUND     x...0857  0
 FX BOUND     x...0858  0
 UP BOUND     x...0869  82
 FX BOUND     x...0870  0
 FX BOUND     x...0875  0
 FX BOUND     x...0876  0
 FX BOUND     x...0879  0
 FX BOUND     x...0880  0
 FX BOUND     x...0883  0
 FX BOUND     x...0884  0
 FX BOUND     x...0885  0
 FX BOUND     x...0886  0
 FX BOUND     x...0887  0
 FX BOUND     x...0888  0
 FX BOUND     x...0899  0
 FX BOUND     x...0900  0
 FX BOUND     x...0901  0
 FX BOUND     x...0902  0
 FX BOUND     x...0905  0
 UP BOUND     x...0906  82
 FX BOUND     x...0911  0
 FX BOUND     x...0912  0
 FX BOUND     x...0913  0
 FX BOUND     x...0914  0
 FX BOUND     x...0915  0
 FX BOUND     x...0916  0
 UP BOUND     x...0917  82
 UP BOUND     x...0918  82
 FX BOUND     x...0919  0
 FX BOUND     x...0920  0
 FX BOUND     x...0921  0
 FX BOUND     x...0922  0
 UP BOUND     x...0923  82
 UP BOUND     x...0924  82
 FX BOUND     x...0925  0
 FX BOUND     x...0926  0
 FX BOUND     x...0937  0
 FX BOUND     x...0938  0
 FX BOUND     x...0945  0
 UP BOUND     x...0946  82
 UP BOUND     x...0947  82
 UP BOUND     x...0948  82
 FX BOUND     x...0953  0
 FX BOUND     x...0954  0
 FX BOUND     x...0961  0
 FX BOUND     x...0962  0
 FX BOUND     x...0975  0
 FX BOUND     x...0976  0
 FX BOUND     x...0979  0
 FX BOUND     x...0980  0
 FX BOUND     x...0981  0
 FX BOUND     x...0982  0
 FX BOUND     x...0985  0
 FX BOUND     x...0986  0
 UP BOUND     x...0987  82
 FX BOUND     x...0988  0
 UP BOUND     x...0991  82
 UP BOUND     x...0992  82
 FX BOUND     x...0995  0
 FX BOUND     x...0996  0
 FX BOUND     x...0999  0
 FX BOUND     x...1000  0
 FX BOUND     x...1001  0
 UP BOUND     x...1002  82
 FX BOUND     x...1003  0
 UP BOUND     x...1004  82
 UP BOUND     x...1005  82
 UP BOUND     x...1006  82
 FX BOUND     x...1007  0
 FX BOUND     x...1008  0
 FX BOUND     x...1009  0
 FX BOUND     x...1010  0
 FX BOUND     x...1011  0
 FX BOUND     x...1012  0
 UP BOUND     x...1013  82
 FX BOUND     x...1014  0
 FX BOUND     x...1015  0
 FX BOUND     x...1016  0
 FX BOUND     x...1017  1
 FX BOUND     x...1018  0
 FX BOUND     x...1019  0
 FX BOUND     x...1020  0
 UP BOUND     x...1021  82
 UP BOUND     x...1022  82
 FX BOUND     x...1023  0
 FX BOUND     x...1024  0
 FX BOUND     x...1025  0
 FX BOUND     x...1026  0
 UP BOUND     x...1027  82
 UP BOUND     x...1028  82
 UP BOUND     x...1029  82
 UP BOUND     x...1030  82
 FX BOUND     x...1031  0
 FX BOUND     x...1032  0
 UP BOUND     x...1033  82
 UP BOUND     x...1034  82
 FX BOUND     x...1035  0
 FX BOUND     x...1036  0
 UP BOUND     x...1037  82
 UP BOUND     x...1038  82
 FX BOUND     x...1039  0
 FX BOUND     x...1040  0
 FX BOUND     x...1041  0
 FX BOUND     x...1042  0
 FX BOUND     x...1043  0
 FX BOUND     x...1044  0
 UP BOUND     x...1045  82
 UP BOUND     x...1046  82
 FX BOUND     x...1047  0
 FX BOUND     x...1048  0
 FX BOUND     x...1049  0
 FX BOUND     x...1050  0
 UP BOUND     x...1051  82
 UP BOUND     x...1052  82
 FX BOUND     x...1053  0
 UP BOUND     x...1054  82
 FX BOUND     x...1055  0
 FX BOUND     x...1056  0
 FX BOUND     x...1057  0
 FX BOUND     x...1058  0
 FX BOUND     x...1059  0
 UP BOUND     x...1060  82
 UP BOUND     x...1061  82
 UP BOUND     x...1062  82
 FX BOUND     x...1063  0
 FX BOUND     x...1064  0
 FX BOUND     x...1065  0
 UP BOUND     x...1066  82
 UP BOUND     x...1067  82
 UP BOUND     x...1068  82
 UP BOUND     x...1069  82
 FX BOUND     x...1070  0
 FX BOUND     x...1071  0
 FX BOUND     x...1072  0
 UP BOUND     x...1073  82
 UP BOUND     x...1074  82
 FX BOUND     x...1075  0
 FX BOUND     x...1076  0
 FX BOUND     x...1077  0
 UP BOUND     x...1078  82
 UP BOUND     x...1079  82
 UP BOUND     x...1080  82
 UP BOUND     x...1081  82
 UP BOUND     x...1082  82
 FX BOUND     x...1083  0
 FX BOUND     x...1084  0
 UP BOUND     x...1085  82
 UP BOUND     x...1086  82
 FX BOUND     x...1087  0
 UP BOUND     x...1088  82
 FX BOUND     x...1089  0
 FX BOUND     x...1090  0
 UP BOUND     x...1091  1
 FX BOUND     x...1092  0
 UP BOUND     x...1093  82
 FX BOUND     x...1094  0
 FX BOUND     x...1095  0
 FX BOUND     x...1096  0
 FX BOUND     x...1097  0
 FX BOUND     x...1098  0
 UP BOUND     x...1099  82
 UP BOUND     x...1100  82
 FX BOUND     x...1101  0
 FX BOUND     x...1102  0
 FX BOUND     x...1103  0
 FX BOUND     x...1104  0
 UP BOUND     x...1105  82
 UP BOUND     x...1106  82
 FX BOUND     x...1107  0
 UP BOUND     x...1108  1
 FX BOUND     x...1109  0
 LO BOUND     x...1110  1
 UP BOUND     x...1110  2
 UP BOUND     x...1111  82
 UP BOUND     x...1112  82
 LO BOUND     x...1113  1
 UP BOUND     x...1113  2
 FX BOUND     x...1114  0
 FX BOUND     x...1115  0
 FX BOUND     x...1116  0
 UP BOUND     x...1117  82
 FX BOUND     x...1118  0
 FX BOUND     x...1119  0
 FX BOUND     x...1120  0
 UP BOUND     x...1121  82
 UP BOUND     x...1122  82
 FX BOUND     x...1123  0
 FX BOUND     x...1124  0
 FX BOUND     x...1125  0
 UP BOUND     x...1126  82
 FX BOUND     x...1127  0
 FX BOUND     x...1128  0
 FX BOUND     x...1129  0
 FX BOUND     x...1130  0
 UP BOUND     x...1131  82
 UP BOUND     x...1132  82
 FX BOUND     x...1133  0
 FX BOUND     x...1134  0
 UP BOUND     x...1135  82
 UP BOUND     x...1136  82
 FX BOUND     x...1137  0
 FX BOUND     x...1138  0
 FX BOUND     x...1139  0
 FX BOUND     x...1140  0
 FX BOUND     x...1141  0
 FX BOUND     x...1142  0
 FX BOUND     x...1143  0
 FX BOUND     x...1144  0
 FX BOUND     x...1145  0
 FX BOUND     x...1146  0
 UP BOUND     x...1147  82
 UP BOUND     x...1148  82
 UP BOUND     x...1149  82
 FX BOUND     x...1150  0
 UP BOUND     x...1151  82
 FX BOUND     x...1152  0
 FX BOUND     x...1153  0
 FX BOUND     x...1154  0
 UP BOUND     x...1155  82
 UP BOUND     x...1156  82
 FX BOUND     x...1157  0
 UP BOUND     x...1158  82
 FX BOUND     x...1159  0
 UP BOUND     x...1160  82
 FX BOUND     x...1161  0
 FX BOUND     x...1162  0
 FX BOUND     x...1163  0
 FX BOUND     x...1164  0
 FX BOUND     x...1165  0
 FX BOUND     x...1166  0
 FX BOUND     x...1167  0
 FX BOUND     x...1168  0
 UP BOUND     x...1169  82
 UP BOUND     x...1170  82
 UP BOUND     x...1171  1
 FX BOUND     x...1172  0
 FX BOUND     x...1173  0
 FX BOUND     x...1174  0
 FX BOUND     x...1175  0
 FX BOUND     x...1176  0
 FX BOUND     x...1177  0
 FX BOUND     x...1178  0
 FX BOUND     x...1179  0
 FX BOUND     x...1180  0
 FX BOUND     x...1181  0
 FX BOUND     x...1182  0
 FX BOUND     x...1183  0
 FX BOUND     x...1184  0
 FX BOUND     x...1185  0
 FX BOUND     x...1186  0
 FX BOUND     x...1187  0
 UP BOUND     x...1188  82
 FX BOUND     x...1189  0
 FX BOUND     x...1190  0
 UP BOUND     x...1191  82
 UP BOUND     x...1192  82
 FX BOUND     x...1193  0
 FX BOUND     x...1194  0
 UP BOUND     x...1195  82
 FX BOUND     x...1196  0
 FX BOUND     x...1197  0
 FX BOUND     x...1198  0
 FX BOUND     x...1199  0
 FX BOUND     x...1200  0
 FX BOUND     x...1201  0
 FX BOUND     x...1202  0
 FX BOUND     x...1203  0
 FX BOUND     x...1204  0
 FX BOUND     x...1205  0
 FX BOUND     x...1206  0
 UP BOUND     x...1207  82
 UP BOUND     x...1208  82
 FX BOUND     x...1209  0
 FX BOUND     x...1210  0
 FX BOUND     x...1211  0
 FX BOUND     x...1212  0
 FX BOUND     x...1213  0
 FX BOUND     x...1214  0
 FX BOUND     x...1215  0
 FX BOUND     x...1216  0
 FX BOUND     x...1217  0
 FX BOUND     x...1218  0
 UP BOUND     x...1219  82
 UP BOUND     x...1220  82
 FX BOUND     x...1221  0
 FX BOUND     x...1222  0
 UP BOUND     x...1223  82
 FX BOUND     x...1224  0
 FX BOUND     x...1225  0
 FX BOUND     x...1226  0
 UP BOUND     x...1227  82
 FX BOUND     x...1228  0
 FX BOUND     x...1229  0
 FX BOUND     x...1230  0
 FX BOUND     x...1231  0
 UP BOUND     x...1232  82
 UP BOUND     x...1233  82
 UP BOUND     x...1234  82
 FX BOUND     x...1235  0
 FX BOUND     x...1236  0
 FX BOUND     x...1237  0
 FX BOUND     x...1238  0
 UP BOUND     x...1239  82
 UP BOUND     x...1240  82
 FX BOUND     x...1241  0
 FX BOUND     x...1242  0
 FX BOUND     x...1243  0
 FX BOUND     x...1244  0
 UP BOUND     x...1245  82
 UP BOUND     x...1246  82
 UP BOUND     x...1247  82
 UP BOUND     x...1248  82
 UP BOUND     x...1249  82
 FX BOUND     x...1250  0
 BV BOUND     y...0001
 BV BOUND     y...0002
 BV BOUND     y...0003
 BV BOUND     y...0004
 BV BOUND     y...0005
 BV BOUND     y...0006
 FX BOUND     y...0007  0
 FX BOUND     y...0008  0
 BV BOUND     y...0009
 BV BOUND     y...0010
 BV BOUND     y...0011
 FX BOUND     y...0012  1
 BV BOUND     y...0013
 FX BOUND     y...0014  1
 BV BOUND     y...0015
 FX BOUND     y...0016  0
 FX BOUND     y...0017  0
 FX BOUND     y...0018  0
 FX BOUND     y...0019  0
 FX BOUND     y...0020  0
 FX BOUND     y...0021  0
 BV BOUND     y...0022
 FX BOUND     y...0025  0
 BV BOUND     y...0026
 FX BOUND     y...0027  1
 BV BOUND     y...0028
 FX BOUND     y...0029  0
 BV BOUND     y...0030
 FX BOUND     y...0031  0
 BV BOUND     y...0032
 FX BOUND     y...0035  0
 FX BOUND     y...0036  0
 BV BOUND     y...0037
 FX BOUND     y...0038  0
 BV BOUND     y...0039
 FX BOUND     y...0040  0
 BV BOUND     y...0041
 BV BOUND     y...0042
 BV BOUND     y...0045
 BV BOUND     y...0046
 BV BOUND     y...0047
 BV BOUND     y...0048
 BV BOUND     y...0049
 FX BOUND     y...0050  0
 FX BOUND     y...0051  0
 FX BOUND     y...0052  0
 BV BOUND     y...0053
 BV BOUND     y...0054
 BV BOUND     y...0055
 BV BOUND     y...0056
 FX BOUND     y...0057  0
 BV BOUND     y...0058
 FX BOUND     y...0059  0
 BV BOUND     y...0060
 FX BOUND     y...0061  0
 FX BOUND     y...0062  0
 BV BOUND     y...0063
 BV BOUND     y...0064
 FX BOUND     y...0065  0
 BV BOUND     y...0066
 BV BOUND     y...0067
 BV BOUND     y...0068
 BV BOUND     y...0069
 BV BOUND     y...0070
 BV BOUND     y...0071
 BV BOUND     y...0072
 BV BOUND     y...0073
 FX BOUND     y...0074  0
 FX BOUND     y...0075  0
 BV BOUND     y...0076
 FX BOUND     y...0077  0
 BV BOUND     y...0078
 FX BOUND     y...0079  0
 BV BOUND     y...0080
 FX BOUND     y...0081  0
 BV BOUND     y...0082
 BV BOUND     y...0083
 BV BOUND     y...0084
 FX BOUND     y...0085  0
 BV BOUND     y...0086
 FX BOUND     y...0087  0
 BV BOUND     y...0088
 FX BOUND     y...0089  0
 FX BOUND     y...0090  0
 BV BOUND     y...0091
 FX BOUND     y...0092  1
 BV BOUND     y...0093
 BV BOUND     y...0094
 BV BOUND     y...0095
 FX BOUND     y...0096  0
 BV BOUND     y...0097
 FX BOUND     y...0098  0
 FX BOUND     y...0099  0
 FX BOUND     y...0100  0
 BV BOUND     y...0103
 FX BOUND     y...0104  0
 FX BOUND     y...0105  0
 BV BOUND     y...0106
 FX BOUND     y...0109  0
 BV BOUND     y...0110
 FX BOUND     y...0111  0
 BV BOUND     y...0112
 FX BOUND     y...0113  0
 BV BOUND     y...0114
 BV BOUND     y...0115
 FX BOUND     y...0116  0
 FX BOUND     y...0117  0
 FX BOUND     y...0118  1
 BV BOUND     y...0119
 FX BOUND     y...0120  0
 BV BOUND     y...0121
 BV BOUND     y...0122
 BV BOUND     y...0123
 BV BOUND     y...0124
 BV BOUND     y...0125
 FX BOUND     y...0126  0
 BV BOUND     y...0127
 FX BOUND     y...0128  0
 BV BOUND     y...0129
 FX BOUND     y...0130  0
 FX BOUND     y...0131  1
 FX BOUND     y...0132  0
 FX BOUND     y...0133  0
 BV BOUND     y...0134
 FX BOUND     y...0135  0
 BV BOUND     y...0136
 FX BOUND     y...0137  1
 BV BOUND     y...0138
 FX BOUND     y...0139  0
 BV BOUND     y...0140
 BV BOUND     y...0143
 FX BOUND     y...0144  0
 BV BOUND     y...0145
 FX BOUND     y...0146  1
 BV BOUND     y...0147
 BV BOUND     y...0148
 FX BOUND     y...0149  1
 FX BOUND     y...0150  0
 FX BOUND     y...0151  1
 FX BOUND     y...0152  0
 FX BOUND     y...0155  1
 FX BOUND     y...0156  0
 BV BOUND     y...0163
 FX BOUND     y...0164  0
 FX BOUND     y...0169  0
 BV BOUND     y...0170
 BV BOUND     y...0171
 BV BOUND     y...0172
 FX BOUND     y...0173  0
 BV BOUND     y...0174
 FX BOUND     y...0175  1
 BV BOUND     y...0176
 BV BOUND     y...0179
 BV BOUND     y...0180
 BV BOUND     y...0181
 BV BOUND     y...0182
 BV BOUND     y...0185
 BV BOUND     y...0186
 FX BOUND     y...0187  0
 FX BOUND     y...0188  0
 BV BOUND     y...0191
 FX BOUND     y...0192  0
 BV BOUND     y...0193
 FX BOUND     y...0194  0
 BV BOUND     y...0195
 FX BOUND     y...0196  0
 BV BOUND     y...0197
 FX BOUND     y...0198  0
 BV BOUND     y...0199
 BV BOUND     y...0200
 BV BOUND     y...0201
 BV BOUND     y...0202
 FX BOUND     y...0203  0
 BV BOUND     y...0204
 BV BOUND     y...0205
 BV BOUND     y...0206
 BV BOUND     y...0207
 BV BOUND     y...0208
 FX BOUND     y...0211  0
 BV BOUND     y...0212
 FX BOUND     y...0215  0
 FX BOUND     y...0216  0
 FX BOUND     y...0217  0
 FX BOUND     y...0218  0
 FX BOUND     y...0221  0
 FX BOUND     y...0222  0
 BV BOUND     y...0223
 BV BOUND     y...0224
 BV BOUND     y...0225
 BV BOUND     y...0226
 BV BOUND     y...0227
 FX BOUND     y...0228  0
 BV BOUND     y...0231
 FX BOUND     y...0232  0
 FX BOUND     y...0233  0
 BV BOUND     y...0234
 FX BOUND     y...0237  0
 FX BOUND     y...0238  0
 FX BOUND     y...0243  0
 BV BOUND     y...0244
 FX BOUND     y...0245  0
 BV BOUND     y...0246
 FX BOUND     y...0247  0
 BV BOUND     y...0248
 FX BOUND     y...0249  0
 BV BOUND     y...0250
 BV BOUND     y...0251
 FX BOUND     y...0252  0
 FX BOUND     y...0253  0
 FX BOUND     y...0254  0
 FX BOUND     y...0255  0
 FX BOUND     y...0256  0
 BV BOUND     y...0257
 FX BOUND     y...0258  1
 BV BOUND     y...0259
 FX BOUND     y...0260  0
 BV BOUND     y...0261
 FX BOUND     y...0262  0
 BV BOUND     y...0263
 FX BOUND     y...0264  0
 FX BOUND     y...0267  0
 FX BOUND     y...0268  0
 BV BOUND     y...0269
 BV BOUND     y...0270
 FX BOUND     y...0271  0
 BV BOUND     y...0272
 FX BOUND     y...0273  0
 BV BOUND     y...0274
 FX BOUND     y...0275  0
 BV BOUND     y...0276
 FX BOUND     y...0277  0
 BV BOUND     y...0278
 FX BOUND     y...0281  0
 FX BOUND     y...0282  0
 FX BOUND     y...0283  0
 FX BOUND     y...0284  0
 BV BOUND     y...0285
 FX BOUND     y...0286  0
 BV BOUND     y...0287
 FX BOUND     y...0288  0
 BV BOUND     y...0289
 FX BOUND     y...0290  0
 BV BOUND     y...0295
 FX BOUND     y...0296  0
 FX BOUND     y...0297  0
 FX BOUND     y...0298  0
 FX BOUND     y...0299  0
 BV BOUND     y...0300
 BV BOUND     y...0301
 BV BOUND     y...0302
 FX BOUND     y...0303  0
 BV BOUND     y...0304
 BV BOUND     y...0305
 BV BOUND     y...0306
 BV BOUND     y...0307
 BV BOUND     y...0308
 FX BOUND     y...0309  0
 FX BOUND     y...0310  0
 FX BOUND     y...0311  0
 FX BOUND     y...0312  1
 BV BOUND     y...0313
 FX BOUND     y...0314  0
 BV BOUND     y...0315
 FX BOUND     y...0316  0
 BV BOUND     y...0319
 FX BOUND     y...0320  0
 BV BOUND     y...0321
 FX BOUND     y...0322  0
 BV BOUND     y...0327
 BV BOUND     y...0328
 FX BOUND     y...0335  0
 FX BOUND     y...0336  0
 BV BOUND     y...0337
 FX BOUND     y...0338  0
 FX BOUND     y...0339  0
 FX BOUND     y...0340  1
 FX BOUND     y...0347  0
 BV BOUND     y...0348
 BV BOUND     y...0349
 BV BOUND     y...0350
 FX BOUND     y...0357  0
 BV BOUND     y...0358
 FX BOUND     y...0359  1
 FX BOUND     y...0360  0
 FX BOUND     y...0361  0
 FX BOUND     y...0362  0
 FX BOUND     y...0363  0
 FX BOUND     y...0364  0
 BV BOUND     y...0365
 BV BOUND     y...0366
 FX BOUND     y...0367  1
 FX BOUND     y...0368  0
 BV BOUND     y...0369
 FX BOUND     y...0370  0
 BV BOUND     y...0371
 FX BOUND     y...0372  0
 BV BOUND     y...0373
 BV BOUND     y...0374
 BV BOUND     y...0377
 BV BOUND     y...0378
 BV BOUND     y...0379
 BV BOUND     y...0380
 FX BOUND     y...0383  0
 BV BOUND     y...0384
 BV BOUND     y...0385
 BV BOUND     y...0386
 FX BOUND     y...0387  0
 BV BOUND     y...0388
 FX BOUND     y...0393  1
 FX BOUND     y...0394  0
 FX BOUND     y...0395  0
 FX BOUND     y...0396  0
 FX BOUND     y...0397  1
 FX BOUND     y...0398  0
 BV BOUND     y...0399
 FX BOUND     y...0400  0
 BV BOUND     y...0405
 FX BOUND     y...0406  0
 BV BOUND     y...0407
 BV BOUND     y...0408
 BV BOUND     y...0409
 FX BOUND     y...0410  1
 FX BOUND     y...0413  0
 FX BOUND     y...0414  0
 FX BOUND     y...0417  0
 BV BOUND     y...0418
 FX BOUND     y...0419  0
 BV BOUND     y...0420
 BV BOUND     y...0421
 BV BOUND     y...0422
 FX BOUND     y...0423  0
 BV BOUND     y...0424
 FX BOUND     y...0429  0
 FX BOUND     y...0430  0
 FX BOUND     y...0433  0
 FX BOUND     y...0434  0
 FX BOUND     y...0437  0
 FX BOUND     y...0438  0
 BV BOUND     y...0441
 FX BOUND     y...0442  0
 BV BOUND     y...0445
 FX BOUND     y...0446  0
 BV BOUND     y...0447
 BV BOUND     y...0448
 BV BOUND     y...0451
 BV BOUND     y...0452
 FX BOUND     y...0455  0
 FX BOUND     y...0456  0
 FX BOUND     y...0457  1
 FX BOUND     y...0458  0
 FX BOUND     y...0461  0
 BV BOUND     y...0462
 BV BOUND     y...0463
 BV BOUND     y...0464
 FX BOUND     y...0467  0
 BV BOUND     y...0468
 FX BOUND     y...0469  0
 BV BOUND     y...0470
 FX BOUND     y...0475  0
 FX BOUND     y...0476  1
 BV BOUND     y...0477
 BV BOUND     y...0478
 FX BOUND     y...0479  0
 FX BOUND     y...0480  0
 BV BOUND     y...0483
 FX BOUND     y...0484  0
 BV BOUND     y...0485
 FX BOUND     y...0486  0
 BV BOUND     y...0495
 BV BOUND     y...0496
 BV BOUND     y...0497
 FX BOUND     y...0498  1
 FX BOUND     y...0499  0
 FX BOUND     y...0500  0
 FX BOUND     y...0501  0
 FX BOUND     y...0502  0
 FX BOUND     y...0503  0
 FX BOUND     y...0504  1
 BV BOUND     y...0507
 BV BOUND     y...0508
 FX BOUND     y...0511  0
 BV BOUND     y...0512
 BV BOUND     y...0513
 BV BOUND     y...0514
 FX BOUND     y...0519  0
 FX BOUND     y...0520  0
 BV BOUND     y...0521
 FX BOUND     y...0522  0
 FX BOUND     y...0525  1
 FX BOUND     y...0526  0
 BV BOUND     y...0527
 BV BOUND     y...0528
 BV BOUND     y...0529
 FX BOUND     y...0530  0
 BV BOUND     y...0533
 BV BOUND     y...0534
 BV BOUND     y...0543
 FX BOUND     y...0544  1
 FX BOUND     y...0547  0
 FX BOUND     y...0548  0
 BV BOUND     y...0551
 BV BOUND     y...0552
 FX BOUND     y...0553  0
 BV BOUND     y...0554
 FX BOUND     y...0563  0
 BV BOUND     y...0564
 FX BOUND     y...0565  0
 BV BOUND     y...0566
 FX BOUND     y...0569  0
 FX BOUND     y...0570  0
 FX BOUND     y...0571  0
 FX BOUND     y...0572  0
 FX BOUND     y...0577  0
 FX BOUND     y...0578  0
 BV BOUND     y...0579
 FX BOUND     y...0580  0
 BV BOUND     y...0583
 FX BOUND     y...0584  0
 BV BOUND     y...0585
 FX BOUND     y...0586  0
 BV BOUND     y...0589
 FX BOUND     y...0590  1
 FX BOUND     y...0591  0
 FX BOUND     y...0592  0
 FX BOUND     y...0593  0
 FX BOUND     y...0594  1
 BV BOUND     y...0595
 BV BOUND     y...0596
 FX BOUND     y...0597  0
 BV BOUND     y...0598
 BV BOUND     y...0599
 BV BOUND     y...0600
 FX BOUND     y...0601  0
 BV BOUND     y...0602
 FX BOUND     y...0603  0
 BV BOUND     y...0604
 FX BOUND     y...0609  0
 FX BOUND     y...0610  0
 FX BOUND     y...0611  0
 FX BOUND     y...0612  0
 BV BOUND     y...0631
 BV BOUND     y...0632
 BV BOUND     y...0633
 FX BOUND     y...0634  0
 FX BOUND     y...0643  1
 FX BOUND     y...0644  0
 BV BOUND     y...0647
 FX BOUND     y...0648  0
 FX BOUND     y...0649  1
 FX BOUND     y...0650  0
 FX BOUND     y...0651  0
 BV BOUND     y...0652
 FX BOUND     y...0655  0
 BV BOUND     y...0656
 BV BOUND     y...0657
 BV BOUND     y...0658
 BV BOUND     y...0661
 BV BOUND     y...0662
 BV BOUND     y...0665
 BV BOUND     y...0666
 FX BOUND     y...0667  0
 FX BOUND     y...0668  0
 FX BOUND     y...0669  0
 FX BOUND     y...0670  0
 BV BOUND     y...0671
 FX BOUND     y...0672  0
 BV BOUND     y...0673
 BV BOUND     y...0674
 BV BOUND     y...0675
 FX BOUND     y...0676  0
 BV BOUND     y...0679
 BV BOUND     y...0680
 BV BOUND     y...0681
 BV BOUND     y...0682
 FX BOUND     y...0689  0
 FX BOUND     y...0690  0
 FX BOUND     y...0693  0
 BV BOUND     y...0694
 FX BOUND     y...0695  0
 BV BOUND     y...0696
 FX BOUND     y...0699  0
 BV BOUND     y...0700
 FX BOUND     y...0707  0
 BV BOUND     y...0708
 BV BOUND     y...0715
 BV BOUND     y...0716
 BV BOUND     y...0717
 BV BOUND     y...0718
 FX BOUND     y...0719  0
 FX BOUND     y...0720  0
 BV BOUND     y...0721
 BV BOUND     y...0722
 BV BOUND     y...0725
 FX BOUND     y...0726  0
 BV BOUND     y...0749
 FX BOUND     y...0750  0
 BV BOUND     y...0753
 BV BOUND     y...0754
 FX BOUND     y...0763  0
 FX BOUND     y...0764  0
 FX BOUND     y...0773  0
 FX BOUND     y...0774  0
 FX BOUND     y...0781  0
 BV BOUND     y...0782
 FX BOUND     y...0783  0
 BV BOUND     y...0784
 FX BOUND     y...0785  0
 BV BOUND     y...0786
 FX BOUND     y...0787  0
 BV BOUND     y...0788
 FX BOUND     y...0791  1
 FX BOUND     y...0792  0
 FX BOUND     y...0793  0
 FX BOUND     y...0794  0
 FX BOUND     y...0799  0
 FX BOUND     y...0800  0
 BV BOUND     y...0801
 BV BOUND     y...0802
 BV BOUND     y...0803
 FX BOUND     y...0804  0
 BV BOUND     y...0805
 BV BOUND     y...0806
 BV BOUND     y...0815
 FX BOUND     y...0816  0
 FX BOUND     y...0823  1
 FX BOUND     y...0824  0
 FX BOUND     y...0829  0
 FX BOUND     y...0830  0
 FX BOUND     y...0837  0
 BV BOUND     y...0838
 FX BOUND     y...0839  0
 BV BOUND     y...0840
 FX BOUND     y...0841  0
 BV BOUND     y...0842
 FX BOUND     y...0849  0
 BV BOUND     y...0850
 FX BOUND     y...0853  0
 FX BOUND     y...0854  0
 FX BOUND     y...0855  0
 BV BOUND     y...0856
 BV BOUND     y...0857
 FX BOUND     y...0858  0
 BV BOUND     y...0869
 FX BOUND     y...0870  0
 BV BOUND     y...0875
 FX BOUND     y...0876  0
 BV BOUND     y...0879
 FX BOUND     y...0880  0
 BV BOUND     y...0883
 FX BOUND     y...0884  0
 FX BOUND     y...0885  0
 FX BOUND     y...0886  0
 FX BOUND     y...0887  0
 BV BOUND     y...0888
 FX BOUND     y...0899  0
 BV BOUND     y...0900
 FX BOUND     y...0901  0
 BV BOUND     y...0902
 FX BOUND     y...0905  0
 BV BOUND     y...0906
 FX BOUND     y...0911  0
 FX BOUND     y...0912  0
 FX BOUND     y...0913  0
 FX BOUND     y...0914  0
 FX BOUND     y...0915  0
 FX BOUND     y...0916  0
 BV BOUND     y...0917
 BV BOUND     y...0918
 BV BOUND     y...0919
 FX BOUND     y...0920  0
 BV BOUND     y...0921
 FX BOUND     y...0922  0
 BV BOUND     y...0923
 BV BOUND     y...0924
 FX BOUND     y...0925  0
 FX BOUND     y...0926  0
 FX BOUND     y...0937  0
 FX BOUND     y...0938  0
 FX BOUND     y...0945  0
 BV BOUND     y...0946
 FX BOUND     y...0947  1
 BV BOUND     y...0948
 FX BOUND     y...0953  0
 BV BOUND     y...0954
 FX BOUND     y...0961  0
 BV BOUND     y...0962
 FX BOUND     y...0975  0
 FX BOUND     y...0976  0
 FX BOUND     y...0979  0
 FX BOUND     y...0980  0
 FX BOUND     y...0981  0
 FX BOUND     y...0982  0
 BV BOUND     y...0985
 FX BOUND     y...0986  0
 BV BOUND     y...0987
 FX BOUND     y...0988  0
 BV BOUND     y...0991
 BV BOUND     y...0992
 BV BOUND     y...0995
 FX BOUND     y...0996  0
 FX BOUND     y...0999  0
 FX BOUND     y...1000  0
 FX BOUND     y...1001  0
 BV BOUND     y...1002
 FX BOUND     y...1003  0
 BV BOUND     y...1004
 BV BOUND     y...1005
 BV BOUND     y...1006
 FX BOUND     y...1007  0
 BV BOUND     y...1008
 FX BOUND     y...1009  0
 BV BOUND     y...1010
 FX BOUND     y...1011  0
 FX BOUND     y...1012  0
 BV BOUND     y...1013
 FX BOUND     y...1014  0
 BV BOUND     y...1015
 FX BOUND     y...1016  0
 FX BOUND     y...1017  1
 FX BOUND     y...1018  0
 BV BOUND     y...1019
 FX BOUND     y...1020  0
 BV BOUND     y...1021
 BV BOUND     y...1022
 BV BOUND     y...1023
 FX BOUND     y...1024  0
 FX BOUND     y...1025  0
 FX BOUND     y...1026  0
 BV BOUND     y...1027
 BV BOUND     y...1028
 BV BOUND     y...1029
 BV BOUND     y...1030
 FX BOUND     y...1031  0
 BV BOUND     y...1032
 BV BOUND     y...1033
 BV BOUND     y...1034
 FX BOUND     y...1035  0
 BV BOUND     y...1036
 BV BOUND     y...1037
 BV BOUND     y...1038
 FX BOUND     y...1039  0
 FX BOUND     y...1040  0
 BV BOUND     y...1041
 FX BOUND     y...1042  0
 BV BOUND     y...1043
 FX BOUND     y...1044  0
 BV BOUND     y...1045
 BV BOUND     y...1046
 BV BOUND     y...1047
 FX BOUND     y...1048  0
 FX BOUND     y...1049  0
 FX BOUND     y...1050  0
 BV BOUND     y...1051
 BV BOUND     y...1052
 FX BOUND     y...1053  0
 BV BOUND     y...1054
 FX BOUND     y...1055  0
 BV BOUND     y...1056
 FX BOUND     y...1057  0
 BV BOUND     y...1058
 FX BOUND     y...1059  0
 BV BOUND     y...1060
 FX BOUND     y...1061  1
 BV BOUND     y...1062
 FX BOUND     y...1063  0
 FX BOUND     y...1064  0
 FX BOUND     y...1065  0
 FX BOUND     y...1066  1
 BV BOUND     y...1067
 BV BOUND     y...1068
 BV BOUND     y...1069
 FX BOUND     y...1070  0
 BV BOUND     y...1071
 FX BOUND     y...1072  0
 BV BOUND     y...1073
 BV BOUND     y...1074
 FX BOUND     y...1075  0
 FX BOUND     y...1076  0
 FX BOUND     y...1077  0
 FX BOUND     y...1078  1
 BV BOUND     y...1079
 BV BOUND     y...1080
 BV BOUND     y...1081
 BV BOUND     y...1082
 FX BOUND     y...1083  0
 BV BOUND     y...1084
 BV BOUND     y...1085
 BV BOUND     y...1086
 FX BOUND     y...1087  0
 BV BOUND     y...1088
 FX BOUND     y...1089  0
 FX BOUND     y...1090  0
 BV BOUND     y...1091
 FX BOUND     y...1092  0
 BV BOUND     y...1093
 FX BOUND     y...1094  0
 BV BOUND     y...1095
 FX BOUND     y...1096  0
 BV BOUND     y...1097
 FX BOUND     y...1098  0
 BV BOUND     y...1099
 BV BOUND     y...1100
 FX BOUND     y...1101  0
 FX BOUND     y...1102  0
 FX BOUND     y...1103  0
 BV BOUND     y...1104
 BV BOUND     y...1105
 BV BOUND     y...1106
 FX BOUND     y...1107  0
 BV BOUND     y...1108
 FX BOUND     y...1109  0
 FX BOUND     y...1110  1
 BV BOUND     y...1111
 BV BOUND     y...1112
 FX BOUND     y...1113  1
 FX BOUND     y...1114  0
 FX BOUND     y...1115  0
 FX BOUND     y...1116  0
 BV BOUND     y...1117
 FX BOUND     y...1118  0
 BV BOUND     y...1119
 FX BOUND     y...1120  0
 BV BOUND     y...1121
 BV BOUND     y...1122
 BV BOUND     y...1123
 FX BOUND     y...1124  0
 FX BOUND     y...1125  0
 BV BOUND     y...1126
 FX BOUND     y...1127  0
 FX BOUND     y...1128  0
 FX BOUND     y...1129  0
 BV BOUND     y...1130
 BV BOUND     y...1131
 BV BOUND     y...1132
 FX BOUND     y...1133  0
 BV BOUND     y...1134
 BV BOUND     y...1135
 BV BOUND     y...1136
 FX BOUND     y...1137  0
 FX BOUND     y...1138  0
 FX BOUND     y...1139  0
 FX BOUND     y...1140  0
 FX BOUND     y...1141  0
 BV BOUND     y...1142
 BV BOUND     y...1143
 FX BOUND     y...1144  0
 BV BOUND     y...1145
 FX BOUND     y...1146  0
 BV BOUND     y...1147
 BV BOUND     y...1148
 BV BOUND     y...1149
 FX BOUND     y...1150  0
 BV BOUND     y...1151
 FX BOUND     y...1152  0
 FX BOUND     y...1153  0
 FX BOUND     y...1154  0
 FX BOUND     y...1155  1
 BV BOUND     y...1156
 FX BOUND     y...1157  0
 BV BOUND     y...1158
 FX BOUND     y...1159  0
 BV BOUND     y...1160
 FX BOUND     y...1161  0
 BV BOUND     y...1162
 FX BOUND     y...1163  0
 FX BOUND     y...1164  0
 FX BOUND     y...1165  0
 FX BOUND     y...1166  0
 FX BOUND     y...1167  0
 FX BOUND     y...1168  0
 BV BOUND     y...1169
 BV BOUND     y...1170
 BV BOUND     y...1171
 FX BOUND     y...1172  0
 BV BOUND     y...1173
 FX BOUND     y...1174  0
 BV BOUND     y...1175
 FX BOUND     y...1176  0
 FX BOUND     y...1177  0
 FX BOUND     y...1178  0
 FX BOUND     y...1179  0
 BV BOUND     y...1180
 FX BOUND     y...1181  0
 BV BOUND     y...1182
 FX BOUND     y...1183  0
 BV BOUND     y...1184
 FX BOUND     y...1185  0
 BV BOUND     y...1186
 FX BOUND     y...1187  0
 BV BOUND     y...1188
 FX BOUND     y...1189  0
 FX BOUND     y...1190  0
 FX BOUND     y...1191  1
 BV BOUND     y...1192
 BV BOUND     y...1193
 FX BOUND     y...1194  0
 BV BOUND     y...1195
 FX BOUND     y...1196  0
 BV BOUND     y...1197
 FX BOUND     y...1198  0
 BV BOUND     y...1199
 FX BOUND     y...1200  0
 FX BOUND     y...1201  0
 FX BOUND     y...1202  0
 FX BOUND     y...1203  0
 FX BOUND     y...1204  0
 FX BOUND     y...1205  0
 BV BOUND     y...1206
 BV BOUND     y...1207
 BV BOUND     y...1208
 FX BOUND     y...1209  0
 BV BOUND     y...1210
 FX BOUND     y...1211  0
 BV BOUND     y...1212
 FX BOUND     y...1213  0
 FX BOUND     y...1214  0
 FX BOUND     y...1215  0
 FX BOUND     y...1216  0
 FX BOUND     y...1217  0
 FX BOUND     y...1218  0
 BV BOUND     y...1219
 BV BOUND     y...1220
 BV BOUND     y...1221
 FX BOUND     y...1222  0
 BV BOUND     y...1223
 FX BOUND     y...1224  0
 BV BOUND     y...1225
 FX BOUND     y...1226  0
 BV BOUND     y...1227
 FX BOUND     y...1228  0
 FX BOUND     y...1229  0
 FX BOUND     y...1230  0
 FX BOUND     y...1231  0
 BV BOUND     y...1232
 BV BOUND     y...1233
 BV BOUND     y...1234
 FX BOUND     y...1235  0
 BV BOUND     y...1236
 FX BOUND     y...1237  0
 BV BOUND     y...1238
 BV BOUND     y...1239
 BV BOUND     y...1240
 FX BOUND     y...1241  0
 BV BOUND     y...1242
 FX BOUND     y...1243  0
 FX BOUND     y...1244  0
 BV BOUND     y...1245
 BV BOUND     y...1246
 BV BOUND     y...1247
 BV BOUND     y...1248
 BV BOUND     y...1249
 FX BOUND     y...1250  0
ENDATA
